# More Envíos — Proyecto integrado

Este paquete integra la API y la base de datos en carpetas separadas.

## Estructura

- `more_envios_api/`: API FastAPI, configuración, dependencias y pruebas.
- `more_envios_db/`: migraciones SQL, datos de ejemplo y verificación de integridad.
- `INFORME_TECNICO.md`: resumen de los ajustes incluidos y limitaciones de validación.

## Orden recomendado para preparar un entorno local

1. Instala Python 3.11+, PostgreSQL y `psql`.
2. Crea una base de datos de desarrollo, por ejemplo `more_envios_db`.
3. Configura `DATABASE_URL` para `more_envios_db` y ejecuta las migraciones desde `more_envios_db` siguiendo su README.
4. En `more_envios_api`, ejecuta `configurar_entorno.bat`.
5. Edita `more_envios_api/.env` para usar la misma base local (o, preferentemente, una base de pruebas separada para pytest).
6. Ejecuta `ejecutar_pruebas.bat` y después inicia la API con `\.venv\Scripts\python.exe -m uvicorn app.main:app --reload` desde la carpeta API.

No uses `migrar.sh reset` en una base con datos reales: revierte migraciones y puede borrar datos. Conserva respaldos antes de aplicar cambios a cualquier entorno compartido.
