# More Envíos API

API REST para consultas operativas, reportes y seguimiento de envíos. Está construida con FastAPI, SQLAlchemy 2 y PostgreSQL mediante psycopg 3.

## Requisitos

- Python 3.11 o superior.
- PostgreSQL 12 o superior.
- Una base de datos de desarrollo/pruebas preparada con las migraciones de `../more_envios_db`.

## Instalación en Windows (recomendado)

1. Abre esta carpeta `more_envios_api` en Visual Studio Code.
2. Haz doble clic en `configurar_entorno.bat` o ejecútalo desde CMD. Crea `.venv`, instala las dependencias y copia `.env.example` a `.env` si aún no existe.
3. Edita `.env` y configura `DATABASE_URL` con tu usuario, contraseña y base de datos local. No compartas ni subas `.env` a GitHub.
4. Ejecuta `ejecutar_pruebas.bat` para correr las pruebas. Las pruebas requieren una base de datos de pruebas con los datos de ejemplo.
5. Inicia la API con el comando de abajo.

Si PowerShell bloquea `Activate.ps1`, no necesitas cambiar la política de ejecución: ejecuta el Python del entorno directamente:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest -v
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

**Importante:** ejecuta los comandos desde esta carpeta, donde está `requirements.txt`. Si recibes `Could not open requirements file`, revisa la ruta con `dir` o entra con `cd` a la carpeta correcta.

## Instalación en macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env  # edita DATABASE_URL
python -m uvicorn app.main:app --reload
```

## Endpoints

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/health` | Estado del proceso de la API |
| GET | `/health/db` | Comprueba conexión con PostgreSQL |
| GET | `/envios?estado=&id_cliente=&desde=&page=&size=` | Listado con filtros y paginación |
| GET | `/envios/costosos?costo_min=150` | Envíos por encima de un costo mínimo |
| GET | `/envios/{num_guia}/ruta` | Zonas y sucursales de la ruta |
| GET | `/envios/{num_guia}/historial` | Historial de estados |
| GET | `/reportes/ingresos-por-zona` | Ingresos agregados por zona destino |
| GET | `/reportes/carga-repartidores?min_envios=2` | Carga de trabajo por repartidor |
| GET | `/clientes/sin-fallidos` | Clientes sin envíos fallidos |
| PATCH | `/envios/{num_guia}/estado` | Cambio transaccional de estado |

Cuando se inicia localmente, la documentación interactiva está en `http://127.0.0.1:8000/docs`.

## Reglas de negocio y transacciones

El cambio de estado bloquea la fila con `SELECT ... FOR UPDATE`, valida la transición permitida y, cuando se asigna un repartidor, comprueba que exista y corresponda a la zona de origen. La actualización de estado, la asignación opcional y el historial se confirman en una sola transacción. Ante un error, se revierte la operación.

Transiciones permitidas:

- `creado` → `recolectado`
- `recolectado` → `en_transito`
- `en_transito` → `en_reparto`
- `en_reparto` → `entregado` o `fallido`
- `fallido` → `en_reparto`

## Pruebas

```powershell
.\.venv\Scripts\python.exe -m pytest -v
```

Configura `DATABASE_URL` en `.env` para que apunte a una base exclusiva de pruebas. No ejecutes pruebas transaccionales contra producción.

## Seguridad y mantenimiento

- Las consultas SQL utilizan parámetros enlazados.
- `.env` y `.venv` están excluidos de Git.
- El endpoint `/health/db` comprueba la conexión sin exponer credenciales.
- Los errores de negocio se devuelven con códigos HTTP coherentes: 404 para envíos inexistentes y 409 para transiciones o referencias no válidas.
