"""API de More Envíos: las 10 consultas del miércoles como endpoints."""
from datetime import date
from math import ceil
from typing import Literal

from fastapi import Depends, FastAPI, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.db import get_db
from app.services import ErrorNegocio, NoEncontrado, cambiar_estado

app = FastAPI(
    title="More Envíos API",
    version="1.1.0",
    description="API de consulta, seguimiento y reportes para operaciones de More Envíos.",
    contact={"name": "Equipo de desarrollo More Envíos"},
)


@app.exception_handler(ErrorNegocio)
def manejar_error_negocio(_: Request, exc: ErrorNegocio):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detalle})


def filas(db: Session, sql: str, params: dict | None = None) -> list[dict]:
    return [dict(r) for r in db.execute(text(sql), params or {}).mappings()]


@app.get("/health", tags=["Salud"])
def health():
    """Comprueba que el proceso de la API responde."""
    return {"status": "ok", "service": "more-envios-api", "version": app.version}


@app.get("/health/db", tags=["Salud"])
def health_db(db: Session = Depends(get_db)):
    """Comprueba la conectividad con PostgreSQL."""
    db.execute(text("SELECT 1"))
    return {"status": "ok", "database": "connected"}


# ---------- Consultas 1, 3, 9 y 10: listado con filtros y paginación ----------
@app.get("/envios", tags=["Envíos"])
def listar_envios(
    estado: Literal["creado", "recolectado", "en_transito", "en_reparto", "entregado", "fallido"] | None = None,
    id_cliente: int | None = Query(default=None, ge=1),
    desde: date | None = None,
    page: int = Query(1, ge=1),
    size: int = Query(5, ge=1, le=50),
    db: Session = Depends(get_db),
):
    condiciones, params = [], {}
    if estado:
        condiciones.append("e.estado_actual = :estado")
        params["estado"] = estado
    if id_cliente is not None:
        condiciones.append("e.id_cliente = :id_cliente")
        params["id_cliente"] = id_cliente
    if desde:
        condiciones.append("e.fecha_creacion >= :desde")
        params["desde"] = desde
    where = ("WHERE " + " AND ".join(condiciones)) if condiciones else ""

    total = db.execute(
        text(f"SELECT COUNT(*) FROM envio e {where}"), params
    ).scalar_one()

    items = filas(
        db,
        f"""
        SELECT e.num_guia, c.nombre AS cliente, r.nombre AS repartidor,
               e.estado_actual, e.costo, e.fecha_creacion
        FROM envio e
        JOIN cliente c         ON c.id_cliente = e.id_cliente
        LEFT JOIN repartidor r ON r.id_repartidor = e.id_repartidor
        {where}
        ORDER BY e.fecha_creacion DESC, e.id_envio
        LIMIT :size OFFSET :offset
        """,
        {**params, "size": size, "offset": (page - 1) * size},
    )
    return {
        "page": page,
        "size": size,
        "total": total,
        "total_pages": ceil(total / size) if total else 0,
        "items": items,
    }


# ---------- Consulta 4: envíos caros y su pago ----------
@app.get("/envios/costosos", tags=["Envíos"])
def envios_costosos(
    costo_min: float = Query(default=150, ge=0), db: Session = Depends(get_db)
):
    return filas(
        db,
        """
        SELECT e.num_guia, e.costo, p.estado AS estado_pago
        FROM envio e
        JOIN pago p ON p.id_envio = e.id_envio
        WHERE e.costo > :costo_min
        ORDER BY e.costo DESC
        """,
        {"costo_min": costo_min},
    )


# ---------- Consulta 2: ruta ----------
@app.get("/envios/{num_guia}/ruta", tags=["Envíos"])
def ruta_envio(num_guia: str, db: Session = Depends(get_db)):
    datos = filas(
        db,
        """
        SELECT e.num_guia, zo.nombre AS zona_origen, zd.nombre AS zona_destino,
               so.nombre AS sucursal_origen, sd.nombre AS sucursal_destino
        FROM envio e
        JOIN zona zo          ON zo.id_zona = e.id_zona_origen
        JOIN zona zd          ON zd.id_zona = e.id_zona_destino
        LEFT JOIN sucursal so ON so.id_sucursal = e.id_sucursal_origen
        LEFT JOIN sucursal sd ON sd.id_sucursal = e.id_sucursal_destino
        WHERE e.num_guia = :guia
        """,
        {"guia": num_guia},
    )
    if not datos:
        raise NoEncontrado(f"No existe el envío {num_guia}")
    return datos[0]


# ---------- Consulta 8: historial ----------
@app.get("/envios/{num_guia}/historial", tags=["Envíos"])
def historial_envio(num_guia: str, db: Session = Depends(get_db)):
    datos = filas(
        db,
        """
        SELECT e.num_guia, h.estado, h.fecha_cambio, h.usuario_cambio
        FROM historial_estado h
        JOIN envio e ON e.id_envio = h.id_envio
        WHERE e.num_guia = :guia
        ORDER BY h.fecha_cambio
        """,
        {"guia": num_guia},
    )
    if not datos:
        raise NoEncontrado(f"No hay historial para {num_guia}")
    return datos


# ---------- Consulta 5: ingresos por zona ----------
@app.get("/reportes/ingresos-por-zona", tags=["Reportes"])
def ingresos_por_zona(db: Session = Depends(get_db)):
    return filas(
        db,
        """
        SELECT z.nombre AS zona_destino, COUNT(*) AS total_envios,
               SUM(e.costo) AS ingresos,
               ROUND(AVG(e.costo), 2) AS costo_promedio
        FROM envio e
        JOIN zona z ON z.id_zona = e.id_zona_destino
        GROUP BY z.nombre
        ORDER BY ingresos DESC
        """,
    )


# ---------- Consulta 6: carga de repartidores ----------
@app.get("/reportes/carga-repartidores", tags=["Reportes"])
def carga_repartidores(
    min_envios: int = Query(2, ge=1), db: Session = Depends(get_db)
):
    return filas(
        db,
        """
        SELECT r.nombre AS repartidor, COUNT(*) AS envios_asignados
        FROM envio e
        JOIN repartidor r ON r.id_repartidor = e.id_repartidor
        GROUP BY r.nombre
        HAVING COUNT(*) >= :min_envios
        ORDER BY envios_asignados DESC, r.nombre
        """,
        {"min_envios": min_envios},
    )


# ---------- Consulta 7: clientes sin fallidos ----------
# NOT EXISTS en lugar de NOT IN: no se rompe si id_cliente llega a ser NULL.
@app.get("/clientes/sin-fallidos", tags=["Clientes"])
def clientes_sin_fallidos(db: Session = Depends(get_db)):
    return filas(
        db,
        """
        SELECT c.nombre, c.correo
        FROM cliente c
        WHERE NOT EXISTS (
            SELECT 1 FROM envio e
            WHERE e.id_cliente = c.id_cliente AND e.estado_actual = 'fallido'
        )
        ORDER BY c.nombre
        """,
    )


# ---------- Transacción: cambio de estado ----------
class CambioEstado(BaseModel):
    estado: str = Field(min_length=1, max_length=15, examples=["recolectado"])
    usuario: str = Field(min_length=1, max_length=50, examples=["repartidor:1"])
    id_repartidor: int | None = Field(default=None, ge=1)


@app.patch("/envios/{num_guia}/estado", tags=["Envíos"])
def patch_estado(
    num_guia: str, body: CambioEstado, db: Session = Depends(get_db)
):
    return cambiar_estado(
        db, num_guia, body.estado, body.usuario, body.id_repartidor
    )
