"""Reglas de negocio y actualización transaccional de envíos."""
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

TRANSICIONES = {
    "creado": {"recolectado"},
    "recolectado": {"en_transito"},
    "en_transito": {"en_reparto"},
    "en_reparto": {"entregado", "fallido"},
    "fallido": {"en_reparto"},
    "entregado": set(),
}


class ErrorNegocio(Exception):
    status_code = 400

    def __init__(self, detalle: str):
        super().__init__(detalle)
        self.detalle = detalle


class NoEncontrado(ErrorNegocio):
    status_code = 404


class TransicionInvalida(ErrorNegocio):
    status_code = 409


class ReferenciaInvalida(ErrorNegocio):
    status_code = 409


def cambiar_estado(
    db: Session,
    num_guia: str,
    nuevo_estado: str,
    usuario: str,
    id_repartidor: int | None = None,
) -> dict:
    """Cambia estado, asignación opcional e historial en una sola transacción."""
    try:
        envio = db.execute(
            text(
                "SELECT id_envio, estado_actual, id_repartidor, id_zona_origen "
                "FROM envio WHERE num_guia = :guia FOR UPDATE"
            ),
            {"guia": num_guia},
        ).mappings().first()
        if envio is None:
            raise NoEncontrado(f"No existe el envío {num_guia}")

        actual = envio["estado_actual"]
        if nuevo_estado not in TRANSICIONES.get(actual, set()):
            raise TransicionInvalida(
                f"No se puede pasar de '{actual}' a '{nuevo_estado}'"
            )

        repartidor_final = envio["id_repartidor"]
        if id_repartidor is not None:
            repartidor = db.execute(
                text("SELECT id_repartidor, id_zona FROM repartidor WHERE id_repartidor = :id"),
                {"id": id_repartidor},
            ).mappings().first()
            if repartidor is None:
                raise ReferenciaInvalida(f"No existe el repartidor {id_repartidor}")
            if repartidor["id_zona"] != envio["id_zona_origen"]:
                raise ReferenciaInvalida(
                    "El repartidor no pertenece a la zona de origen del envío"
                )
            repartidor_final = id_repartidor

        db.execute(
            text("UPDATE envio SET estado_actual = :estado WHERE id_envio = :id"),
            {"estado": nuevo_estado, "id": envio["id_envio"]},
        )
        if id_repartidor is not None:
            db.execute(
                text("UPDATE envio SET id_repartidor = :repartidor WHERE id_envio = :id"),
                {"repartidor": id_repartidor, "id": envio["id_envio"]},
            )
        db.execute(
            text(
                "INSERT INTO historial_estado "
                "(id_envio, estado, fecha_cambio, usuario_cambio) "
                "VALUES (:id, :estado, now(), :usuario)"
            ),
            {"id": envio["id_envio"], "estado": nuevo_estado, "usuario": usuario},
        )
        db.commit()
        return {
            "num_guia": num_guia,
            "estado_anterior": actual,
            "estado_actual": nuevo_estado,
            "id_repartidor": repartidor_final,
        }
    except IntegrityError as exc:
        db.rollback()
        raise ReferenciaInvalida(
            "El cambio viola una restricción de integridad de la base de datos"
        ) from exc
    except Exception:
        db.rollback()
        raise
