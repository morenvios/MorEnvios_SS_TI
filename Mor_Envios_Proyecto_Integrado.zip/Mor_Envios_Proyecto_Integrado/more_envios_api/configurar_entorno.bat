@echo off
setlocal
cd /d "%~dp0"
echo === Configuracion del entorno de More Envios API ===
where py >nul 2>nul
if errorlevel 1 (
  where python >nul 2>nul
  if errorlevel 1 (
    echo ERROR: No se encontro Python. Instala Python 3.11 o superior y vuelve a intentarlo.
    pause
    exit /b 1
  )
  set PYTHON_CMD=python
) else (
  set PYTHON_CMD=py
)
if not exist ".venv\Scripts\python.exe" (
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 goto error
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error
if not exist ".env" copy ".env.example" ".env" >nul
echo.
echo Entorno preparado. Revisa DATABASE_URL en el archivo .env antes de iniciar la API.
echo Para ejecutar pruebas usa ejecutar_pruebas.bat.
pause
exit /b 0
:error
echo ERROR: No se pudo completar la configuracion. Revisa el mensaje anterior.
pause
exit /b 1
