@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: No existe .venv. Ejecuta primero configurar_entorno.bat.
  pause
  exit /b 1
)
if not exist ".env" (
  echo ERROR: No existe .env. Copia .env.example a .env y configura DATABASE_URL.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pytest -v
set RESULT=%ERRORLEVEL%
if not "%RESULT%"=="0" echo Algunas pruebas fallaron o no se pudo conectar a la base de pruebas.
pause
exit /b %RESULT%
