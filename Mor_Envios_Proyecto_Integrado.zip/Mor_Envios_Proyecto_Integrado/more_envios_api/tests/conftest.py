"""Pruebas contra la base real, sin dejar rastro.

Cada prueba corre dentro de una transacción externa que se revierte al final.
Los commit() del código se convierten en SAVEPOINT (create_savepoint), así que
el rollback del servicio también se puede comprobar.
Usa una base de pruebas: export DATABASE_URL=...more_envios_test
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.db import engine, get_db
from app.main import app


@pytest.fixture
def db():
    conn = engine.connect()
    trans = conn.begin()
    session = Session(bind=conn, join_transaction_mode="create_savepoint")
    yield session
    session.close()
    trans.rollback()
    conn.close()


@pytest.fixture
def client(db):
    app.dependency_overrides[get_db] = lambda: db
    yield TestClient(app)
    app.dependency_overrides.clear()
