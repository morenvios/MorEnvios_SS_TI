"""Pruebas básicas de disponibilidad y documentación OpenAPI."""
from fastapi.testclient import TestClient

from app.main import app


def test_health_responde():
    response = TestClient(app).get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_openapi_contiene_endpoints_principales():
    response = TestClient(app).get("/openapi.json")
    assert response.status_code == 200
    paths = response.json()["paths"]
    assert "/envios" in paths
    assert "/health/db" in paths
    assert "/envios/{num_guia}/estado" in paths
