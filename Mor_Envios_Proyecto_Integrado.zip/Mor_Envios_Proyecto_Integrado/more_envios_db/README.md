# More Envios - base de datos

Esquema PostgreSQL para el seguimiento de envios (clientes, repartidores, zonas, sucursales, tarifas, pagos).
Probado con PostgreSQL 16.2.

## Requisitos
- PostgreSQL 12 o superior
- `psql` en el PATH
- bash

## Uso

```bash
createdb more_envios
export DATABASE_URL=postgresql+psycopg://usuario:clave@localhost:5432/more_envios

bash migrar.sh up       # aplica las migraciones pendientes
bash migrar.sh status   # lista las aplicadas
bash migrar.sh down     # revierte la ultima
bash migrar.sh reset    # revierte migraciones y vuelve a aplicar (solo para desarrollo/pruebas)

psql "$DATABASE_URL" -f pruebas/verificar_integridad.sql   # cada consulta debe dar 0 filas
```

Advertencia: reset revierte las migraciones; úsalo solo en desarrollo/pruebas y nunca contra producción sin respaldo.

Cada migracion corre en una sola transaccion: si falla, no queda nada a medias.
El estado se guarda en la tabla `schema_migrations`.

## Estructura

```
migrar.sh
migraciones/
  001_crear_tablas      tablas, columnas, PK, NOT NULL, DEFAULT
  002_restricciones     UNIQUE, CHECK, FK (con ON DELETE)
  003_indices           indices sobre FK y filtros frecuentes
  004_datos_semilla     5 zonas, 5 sucursales, 8 clientes, 6 repartidores,
                        6 tarifas, 12 envios con historial y pago
pruebas/
  verificar_integridad.sql
```

Cada migracion tiene su `.up.sql` y su `.down.sql`.

## Convenciones
- Tablas y campos en snake_case, singular, sin acentos.
- Restricciones con nombre: `pk_`, `uq_`, `ck_`, `fk_` + tabla + detalle.
- Montos en NUMERIC, fechas en TIMESTAMP.
- Tarifa por rango de peso: (peso_min_kg, peso_max_kg].
- Los hashes de `administrador` en la semilla son de ejemplo, no son reales.

## Notas
- La semilla usa ids implicitos (SERIAL desde 1), asi que asume tablas vacias.
- `estado_actual` en `envio` y `historial_estado` deben actualizarse juntos, en la misma transaccion (se hace desde la API).
- Pendiente: decidir si `usuario_cambio` pasa a ser FK hacia repartidor/administrador.
