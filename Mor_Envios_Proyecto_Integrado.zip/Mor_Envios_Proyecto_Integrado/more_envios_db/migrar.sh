#!/usr/bin/env bash
# Uso: DATABASE_URL=postgresql://user:clave@localhost:5432/more_envios ./migrar.sh <up|down|reset|status>
#   up      aplica las migraciones pendientes (en orden)
#   down    revierte la ultima migracion aplicada
#   reset   revierte todas y vuelve a aplicarlas
#   status  muestra las migraciones aplicadas
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)/migraciones"
: "${DATABASE_URL:?Falta DATABASE_URL, ej: postgresql://user:clave@localhost:5432/more_envios}"
PSQL=(psql "$DATABASE_URL" -X -q -v ON_ERROR_STOP=1)

asegurar_tabla() {
  "${PSQL[@]}" -c "CREATE TABLE IF NOT EXISTS schema_migrations (
    version CHAR(3) PRIMARY KEY,
    nombre TEXT NOT NULL,
    aplicada_en TIMESTAMP NOT NULL DEFAULT now());"
}

up() {
  for f in "$DIR"/*.up.sql; do
    base=$(basename "$f" .up.sql); ver=${base%%_*}; nombre=${base#*_}
    if [[ -n "$("${PSQL[@]}" -tA -c "SELECT 1 FROM schema_migrations WHERE version='$ver'")" ]]; then
      echo "  = $base (ya aplicada)"; continue
    fi
    echo "  + $base"
    "${PSQL[@]}" --single-transaction -f "$f" \
      -c "INSERT INTO schema_migrations (version, nombre) VALUES ('$ver', '$nombre');"
  done
}

down() {
  ver=$("${PSQL[@]}" -tA -c "SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1")
  if [[ -z "$ver" ]]; then echo "  nada que revertir"; return 1; fi
  f=$(ls "$DIR"/${ver}_*.down.sql)
  echo "  - $(basename "$f" .down.sql)"
  "${PSQL[@]}" --single-transaction -f "$f" \
    -c "DELETE FROM schema_migrations WHERE version='$ver';"
}

asegurar_tabla
case "${1:-}" in
  up)     up ;;
  down)   down ;;
  reset)  while down; do :; done; up ;;
  status) "${PSQL[@]}" -c "SELECT * FROM schema_migrations ORDER BY version;" ;;
  *)      sed -n '2,6p' "$0"; exit 1 ;;
esac
