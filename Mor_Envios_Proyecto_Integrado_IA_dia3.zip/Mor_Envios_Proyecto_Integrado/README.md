# More Envíos — Proyecto integrado

- `more_envios_api/`: API FastAPI (autenticación por llave, validación, límites, salud) y pruebas.
- `more_envios_db/`: migraciones 001–005, datos de ejemplo y verificaciones SQL.
- `docs/INFORME_TECNICO.md`: qué se cambió y qué se verificó. `docs/SEGURIDAD.md`: controles y límites.
- `.github/workflows/ci.yml`: migraciones, pruebas y `pip-audit` en cada push.

## Preparar un entorno local
1. Instala Python 3.11+, PostgreSQL y `psql`.
2. Crea las bases `more_envios_db` y `more_envios_test`.
3. En `more_envios_db`: `export DATABASE_URL=postgresql://usuario:clave@localhost:5432/more_envios_test` y `bash migrar.sh up` (Git Bash o WSL en Windows). Repite con `more_envios_db` para desarrollo.
4. Asigna contraseña al rol de la API (ver README de la base).
5. En `more_envios_api`: `configurar_entorno.bat`, edita `.env`, `ejecutar_pruebas.bat`, `iniciar_api.bat`.

No uses `migrar.sh reset` en una base con datos reales.
