"""Busca claves reales y usos indebidos de la clave de IA en los archivos del proyecto.

Revisa tres cosas:
  1. Claves de proveedores (sk-ant-..., ghp_...) escritas en cualquier archivo.
  2. IA_API_KEY / ANTHROPIC_API_KEY / OPENAI_API_KEY con un valor que no sea el de ejemplo.
  3. Codigo de navegador (.html, .js, .jsx, .ts, .tsx, .vue...) que mencione al proveedor de IA
     o a esas variables: el navegador NO debe hablar con el proveedor ni conocer la clave.

Nunca imprime el valor encontrado, solo archivo, linea y regla.
Una linea con la marca "secreto-falso" se ignora (para claves de mentira en pruebas).

Uso:  python escanear_secretos.py [carpeta] [--incluir-env]
      --incluir-env tambien revisa archivos .env (en CI: un .env subido a git es un hallazgo).
Sale con codigo 1 si encuentra algo.
"""
import re
import sys
from dataclasses import dataclass
from pathlib import Path

IGNORAR_CARPETAS = {".git", ".venv", "venv", "__pycache__", ".pytest_cache", "node_modules"}
MARCA_FALSO = "secreto-falso"
TAM_MAX = 1_000_000
EXT_NAVEGADOR = {".html", ".htm", ".js", ".mjs", ".jsx", ".ts", ".tsx", ".vue", ".svelte"}

CLAVES_PROVEEDOR = re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}|\bsk-[A-Za-z0-9]{32,}|ghp_[A-Za-z0-9]{36}")
ASIGNACION_IA = re.compile(r"^\s*(?:export\s+)?(IA_API_KEY|ANTHROPIC_API_KEY|OPENAI_API_KEY)\s*[=:]\s*['\"]?([^\s'\"#]*)")
USO_EN_NAVEGADOR = re.compile(r"api\.anthropic\.com|api\.openai\.com|IA_API_KEY|ANTHROPIC_API_KEY|OPENAI_API_KEY|anthropic-version")


@dataclass(frozen=True)
class Hallazgo:
    archivo: str
    linea: int
    regla: str

    def __str__(self) -> str:
        return f"{self.archivo}:{self.linea}  {self.regla}"


def _es_ejemplo(valor: str) -> bool:
    return valor == "" or "CAMBIAME" in valor.upper()


def escanear(raiz: Path, incluir_env: bool = False) -> list[Hallazgo]:
    hallazgos: list[Hallazgo] = []
    for ruta in sorted(raiz.rglob("*")):
        if not ruta.is_file() or any(p in IGNORAR_CARPETAS for p in ruta.relative_to(raiz).parts):
            continue
        if ruta.name == ".env" and not incluir_env:
            continue  # el .env local es donde SI van los secretos; no se sube (ver .gitignore)
        try:
            if ruta.stat().st_size > TAM_MAX:
                continue
            datos = ruta.read_bytes()
        except OSError:
            continue
        if b"\x00" in datos:
            continue  # binario
        rel = str(ruta.relative_to(raiz))
        es_navegador = ruta.suffix.lower() in EXT_NAVEGADOR
        if ruta.name == ".env":
            hallazgos.append(Hallazgo(rel, 1, "archivo .env dentro del repositorio"))
        for n, linea in enumerate(datos.decode("utf-8", errors="ignore").splitlines(), 1):
            if MARCA_FALSO in linea:
                continue
            if CLAVES_PROVEEDOR.search(linea):
                hallazgos.append(Hallazgo(rel, n, "clave de proveedor escrita en el archivo"))
            m = ASIGNACION_IA.match(linea)
            if m and not _es_ejemplo(m.group(2)):
                hallazgos.append(Hallazgo(rel, n, f"{m.group(1)} con un valor real"))
            if es_navegador and USO_EN_NAVEGADOR.search(linea):
                hallazgos.append(Hallazgo(rel, n, "codigo de navegador que menciona al proveedor de IA o su clave"))
    return hallazgos


def main(argv: list[str]) -> int:
    incluir_env = "--incluir-env" in argv
    carpetas = [a for a in argv if not a.startswith("--")]
    raiz = Path(carpetas[0] if carpetas else ".").resolve()
    hallazgos = escanear(raiz, incluir_env)
    for h in hallazgos:
        print(h)
    print(f"{len(hallazgos)} hallazgo(s) en {raiz}")
    return 1 if hallazgos else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
