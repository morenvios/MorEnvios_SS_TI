# More Envíos API

API FastAPI sobre PostgreSQL: 10 consultas, un cambio de estado transaccional y endpoints de salud.

## Windows (sin activar nada en PowerShell)
1. `configurar_entorno.bat` crea `.venv`, instala `requirements-dev.txt` y genera `.env` con una llave de API aleatoria.
2. Abre `.env` y cambia `CAMBIAME` en `DATABASE_URL` por la clave de tu base.
3. `ejecutar_pruebas.bat` (usa una base de PRUEBAS, por ejemplo `more_envios_test`).
4. `iniciar_api.bat` levanta la API en `127.0.0.1:8000`.

## Variables de entorno (`.env`)
| Variable | Para qué |
|---|---|
| `DATABASE_URL` | Conexión. En uso real, con el rol `more_envios_api` (permisos mínimos), no `postgres`. |
| `API_KEYS` | `usuario:llave,usuario:llave`. Mínimo 24 caracteres. La API no arranca si falta, es corta o es la de ejemplo. |
| `LIMITE_PETICIONES_POR_MIN` | Peticiones por minuto por IP (60 por defecto). |
| `EXPONER_DOCS` | `1` enciende `/docs` (solo en tu computadora). |
| `IA_HABILITADA` | `1` enciende la explicación con IA. Apagada (`0`) por defecto: el endpoint sigue funcionando con la plantilla fija del estado (sin costo y sin llamar al proveedor). |
| `IA_API_KEY` | Clave del proveedor de IA. Solo en este `.env`. Si `IA_HABILITADA=1` y falta, es de ejemplo, corta o tiene caracteres raros, la API no arranca. |
| `IA_MODELO`, `IA_URL` | Modelo y dirección del proveedor (por defecto `claude-haiku-5-5` y la API de Anthropic; `IA_URL` debe ser `https://`). |
| `IA_TIMEOUT_SEG`, `IA_MAX_TOKENS_SALIDA` | Espera máxima al proveedor (8 s) y tope de tokens de respuesta (200). |
| `IA_LIMITE_POR_MIN`, `IA_LIMITE_DIARIO` | Topes de uso: por llave de API por minuto (10) y total por día (200, provisional). |

## Uso
Todas las rutas, salvo `/health` y `/health/db`, piden el encabezado `X-API-Key`.
```
curl -H "X-API-Key: TU_LLAVE" "http://127.0.0.1:8000/envios?size=2"
curl -X PATCH -H "X-API-Key: TU_LLAVE" -H "Content-Type: application/json" \
     -d '{"estado":"recolectado","id_repartidor":1}' http://127.0.0.1:8000/envios/MEV-2026-000010/estado
```
El PATCH ya no recibe `usuario`: se guarda el dueño de la llave. El repartidor debe existir y trabajar en la zona de origen del envío (si no, 409).

## Explicación del estado de un envío con IA
`POST /envios/{num_guia}/explicacion` con cuerpo opcional `{"pregunta": "..."}` (máximo 200 caracteres). Pide `X-API-Key` como las demás rutas.
```
curl -X POST -H "X-API-Key: TU_LLAVE" -H "Content-Type: application/json" \
     -d '{"pregunta":"¿Cómo va mi envío?"}' http://127.0.0.1:8000/envios/MEV-2026-000005/explicacion
```
- Es de **solo lectura**: no puede cambiar nada en la base.
- Al proveedor solo se le envía guía, estado e historial (estado y fecha). No salen nombres, correos, teléfonos, direcciones, costos, repartidores ni `usuario_cambio`.
- La clave del proveedor se usa únicamente en el servidor. Para guardarla sin mostrarla en pantalla: `configurar_ia.bat` (apagar: `configurar_ia.bat --apagar`).

Respuesta (siempre estos seis campos):
```
{"num_guia":"MEV-2026-000005","estado_actual":"en_transito","requiere_atencion":false,
 "resumen":"Tu envío va en tránsito.","siguiente_paso":"El siguiente paso es que salga a reparto. ...","origen":"ia"}
```
- `origen` es `"ia"` si el texto lo redactó el modelo y pasó la validación, o `"plantilla"` si se usó el texto fijo del estado.
- `estado_actual` sale siempre de la base. `requiere_atencion` es verdadero si el envío está fallido **o** si la IA lo marca (por ejemplo, un reclamo de dinero): la IA solo puede subirlo, nunca bajarlo.
- La IA debe responder un JSON de tres campos (`resumen`, `siguiente_paso`, `requiere_atencion`). El servidor lo valida: esquema estricto y coherencia con la base (estado que contradice, fechas u horas que no están en el historial, promesas de plazo o de dinero, enlaces, datos personales, filtración del prompt, idioma).
- Se responde con la **plantilla** (HTTP 200, `origen: "plantilla"`) cuando el proveedor falla o se pasa del tiempo, cuando la salida no es válida o contradice a la base, y cuando la IA está apagada. El motivo queda en el log (`ia_respaldo ... motivo=...`) y nunca se le muestra al cliente.
- `429` si se pasa un tope de uso (por llave por minuto o diario). Una guía inexistente (404) o una entrada inválida (422) no llaman al proveedor.
- Para apagar la IA en un incidente sin dejar de dar servicio: `configurar_ia.bat --apagar` y reiniciar la API.
- Pendiente (jueves): medir con el proveedor real la calidad, la latencia, el costo y la tasa de respaldo.

## Producción
Instala solo `requirements.txt` (versiones fijas). `requirements-dev.txt` es para pruebas. Sin `--reload`. Poner HTTPS y un límite de peticiones en el proxy.
