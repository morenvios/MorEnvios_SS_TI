"""Configuración de la función de IA y manejo de secretos.

Principios:
  * La clave del proveedor vive SOLO en la variable de entorno IA_API_KEY (archivo
    .env, fuera de git). Nunca viaja al navegador ni a la base, ni se devuelve en
    ninguna respuesta.
  * Si la función está apagada (IA_HABILITADA distinto de 1), la clave ni siquiera
    se guarda en memoria.
  * Si está encendida y la configuración es mala, la API se niega a arrancar
    (igual que con API_KEYS): mejor fallar al inicio que a mitad de una petición.
  * El valor de la clave se envuelve en `Secreto`: print(), repr(), f-strings y los
    logs muestran *** en lugar del valor.
"""
import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from dotenv import load_dotenv

# Misma carpeta que db.py. No pisa variables que ya vengan del sistema.
load_dotenv(Path(__file__).resolve().parents[1] / ".env")

URL_PROVEEDOR_DEFECTO = "https://api.anthropic.com/v1/messages"
MODELO_DEFECTO = "claude-haiku-5-5"
LARGO_MINIMO_CLAVE_IA = 20
FORMATO_CLAVE_IA = re.compile(r"^[A-Za-z0-9_-]+$")  # sin espacios, saltos de línea ni comillas


class Secreto:
    """Envuelve un valor sensible para que no salga por accidente en logs o trazas."""

    __slots__ = ("_valor",)

    def __init__(self, valor: str):
        self._valor = valor

    def revelar(self) -> str:
        """Único punto donde se lee el valor real (al armar la petición al proveedor)."""
        return self._valor

    def __repr__(self) -> str:
        return "Secreto(***)"

    __str__ = __repr__

    def __reduce__(self):  # evita que un pickle/copia lo exponga en claro
        raise TypeError("Secreto no se puede serializar")


@dataclass(frozen=True)
class ConfigIA:
    habilitada: bool = False
    api_key: Secreto | None = None
    modelo: str = MODELO_DEFECTO
    url: str = URL_PROVEEDOR_DEFECTO
    timeout_seg: float = 8.0          # tiempo máximo de espera al proveedor
    max_tokens_salida: int = 200      # tope de lo que puede responder (controla el costo)
    limite_por_min: int = 10          # llamadas a la IA por minuto, por llave de API
    limite_diario: int = 200          # llamadas a la IA por día, en total (por decidir con el equipo)


def _entero(env: Mapping[str, str], nombre: str, defecto: int, minimo: int, maximo: int) -> int:
    crudo = env.get(nombre, "").strip()
    if not crudo:
        return defecto
    try:
        valor = int(crudo)
    except ValueError:
        raise RuntimeError(f"{nombre} debe ser un número entero") from None
    if not minimo <= valor <= maximo:
        raise RuntimeError(f"{nombre} debe estar entre {minimo} y {maximo}")
    return valor


def cargar_config_ia(env: Mapping[str, str]) -> ConfigIA:
    """Lee y valida la configuración. Los mensajes de error nunca incluyen la clave."""
    if env.get("IA_HABILITADA", "0").strip() != "1":
        return ConfigIA(habilitada=False)

    clave = env.get("IA_API_KEY", "").strip()
    if not clave:
        raise RuntimeError("IA_HABILITADA=1 pero falta IA_API_KEY (ver .env.example)")
    if "CAMBIAME" in clave.upper():
        raise RuntimeError("IA_API_KEY sigue siendo la de ejemplo: pon la clave real de tu proveedor")
    if len(clave) < LARGO_MINIMO_CLAVE_IA:
        raise RuntimeError(f"IA_API_KEY es muy corta (mínimo {LARGO_MINIMO_CLAVE_IA} caracteres)")
    if not FORMATO_CLAVE_IA.match(clave):
        raise RuntimeError("IA_API_KEY solo puede tener letras, números, guion y guion bajo")

    url = env.get("IA_URL", "").strip() or URL_PROVEEDOR_DEFECTO
    # La clave viaja en un encabezado: solo por HTTPS (o a una prueba local).
    if not (url.startswith("https://") or url.startswith(("http://127.0.0.1", "http://localhost"))):
        raise RuntimeError("IA_URL debe empezar con https://")

    try:
        timeout = float(env.get("IA_TIMEOUT_SEG", "").strip() or 8)
    except ValueError:
        raise RuntimeError("IA_TIMEOUT_SEG debe ser un número") from None
    if not 1 <= timeout <= 30:
        raise RuntimeError("IA_TIMEOUT_SEG debe estar entre 1 y 30")

    return ConfigIA(
        habilitada=True,
        api_key=Secreto(clave),
        modelo=env.get("IA_MODELO", "").strip() or MODELO_DEFECTO,
        url=url,
        timeout_seg=timeout,
        max_tokens_salida=_entero(env, "IA_MAX_TOKENS_SALIDA", 200, 50, 1000),
        limite_por_min=_entero(env, "IA_LIMITE_POR_MIN", 10, 1, 600),
        limite_diario=_entero(env, "IA_LIMITE_DIARIO", 200, 1, 1_000_000),
    )


class FiltroRedaccion(logging.Filter):
    """Última red de seguridad: si un valor secreto llegara a un mensaje de log, se tapa."""

    def __init__(self, secretos: list[str]):
        super().__init__()
        self._secretos = [s for s in secretos if s]

    def filter(self, record: logging.LogRecord) -> bool:
        mensaje = record.getMessage()
        if any(s in mensaje for s in self._secretos):
            for s in self._secretos:
                mensaje = mensaje.replace(s, "***")
            record.msg, record.args = mensaje, ()
        return True


def instalar_redaccion(config: ConfigIA) -> None:
    """Pone el filtro en los loggers que tocan la llamada al proveedor."""
    if config.api_key is None:
        return
    filtro = FiltroRedaccion([config.api_key.revelar()])
    for nombre in ("more_envios", "httpx", "httpcore"):
        logging.getLogger(nombre).addFilter(filtro)
    # httpx registra cada petición en INFO; no hace falta ese ruido.
    logging.getLogger("httpx").setLevel(logging.WARNING)


CONFIG_IA = cargar_config_ia(os.environ)
instalar_redaccion(CONFIG_IA)
