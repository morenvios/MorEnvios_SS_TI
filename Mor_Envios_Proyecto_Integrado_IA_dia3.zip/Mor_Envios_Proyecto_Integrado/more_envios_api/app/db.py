"""Configuración de PostgreSQL y sesiones SQLAlchemy para la API."""
import os
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker

# Carga .env desde la carpeta del proyecto API, no desde el directorio actual.
ENV_FILE = Path(__file__).resolve().parents[1] / ".env"
load_dotenv(ENV_FILE)

DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
if not DATABASE_URL:
    raise RuntimeError(
        f"Falta DATABASE_URL. Crea {ENV_FILE} a partir de .env.example (o ejecuta configurar_entorno.bat)."
    )

# El proyecto usa psycopg 3. Una URL postgres:// o postgresql:// sin driver
# explícito intenta cargar psycopg2; se normaliza para evitarlo.
_url = make_url(DATABASE_URL)
if _url.drivername in {"postgres", "postgresql"}:
    _url = _url.set(drivername="postgresql+psycopg")

engine = create_engine(_url, pool_pre_ping=True, pool_recycle=1800)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_db():
    """Abre una sesión por petición y garantiza su cierre."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
