"""Salida estructurada de la IA: esquema, validación de coherencia y plantilla de respaldo.

La IA debe responder un JSON con exactamente tres campos:
    {"resumen": str, "siguiente_paso": str, "requiere_atencion": bool}
El servidor NUNCA le pasa al cliente algo que no haya validado aquí. Si la salida
no cumple, ia.py usa la plantilla fija del estado (misma forma de respuesta,
origen = "plantilla").

Dos capas:
  1. Esquema: JSON válido, solo esas claves, tipos y largos correctos.
  2. Coherencia con la base (reglas que SÍ se pueden verificar por código):
     estado que contradice la base, fechas u horas que no están en el historial,
     promesas de plazo o de dinero, enlaces, datos personales, filtración del
     prompt e idioma.

Límite que hay que decir en voz alta: son heurísticas sobre texto libre. Atrapan
lo evidente y lo medible, no lo garantizan todo (una paráfrasis rara puede pasar).
Lo que sí está garantizado no depende del texto: estado_actual sale de la base.
La tasa real de falsos rechazos y de fallas se mide el jueves con el modelo real.
"""
import json
import re
from dataclasses import dataclass

# ---------------------------------------------------------------- errores y tipos
class SalidaInvalida(Exception):
    """La salida de la IA no sirve. `motivo` es un código fijo (nunca texto del modelo)."""

    def __init__(self, motivo: str):
        super().__init__(motivo)
        self.motivo = motivo


@dataclass(frozen=True)
class Salida:
    resumen: str
    siguiente_paso: str
    requiere_atencion: bool


CAMPOS = {"resumen", "siguiente_paso", "requiere_atencion"}
LARGO_RESUMEN = 300
LARGO_SIGUIENTE = 200

MESES = {
    "enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6, "julio": 7,
    "agosto": 8, "septiembre": 9, "setiembre": 9, "octubre": 10, "noviembre": 11, "diciembre": 12,
}
MESES_TEXTO = [
    "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre",
    "octubre", "noviembre", "diciembre",
]


# ---------------------------------------------------------------- 1. esquema
def parsear(texto: str) -> Salida:
    """Convierte el texto del modelo en Salida o lanza SalidaInvalida (sin mostrar el texto)."""
    t = texto.strip()
    # Los modelos a veces envuelven el JSON en ```json ... ```; eso se tolera.
    envuelto = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", t, re.S | re.I)
    if envuelto:
        t = envuelto.group(1)
    try:
        datos = json.loads(t)
    except ValueError:
        raise SalidaInvalida("json_invalido") from None
    if not isinstance(datos, dict):
        raise SalidaInvalida("no_es_objeto")
    if set(datos) != CAMPOS:
        raise SalidaInvalida("campos_distintos")
    resumen, siguiente, atencion = datos["resumen"], datos["siguiente_paso"], datos["requiere_atencion"]
    if not isinstance(resumen, str) or not isinstance(siguiente, str):
        raise SalidaInvalida("tipo_texto")
    if not isinstance(atencion, bool):
        raise SalidaInvalida("tipo_booleano")
    resumen, siguiente = resumen.strip(), siguiente.strip()
    if not 1 <= len(resumen) <= LARGO_RESUMEN:
        raise SalidaInvalida("largo_resumen")
    if not 1 <= len(siguiente) <= LARGO_SIGUIENTE:
        raise SalidaInvalida("largo_siguiente_paso")
    return Salida(resumen, siguiente, atencion)


# ---------------------------------------------------------------- 2. coherencia
# Cómo puede nombrar el modelo cada estado (técnico y en lenguaje natural).
FORMAS_ESTADO = {
    "creado": r"cread[oa]|se cre[óo]",
    "recolectado": r"recolectad[oa]|recolect[óo]|recolecci[óo]n|recogid[oa]",
    "en_transito": r"en_transito|en tr[áa]nsito",
    "en_reparto": r"en_reparto|en reparto",
    "entregado": r"entregad[oa]|entreg[óo]|entregaron",
    "fallido": r"fallid[oa]|fall[óo]",
}
# Una mención "negada" no afirma nada ("aún no fue entregado", "sin fecha estimada").
NEGADORES = {"no", "nunca", "sin", "ni", "tampoco", "pendiente", "falta", "faltan", "antes"}

PLAZOS = re.compile(
    r"\b(?:mañana|hoy|ayer|anteayer|esta (?:tarde|noche|semana)|pronto|en breve|a más tardar|"
    r"estimad[oa]s?|llegar[áa]|llegar[íi]a|arribar[áa]|se entregar[áa]|ser[áa] entregad[oa]|"
    r"entregaremos|va a llegar|pr[óo]xim[oa]s? (?:horas|d[íi]as|semana)|"
    r"en \d+ (?:minutos?|horas?|d[íi]as?|semanas?))\b"
)
HORA_SUELTA = re.compile(r"\ba las? \d{1,2}\b|\b\d{1,2}\s?(?:am|pm|hrs?|horas?)\b")
COMPROMISO_DINERO = [
    re.compile(r"\b(?:te|se te|le|les)\s+(?:reembols|devolv|compens|indemniz|reintegr)\w*"),
    re.compile(r"\b(?:reembolsar|devolver|compensar|indemnizar|reintegrar)(?:emos|á|án|é|ía|ían)\b"),
    re.compile(
        r"\b(?:recibir[áa]s|obtendr[áa]s|tendr[áa]s|tienes derecho a)\b[^.]{0,40}"
        r"\b(?:reembolso|devoluci[óo]n|compensaci[óo]n|indemnizaci[óo]n)"
    ),
]
ENLACE = re.compile(r"https?://|www\.|\b\w+\.(?:com|mx|net|org|io)\b")
CORREO = re.compile(r"\S+@\S+")
DINERO = re.compile(r"\$\s?\d|\d\s*(?:pesos|mxn|usd)\b")
TELEFONO = re.compile(r"(?<!\d)(?:\d[\s.-]?){7,}(?!\d)")
MARCAS_PROMPT = re.compile(r"datos_envio|pregunta_cliente")
CARACTERES_PROHIBIDOS = re.compile(r"[<>\x00-\x08\x0b-\x1f\x7f]")
PALABRAS_ES = {
    "el", "la", "los", "las", "tu", "tus", "su", "sus", "de", "en", "que", "un", "una", "por", "con",
    "se", "va", "está", "fue", "ya", "aún", "es", "envío", "paquete", "y", "lo", "al",
}

RE_ISO = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")
RE_NUM = re.compile(r"\b(\d{1,2})[/-](\d{1,2})(?:[/-](\d{4}|\d{2}))?\b")
RE_TEXTO = re.compile(r"\b(\d{1,2}) de (" + "|".join(MESES) + r")(?: de (\d{4}))?\b")
RE_HORA = re.compile(r"\b([01]?\d|2[0-3]):([0-5]\d)\b")


def _palabras(texto: str) -> list[str]:
    return re.findall(r"[a-záéíóúñü]+", texto.lower())


def _negado(texto: str, inicio: int, ventana: int | None = 4) -> bool:
    """¿Hay un negador en las `ventana` palabras anteriores, dentro de la misma oración?

    ventana=None mira toda la oración anterior (se usa solo para "estimada": "No contamos
    con una fecha estimada" niega desde más lejos que las otras construcciones).
    """
    previo = re.split(r"[.;:!?\n]", texto[:inicio])[-1]
    palabras = _palabras(previo)
    return any(p in NEGADORES for p in (palabras if ventana is None else palabras[-ventana:]))


def _huecos_historial(contexto: dict) -> tuple[set, set, set]:
    dias, dias_anio, horas = set(), set(), set()
    for h in contexto["historial"]:
        fecha, hora = h["fecha"].split(" ")
        anio, mes, dia = (int(x) for x in fecha.split("-"))
        dias.add((dia, mes))
        dias_anio.add((dia, mes, anio))
        horas.add(hora)
    return dias, dias_anio, horas


def _revisar_fechas(texto: str, contexto: dict) -> str:
    """Comprueba que toda fecha u hora citada exista en el historial. Devuelve el texto sin ellas."""
    dias, dias_anio, horas = _huecos_historial(contexto)

    def valida(d: int, m: int, a: int | None) -> bool:
        return (d, m, a) in dias_anio if a else (d, m) in dias

    def hallar(patron, ordenar):
        nonlocal texto
        for m in list(patron.finditer(texto)):
            d, mes, anio = ordenar(m)
            if not valida(d, mes, anio):
                raise SalidaInvalida("fecha_inventada")
        texto = patron.sub(" ", texto)

    hallar(RE_ISO, lambda m: (int(m[3]), int(m[2]), int(m[1])))
    hallar(RE_TEXTO, lambda m: (int(m[1]), MESES[m[2]], int(m[3]) if m[3] else None))
    hallar(RE_NUM, lambda m: (int(m[1]), int(m[2]), (int(m[3]) + (2000 if len(m[3]) == 2 else 0)) if m[3] else None))
    for m in RE_HORA.finditer(texto):
        if f"{int(m[1]):02d}:{m[2]}" not in horas:
            raise SalidaInvalida("hora_inventada")
    texto = RE_HORA.sub(" ", texto)
    if HORA_SUELTA.search(texto):
        raise SalidaInvalida("hora_inventada")
    return texto


def validar(salida: Salida, contexto: dict, sistema: str) -> None:
    """Lanza SalidaInvalida si el texto contradice a la base o rompe una regla."""
    texto = f"{salida.resumen}\n{salida.siguiente_paso}"
    if CARACTERES_PROHIBIDOS.search(texto):
        raise SalidaInvalida("caracteres_no_permitidos")
    bajo = texto.lower().replace(contexto["num_guia"].lower(), " ")  # la guía no es teléfono ni fecha

    if ENLACE.search(bajo):
        raise SalidaInvalida("enlace")
    if CORREO.search(bajo) or DINERO.search(bajo):
        raise SalidaInvalida("dato_sensible")
    if MARCAS_PROMPT.search(bajo) or _copia_el_prompt(bajo, sistema):
        raise SalidaInvalida("filtra_instrucciones")
    if sum(p in PALABRAS_ES for p in _palabras(bajo)) < 3:
        raise SalidaInvalida("idioma")

    # El estado: solo se pueden nombrar estados por los que el envío de verdad pasó.
    permitidos = {h["estado"] for h in contexto["historial"]} | {contexto["estado_actual"]}
    for estado, formas in FORMAS_ESTADO.items():
        if estado in permitidos:
            continue
        for m in re.finditer(formas, bajo):
            if not _negado(bajo, m.start()):
                raise SalidaInvalida("estado_incoherente")

    bajo = _revisar_fechas(bajo, contexto)
    if TELEFONO.search(bajo):
        raise SalidaInvalida("dato_sensible")
    for m in PLAZOS.finditer(bajo):
        ventana = None if m.group().startswith("estimad") else 4
        if not _negado(bajo, m.start(), ventana):
            raise SalidaInvalida("promesa_de_plazo")
    for patron in COMPROMISO_DINERO:
        for m in patron.finditer(bajo):
            if not _negado(bajo, m.start()):
                raise SalidaInvalida("promesa_de_dinero")


def _copia_el_prompt(texto: str, sistema: str, n: int = 8) -> bool:
    """¿Repite 8 palabras seguidas de las instrucciones? (así se detecta que las reveló)"""
    ref = _palabras(sistema)
    ngramas = {tuple(ref[i:i + n]) for i in range(len(ref) - n + 1)}
    pal = _palabras(texto)
    return any(tuple(pal[i:i + n]) in ngramas for i in range(len(pal) - n + 1))


def parsear_y_validar(texto: str, contexto: dict, sistema: str) -> Salida:
    salida = parsear(texto)
    validar(salida, contexto, sistema)
    return salida


# ---------------------------------------------------------------- 3. plantilla de respaldo
PLANTILLAS = {
    "creado": (
        "Tu envío ya fue registrado, pero todavía no ha sido recolectado.",
        "Cuando lo recolectemos, el estado cambiará en tu seguimiento. No contamos con una fecha estimada de entrega.",
    ),
    "recolectado": (
        "Tu envío ya fue recolectado.",
        "El siguiente paso es su traslado. No contamos con una fecha estimada de entrega.",
    ),
    "en_transito": (
        "Tu envío va en tránsito.",
        "El siguiente paso es que salga a reparto. No contamos con una fecha estimada de entrega.",
    ),
    "en_reparto": (
        "Tu envío está en reparto.",
        "El siguiente paso es la entrega. No contamos con una fecha ni una hora estimada de entrega.",
    ),
    "entregado": (
        "Tu envío fue entregado.",
        "Si hay algún problema con la entrega, comunícate con atención al cliente.",
    ),
    "fallido": (
        "Hubo un intento de entrega que no se pudo completar.",
        "Una persona de atención revisará tu caso para ver cómo continuar.",
    ),
}


def fecha_legible(fecha_iso: str) -> str:
    """'2026-10-04 23:20' -> '4 de octubre de 2026 a las 23:20' (así también la acepta el validador)."""
    dia, hora = fecha_iso.split(" ")
    anio, mes, d = (int(x) for x in dia.split("-"))
    return f"{d} de {MESES_TEXTO[mes - 1]} de {anio} a las {hora}"


def plantilla(contexto: dict) -> Salida:
    """Respuesta fija por estado, con la fecha del último movimiento tomada de la base."""
    resumen, siguiente = PLANTILLAS[contexto["estado_actual"]]
    if contexto["historial"]:
        resumen += f" Último movimiento registrado: {fecha_legible(contexto['historial'][-1]['fecha'])}."
    return Salida(resumen, siguiente, contexto["estado_actual"] == "fallido")
