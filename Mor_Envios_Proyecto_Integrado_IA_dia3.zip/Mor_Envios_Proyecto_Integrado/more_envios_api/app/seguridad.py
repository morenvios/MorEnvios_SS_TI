"""Autenticación por llave de API y límite de peticiones.

Las llaves viven en la variable de entorno API_KEYS, con el formato
    usuario1:llave1,usuario2:llave2
Cada llave está ligada a un nombre de usuario. Ese nombre es el que se guarda
en historial_estado.usuario_cambio: el cliente ya no lo puede inventar.
"""
import hmac
import os
import re
import time
from collections import deque

from fastapi import Header, HTTPException

NOMBRE_VALIDO = re.compile(r"^[A-Za-z0-9_.-]{1,50}$")
LARGO_MINIMO_LLAVE = 24


def cargar_llaves(texto: str | None) -> dict[str, str]:
    """Devuelve {llave: usuario}. Falla al arrancar si la configuración es mala."""
    if not texto or not texto.strip():
        raise RuntimeError("Falta API_KEYS (ver .env.example)")
    llaves: dict[str, str] = {}
    for par in texto.split(","):
        usuario, sep, llave = par.strip().partition(":")
        if not sep or not NOMBRE_VALIDO.match(usuario):
            raise RuntimeError("API_KEYS mal formada: usa usuario:llave,usuario:llave")
        if len(llave) < LARGO_MINIMO_LLAVE:
            raise RuntimeError(
                f"La llave de '{usuario}' es muy corta (mínimo {LARGO_MINIMO_LLAVE} caracteres)"
            )
        if "CAMBIAME" in llave.upper():
            raise RuntimeError(f"La llave de '{usuario}' sigue siendo la de ejemplo: genera una propia")
        if llave in llaves:
            raise RuntimeError("API_KEYS tiene una llave repetida")
        llaves[llave] = usuario
    return llaves


LLAVES = cargar_llaves(os.getenv("API_KEYS"))


def autenticar(x_api_key: str | None = Header(default=None)) -> str:
    """Dependencia: devuelve el usuario dueño de la llave o responde 401."""
    if x_api_key:
        recibida = x_api_key.encode("utf-8")
        usuario = None
        # se recorren todas las llaves siempre, para no filtrar cuál coincidió por tiempo
        for llave, nombre in LLAVES.items():
            if hmac.compare_digest(recibida, llave.encode("utf-8")):
                usuario = nombre
        if usuario:
            return usuario
    raise HTTPException(
        status_code=401,
        detail="Credenciales requeridas o inválidas",
        headers={"WWW-Authenticate": "ApiKey"},
    )


class LimitadorVentana:
    """Límite simple en memoria: máximo N peticiones por ventana, por cliente.

    Límite conocido: vive dentro de un solo proceso. Con varios workers o detrás
    de un proxy hay que poner el límite también en el proxy.
    """

    def __init__(self, maximo: int, ventana_seg: int = 60):
        self.maximo = maximo
        self.ventana = ventana_seg
        self._visitas: dict[str, deque] = {}

    def reiniciar(self) -> None:
        self._visitas.clear()

    def permitir(self, cliente: str) -> tuple[bool, int]:
        """Devuelve (permitido, segundos_para_reintentar)."""
        ahora = time.monotonic()
        cola = self._visitas.setdefault(cliente, deque())
        while cola and ahora - cola[0] > self.ventana:
            cola.popleft()
        if len(cola) >= self.maximo:
            return False, max(1, int(self.ventana - (ahora - cola[0])) + 1)
        cola.append(ahora)
        if len(self._visitas) > 10_000:  # limpieza para que el diccionario no crezca sin fin
            for k in [k for k, v in self._visitas.items() if not v or ahora - v[-1] > self.ventana]:
                del self._visitas[k]
        return True, 0


limitador = LimitadorVentana(maximo=int(os.getenv("LIMITE_PETICIONES_POR_MIN", "60")))
