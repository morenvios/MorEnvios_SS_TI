"""Lógica transaccional: cambio de estado de un envío.

Una sola transacción hace tres cosas:
  1. UPDATE envio.estado_actual
  2. (opcional) UPDATE envio.id_repartidor
  3. INSERT en historial_estado
Si cualquiera falla, se hace ROLLBACK de todo.
"""
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

TRANSICIONES = {
    "creado": {"recolectado"},
    "recolectado": {"en_transito"},
    "en_transito": {"en_reparto"},
    "en_reparto": {"entregado", "fallido"},
    "fallido": {"en_reparto"},
    "entregado": set(),
}


class ErrorNegocio(Exception):
    status_code = 400
    headers: dict | None = None  # p. ej. Retry-After en un 429

    def __init__(self, detalle: str):
        super().__init__(detalle)
        self.detalle = detalle


class NoEncontrado(ErrorNegocio):
    status_code = 404


class TransicionInvalida(ErrorNegocio):
    status_code = 409


class ReferenciaInvalida(ErrorNegocio):
    status_code = 409


def cambiar_estado(
    db: Session,
    num_guia: str,
    nuevo_estado: str,
    usuario: str,
    id_repartidor: int | None = None,
) -> dict:
    try:
        # FOR UPDATE bloquea la fila: dos peticiones simultáneas sobre el
        # mismo envío se atienden una tras otra.
        envio = db.execute(
            text(
                "SELECT id_envio, estado_actual, id_repartidor, id_zona_origen "
                "FROM envio WHERE num_guia = :guia FOR UPDATE"
            ),
            {"guia": num_guia},
        ).mappings().first()
        if envio is None:
            raise NoEncontrado(f"No existe el envío {num_guia}")

        actual = envio["estado_actual"]
        if nuevo_estado not in TRANSICIONES.get(actual, set()):
            raise TransicionInvalida(
                f"No se puede pasar de '{actual}' a '{nuevo_estado}'"
            )

        repartidor_final = envio["id_repartidor"]
        if id_repartidor is not None:
            repartidor = db.execute(
                text("SELECT id_zona FROM repartidor WHERE id_repartidor = :id"),
                {"id": id_repartidor},
            ).mappings().first()
            if repartidor is None:
                raise ReferenciaInvalida(f"No existe el repartidor {id_repartidor}")
            if repartidor["id_zona"] != envio["id_zona_origen"]:
                raise ReferenciaInvalida(
                    "El repartidor no pertenece a la zona de origen del envío"
                )
            repartidor_final = id_repartidor

        db.execute(
            text("UPDATE envio SET estado_actual = :e WHERE id_envio = :id"),
            {"e": nuevo_estado, "id": envio["id_envio"]},
        )
        if id_repartidor is not None:
            db.execute(
                text(
                    "UPDATE envio SET id_repartidor = :r WHERE id_envio = :id"
                ),
                {"r": id_repartidor, "id": envio["id_envio"]},
            )
        db.execute(
            text(
                "INSERT INTO historial_estado "
                "(id_envio, estado, fecha_cambio, usuario_cambio) "
                "VALUES (:id, :e, now(), :u)"
            ),
            {"id": envio["id_envio"], "e": nuevo_estado, "u": usuario},
        )
        db.commit()
        return {
            "num_guia": num_guia,
            "estado_anterior": actual,
            "estado_actual": nuevo_estado,
            "id_repartidor": repartidor_final,
        }
    except IntegrityError as exc:
        db.rollback()
        raise ReferenciaInvalida(
            "Violación de integridad (repartidor inexistente o dato inválido)"
        ) from exc
    except Exception:
        db.rollback()
        raise
