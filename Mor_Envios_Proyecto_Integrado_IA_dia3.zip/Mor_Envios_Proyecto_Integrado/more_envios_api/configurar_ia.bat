@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: No existe .venv. Ejecuta primero configurar_entorno.bat.
  pause
  exit /b 1
)
REM Pide la clave del proveedor sin mostrarla y la guarda solo en .env
REM (para apagar la IA:  configurar_ia.bat --apagar)
".venv\Scripts\python.exe" configurar_ia.py %*
pause
