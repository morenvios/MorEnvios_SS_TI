"""Activa la explicacion con IA guardando la clave del proveedor en .env SIN mostrarla.

Por que existe: pegar la clave en un comando (o en un chat, o en un archivo que se
sube por error) es la forma mas comun de filtrarla. Aqui se pide con getpass (no se
ve al escribir ni queda en el historial de la terminal), se valida con las mismas
reglas que usa la API al arrancar y se escribe solo en .env.

Uso:  python configurar_ia.py          (activa y guarda la clave)
      python configurar_ia.py --apagar (pone IA_HABILITADA=0; la clave se queda guardada)
"""
import getpass
import os
import sys
from pathlib import Path

from app.config_ia import cargar_config_ia


def _actualizar(lineas: list[str], nombre: str, valor: str) -> list[str]:
    nueva, hecho = [], False
    for linea in lineas:
        if linea.startswith(f"{nombre}="):
            nueva.append(f"{nombre}={valor}")
            hecho = True
        else:
            nueva.append(linea)
    if not hecho:
        nueva.append(f"{nombre}={valor}")
    return nueva


def configurar(env_path: Path, clave: str | None, habilitar: bool = True) -> None:
    """Escribe IA_HABILITADA (y la clave, si se da). Valida ANTES de escribir nada."""
    lineas = env_path.read_text(encoding="utf-8").splitlines()
    if habilitar:
        actuales = {k: v for k, _, v in (l.partition("=") for l in lineas)}
        propuesta = {**actuales, "IA_HABILITADA": "1", **({"IA_API_KEY": clave} if clave else {})}
        cargar_config_ia(propuesta)  # lanza RuntimeError (sin mostrar la clave) si algo esta mal
    if clave:
        lineas = _actualizar(lineas, "IA_API_KEY", clave)
    lineas = _actualizar(lineas, "IA_HABILITADA", "1" if habilitar else "0")
    env_path.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    try:
        os.chmod(env_path, 0o600)  # en Linux/Mac: solo tu usuario lo lee (en Windows no aplica)
    except OSError:
        pass


def main() -> int:
    env_path = Path(__file__).resolve().parent / ".env"
    if not env_path.exists():
        print("No existe .env. Ejecuta primero configurar_entorno.bat.")
        return 1
    try:
        if "--apagar" in sys.argv:
            configurar(env_path, None, habilitar=False)
            print("IA apagada (IA_HABILITADA=0).")
            return 0
        clave = getpass.getpass("Pega la clave del proveedor de IA (no se mostrara): ").strip()
        configurar(env_path, clave, habilitar=True)
    except RuntimeError as exc:
        print(f"No se guardo nada: {exc}")
        return 1
    print("Listo: IA_HABILITADA=1 y la clave quedo guardada solo en .env. Reinicia la API.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
