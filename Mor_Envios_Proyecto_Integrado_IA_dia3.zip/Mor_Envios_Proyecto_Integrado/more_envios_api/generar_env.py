"""Crea .env a partir de .env.example con una llave de API aleatoria (no pisa un .env existente).

La parte de IA queda APAGADA (IA_HABILITADA=0). Para activarla: configurar_ia.bat.
"""
import secrets
from pathlib import Path


def generar(base: Path) -> str:
    destino, modelo = base / ".env", base / ".env.example"
    if destino.exists():
        return ".env ya existe, no se modifica."
    lineas = []
    for linea in modelo.read_text(encoding="utf-8").splitlines():
        if linea.startswith("API_KEYS="):
            linea = f"API_KEYS=operador1:{secrets.token_urlsafe(32)}"
        lineas.append(linea)
    destino.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    return ("Creado .env con una llave aleatoria. Falta poner la contrasena de la base en DATABASE_URL. "
            "La IA queda apagada; para activarla usa configurar_ia.bat.")


if __name__ == "__main__":
    print(generar(Path(__file__).resolve().parent))
