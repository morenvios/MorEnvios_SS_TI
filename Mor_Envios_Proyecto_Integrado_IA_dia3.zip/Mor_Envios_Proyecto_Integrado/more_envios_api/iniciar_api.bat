@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: No existe .venv. Ejecuta primero configurar_entorno.bat.
  pause
  exit /b 1
)
if not exist ".env" (
  echo ERROR: No existe .env. Ejecuta configurar_entorno.bat.
  pause
  exit /b 1
)
REM Solo escucha en esta computadora (127.0.0.1). Sin --reload: eso es solo para desarrollar.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
