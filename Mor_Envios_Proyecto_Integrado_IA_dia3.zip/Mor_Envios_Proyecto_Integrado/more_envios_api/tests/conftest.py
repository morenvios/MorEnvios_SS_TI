"""Pruebas contra la base real, sin dejar rastro.

Cada prueba corre dentro de una transacción externa que se revierte al final.
Los commit() del código se convierten en SAVEPOINT (create_savepoint), así que
el rollback del servicio también se puede comprobar.
Usa una base de pruebas: export DATABASE_URL=...more_envios_test
"""
import os

# Llave fija solo para pruebas; debe fijarse ANTES de importar la app.
LLAVE_PRUEBAS = "llave-de-pruebas-0123456789abcdef"
os.environ["API_KEYS"] = f"pruebas:{LLAVE_PRUEBAS}"

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.db import engine, get_db
from app.main import app
from app.seguridad import limitador


@pytest.fixture
def db():
    conn = engine.connect()
    trans = conn.begin()
    session = Session(bind=conn, join_transaction_mode="create_savepoint")
    yield session
    session.close()
    trans.rollback()
    conn.close()


@pytest.fixture(autouse=True)
def limitador_limpio():
    """Cada prueba arranca con el contador de peticiones en cero."""
    maximo = limitador.maximo
    limitador.reiniciar()
    yield
    limitador.maximo = maximo
    limitador.reiniciar()


@pytest.fixture
def client(db):
    """Cliente CON llave valida (lo normal)."""
    app.dependency_overrides[get_db] = lambda: db
    yield TestClient(app, headers={"X-API-Key": LLAVE_PRUEBAS})
    app.dependency_overrides.clear()


@pytest.fixture
def client_sin_llave(db):
    """Cliente anonimo, para comprobar que la API lo rechaza."""
    app.dependency_overrides[get_db] = lambda: db
    yield TestClient(app)
    app.dependency_overrides.clear()
