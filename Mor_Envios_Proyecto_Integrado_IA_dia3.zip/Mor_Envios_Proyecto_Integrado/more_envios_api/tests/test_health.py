"""Salud y documentación: /health no pide llave, /docs está apagado por defecto."""


def test_health_sin_llave(client_sin_llave):
    r = client_sin_llave.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_health_db_sin_llave(client_sin_llave):
    r = client_sin_llave.get("/health/db")
    assert r.status_code == 200
    assert r.json()["database"] == "connected"


def test_health_no_expone_version_ni_detalles(client_sin_llave):
    cuerpo = client_sin_llave.get("/health").text.lower()
    assert "version" not in cuerpo and "postgres" not in cuerpo


def test_docs_apagados_por_defecto(client_sin_llave):
    for ruta in ("/docs", "/redoc", "/openapi.json"):
        assert client_sin_llave.get(ruta).status_code == 404


def test_rutas_de_negocio_siguen_pidiendo_llave(client_sin_llave):
    assert client_sin_llave.get("/envios").status_code == 401
