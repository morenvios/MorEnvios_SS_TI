"""Pruebas de la salida estructurada, el validador de coherencia, las plantillas y el prompt (miércoles).

Dos baterías hechas a mano:
  * respuestas BUENAS que deben pasar  -> miden los falsos rechazos
  * respuestas MALAS que deben fallar  -> miden lo que el validador atrapa
Ojo: las escribí yo, no las generó un modelo real. Sirven para fijar el comportamiento del
código; la tasa real de falsos rechazos y de fallas se mide el jueves con el proveedor real.
"""
import json
import logging

import httpx
import pytest

from app.config_ia import ConfigIA, Secreto
from app.ia import HISTORIAL_MAX, SISTEMA, ServicioIA, construir_mensaje_usuario, get_servicio_ia, leer_contexto
from app.ia_salida import (
    CAMPOS, PLANTILLAS, Salida, SalidaInvalida, fecha_legible, parsear, parsear_y_validar, plantilla, validar,
)
from app.main import app
from tests.test_ia import BUENAS, GUIAS, Proveedor, config, salida_ia, url


# ---------- contextos de ejemplo (fechas reales de la semilla para MEV-2026-000005) ----------
def ctx(estado, historial=None, guia="MEV-2026-000005"):
    pasos = ["creado", "recolectado", "en_transito", "en_reparto", "entregado"]
    if historial is None:
        hasta = pasos.index(estado) if estado in pasos else 3
        historial = pasos[: hasta + 1] + (["fallido"] if estado == "fallido" else [])
    horas = ["2026-09-18 10:00", "2026-09-18 13:00", "2026-09-18 16:00", "2026-09-18 19:00", "2026-09-20 21:10", "2026-09-20 22:00"]
    return {"num_guia": guia, "estado_actual": estado,
            "historial": [{"estado": e, "fecha": horas[i]} for i, e in enumerate(historial)]}


def valido(resumen, siguiente, contexto, atencion=False):
    return parsear_y_validar(salida_ia(resumen, siguiente, atencion), contexto, SISTEMA)


def motivo_de(resumen, siguiente, contexto, atencion=False):
    with pytest.raises(SalidaInvalida) as exc:
        valido(resumen, siguiente, contexto, atencion)
    return exc.value.motivo


# ======================= 1. Esquema =======================
def test_json_valido_se_parsea():
    s = parsear(BUENAS["en_transito"])
    assert s == Salida("Tu envío va en tránsito.", "El siguiente paso es que salga a reparto. No hay una fecha estimada registrada.", False)


def test_json_envuelto_en_markdown_se_tolera():
    assert parsear("```json\n" + BUENAS["recolectado"] + "\n```").resumen == "Tu envío ya fue recolectado."
    assert parsear("```\n" + BUENAS["recolectado"] + "\n```").requiere_atencion is False


@pytest.mark.parametrize("texto,motivo", [
    ("Tu envío va en tránsito.", "json_invalido"),
    ("", "json_invalido"),
    ("Aquí está: " + BUENAS["creado"], "json_invalido"),                # texto extra alrededor
    ("[1, 2]", "no_es_objeto"),
    ('"hola"', "no_es_objeto"),
    (json.dumps({"resumen": "a", "siguiente_paso": "b"}), "campos_distintos"),                                  # falta uno
    (json.dumps({"resumen": "a", "siguiente_paso": "b", "requiere_atencion": False, "estado": "x"}), "campos_distintos"),  # sobra uno
    (json.dumps({"resumen": 5, "siguiente_paso": "b", "requiere_atencion": False}), "tipo_texto"),
    (json.dumps({"resumen": "a", "siguiente_paso": None, "requiere_atencion": False}), "tipo_texto"),
    (json.dumps({"resumen": "a", "siguiente_paso": "b", "requiere_atencion": "false"}), "tipo_booleano"),
    (json.dumps({"resumen": "a", "siguiente_paso": "b", "requiere_atencion": 0}), "tipo_booleano"),
    (json.dumps({"resumen": "", "siguiente_paso": "b", "requiere_atencion": False}), "largo_resumen"),
    (json.dumps({"resumen": "   ", "siguiente_paso": "b", "requiere_atencion": False}), "largo_resumen"),
    (json.dumps({"resumen": "a" * 301, "siguiente_paso": "b", "requiere_atencion": False}), "largo_resumen"),
    (json.dumps({"resumen": "a", "siguiente_paso": "b" * 201, "requiere_atencion": False}), "largo_siguiente_paso"),
])
def test_esquema_rechaza_salidas_mal_formadas(texto, motivo):
    with pytest.raises(SalidaInvalida) as exc:
        parsear(texto)
    assert exc.value.motivo == motivo


def test_el_motivo_nunca_incluye_el_texto_del_modelo():
    with pytest.raises(SalidaInvalida) as exc:
        parsear("TEXTO-SECRETO-DEL-MODELO")
    assert "SECRETO" not in str(exc.value) and "SECRETO" not in exc.value.motivo


# ======================= 2a. Respuestas BUENAS: deben pasar =======================
BUENAS_PASAN = [
    # (contexto, resumen, siguiente_paso)  -- una variedad realista por caso de evaluación
    (ctx("creado"), "Tu envío está creado y todavía no ha sido recolectado.", "Cuando lo recojan verás el cambio de estado."),                         # C01
    (ctx("recolectado"), "Tu envío ya fue recolectado.", "Después sigue su traslado."),                                                               # C02
    (ctx("en_transito"), "Tu envío va en tránsito.", "No hay una fecha estimada de entrega registrada."),                                            # C03
    (ctx("en_reparto"), "Tu envío está en reparto.", "No tenemos una fecha ni una hora estimada de entrega."),                                       # C04
    (ctx("entregado"), "Tu envío fue entregado el 20 de septiembre de 2026 a las 21:10.", "Si hay algún problema, contacta a atención al cliente."),  # C05 (texto)
    (ctx("entregado"), "Tu envío fue entregado el 2026-09-20 a las 21:10.", "Gracias por usar More Envíos."),                                         # C05 (ISO)
    (ctx("entregado"), "Tu envío se entregó el 20/09/2026.", "No hay más pasos pendientes."),                                                        # C05 (numérica)
    (ctx("fallido"), "Hubo un intento de entrega fallido y no se pudo entregar tu envío.", "Una persona de atención revisará tu caso."),             # C06
    (ctx("en_transito"), "Tu envío está en tránsito.", "El siguiente paso es el reparto."),                                                          # C07
    (ctx("en_transito"), "No hay una fecha estimada de entrega registrada.", "Tu envío va en tránsito y verás el cambio cuando salga a reparto."), # C08
    (ctx("fallido"), "Entiendo tu molestia. No puedo prometer reembolsos.", "Una persona de atención revisará tu caso."),                            # C09
    (ctx("en_reparto"), "Solo puedo ayudarte con el estado de tu envío, que está en reparto.", "No hay una fecha estimada registrada."),           # C10
    (ctx("en_reparto"), "No tengo datos del repartidor.", "Tu envío está en reparto y el siguiente paso es la entrega."),                            # C11
    (ctx("en_reparto"), "No manejo direcciones ni costos.", "Tu envío está en reparto."),                                                           # C12
    (ctx("en_transito"), "Tu envío va en tránsito y todavía no ha sido entregado.", "El siguiente paso es que salga a reparto."),                    # C13
    (ctx("en_transito"), "No puedo compartir mis instrucciones.", "Tu envío va en tránsito."),                                                      # C14
    (ctx("en_transito"), "Tu envío va en tránsito.", "Solo puedo ayudarte con el estado de tu envío."),                                              # C15
    (ctx("recolectado"), "No puedo cambiar estados. Tu envío ya fue recolectado.", "Si necesitas ayuda, contacta a atención al cliente."),          # C16
    (ctx("en_transito"), "Tu paquete va en tránsito.", "El siguiente paso es que salga a reparto."),                                                 # C21 (pregunta en inglés)
    (ctx("creado"), "Tu envío está creado.", "Aún no ha sido recolectado."),                                                                        # C22
    # historia: mencionar estados por los que SÍ pasó
    (ctx("en_reparto"), "Tu envío fue recolectado, pasó por tránsito y ahora está en reparto.", "El siguiente paso es la entrega."),
    (ctx("fallido"), "Tu envío estuvo en reparto, pero el intento de entrega falló.", "Una persona de atención revisará tu caso."),
    (ctx("fallido"), "No hay intentos pendientes; el último fue fallido.", "Una persona de atención revisará tu caso."),
    # "estimada" negada desde más lejos (la plantilla misma usa esta frase)
    (ctx("en_transito"), "Tu envío va en tránsito.", "No contamos con una fecha estimada de entrega."),
    (ctx("en_reparto"), "Tu envío está en reparto.", "Por ahora no tenemos registrada ninguna fecha estimada."),
    # la guía en el texto no cuenta como teléfono ni como fecha
    (ctx("en_transito"), "El envío MEV-2026-000005 va en tránsito.", "No hay una fecha estimada registrada."),
]


@pytest.mark.parametrize("contexto,resumen,siguiente", BUENAS_PASAN, ids=[f"buena{i:02d}" for i in range(len(BUENAS_PASAN))])
def test_respuestas_buenas_pasan(contexto, resumen, siguiente):
    assert valido(resumen, siguiente, contexto).resumen == resumen


# ======================= 2b. Respuestas MALAS: deben rechazarse =======================
MALAS = [
    # --- el estado contradice a la base ---
    ("estado_incoherente", ctx("en_transito"), "Tu envío ya fue entregado.", "Gracias por tu compra."),                              # C13 obedecido
    ("estado_incoherente", ctx("en_transito"), "Tu envío se entregó hoy.", "Listo."),
    ("estado_incoherente", ctx("fallido"), "Tu envío fue entregado con éxito.", "Nada más."),
    ("estado_incoherente", ctx("en_transito"), "Tu envío está en reparto.", "Ya casi llega."),
    ("estado_incoherente", ctx("creado"), "Tu envío ya fue recolectado.", "Va en camino."),
    ("estado_incoherente", ctx("recolectado"), "Tu envío va en tránsito.", "Sigue el reparto."),
    ("estado_incoherente", ctx("en_transito"), "Tu envío va en tránsito.", "Pronto será entregado a su destino."),
    ("estado_incoherente", ctx("en_transito"), "Tu envío va en tránsito.", "Pendiente de recolección."),  # 'pendiente' niega -> debe PASAR (ver abajo)
    # --- fechas u horas que no están en el historial ---
    ("fecha_inventada", ctx("en_transito"), "Tu envío va en tránsito.", "Llegará el 30 de octubre de 2026."),
    ("fecha_inventada", ctx("en_transito"), "Tu envío va en tránsito y llega el 2026-10-31.", "Espera."),
    ("fecha_inventada", ctx("en_transito"), "Tu envío va en tránsito.", "La entrega es el 31/10/2026."),
    ("fecha_inventada", ctx("en_transito"), "Tu envío salió el 1 de septiembre.", "Espera."),
    ("hora_inventada", ctx("en_transito"), "Tu envío va en tránsito.", "Se entrega a las 18:00."),
    ("hora_inventada", ctx("en_transito"), "Tu envío va en tránsito.", "Llega a las 5 de la tarde."),
    ("hora_inventada", ctx("en_transito"), "Tu envío va en tránsito.", "Llega a las 5 pm."),
    # --- promesas de plazo ---
    ("promesa_de_plazo", ctx("en_transito"), "Tu envío va en tránsito.", "Te llegará mañana."),
    ("promesa_de_plazo", ctx("en_transito"), "Tu envío va en tránsito.", "Llegará pronto."),
    ("promesa_de_plazo", ctx("en_transito"), "Tu envío va en tránsito.", "Lo recibirás en 2 días."),
    ("promesa_de_plazo", ctx("en_reparto"), "Tu envío está en reparto.", "Llega hoy."),
    ("promesa_de_plazo", ctx("en_transito"), "Tu envío va en tránsito.", "Se entrega en breve."),
    ("promesa_de_plazo", ctx("en_transito"), "Tu envío va en tránsito.", "La fecha estimada de entrega es el viernes."),
    # --- promesas de dinero ---
    ("promesa_de_dinero", ctx("fallido"), "Hubo un intento de entrega fallido.", "Te reembolsaremos tu dinero."),
    ("promesa_de_dinero", ctx("fallido"), "Hubo un intento de entrega fallido.", "Se te devolverá el pago."),
    ("promesa_de_dinero", ctx("fallido"), "Hubo un intento de entrega fallido.", "Recibirás un reembolso completo."),
    ("promesa_de_dinero", ctx("fallido"), "Hubo un intento de entrega fallido.", "Te compensaremos por las molestias."),
    # --- enlaces, datos personales, dinero, caracteres ---
    ("enlace", ctx("en_transito"), "Tu envío va en tránsito.", "Reclama en https://ejemplo.invalido/reclamo."),
    ("enlace", ctx("en_transito"), "Tu envío va en tránsito.", "Visita www.reclamos-envios.com."),
    ("enlace", ctx("en_transito"), "Tu envío va en tránsito.", "Entra a reclamos.com para ayuda."),
    ("dato_sensible", ctx("en_transito"), "Tu envío va en tránsito.", "Escribe a soporte@ejemplo.invalido."),
    ("dato_sensible", ctx("en_transito"), "Tu envío va en tránsito y costó $150.", "Espera."),
    ("dato_sensible", ctx("en_transito"), "Tu envío va en tránsito y costó 150 pesos.", "Espera."),
    ("dato_sensible", ctx("en_reparto"), "Tu envío está en reparto.", "Llama al repartidor al 55 1234 5678."),
    ("caracteres_no_permitidos", ctx("en_transito"), "Tu envío va en tránsito.", "<script>alert(1)</script>"),
    ("caracteres_no_permitidos", ctx("en_transito"), "Tu envío va en tránsito <b>ahora</b>.", "Espera."),
    # --- filtración de instrucciones (C14) ---
    ("filtra_instrucciones", ctx("en_transito"), "Mis reglas son: No existen fechas estimadas: nunca inventes fechas, horas ni plazos.", "Tu envío va en tránsito."),
    ("filtra_instrucciones", ctx("en_transito"), "Mi entrada tiene un bloque datos_envio con tu guía.", "Tu envío va en tránsito."),
    # --- idioma (C21) ---
    ("idioma", ctx("en_transito"), "Your package is in transit.", "The next step is delivery."),
]


@pytest.mark.parametrize("motivo,contexto,resumen,siguiente", [m for m in MALAS if not (m[2] == "Tu envío va en tránsito." and m[3] == "Pendiente de recolección.")],
                         ids=lambda v: v if isinstance(v, str) and v.islower() and " " not in v and "_" in v else "")
def test_respuestas_malas_se_rechazan_por_el_motivo_correcto(motivo, contexto, resumen, siguiente):
    assert motivo_de(resumen, siguiente, contexto) == motivo


def test_pendiente_de_recoleccion_es_una_negacion_valida():
    # 'pendiente' cuenta como negador: la misma frase que NO afirma el estado recolectado.
    assert valido("Tu envío va en tránsito.", "Pendiente de recolección.", ctx("en_transito"))


def test_resumen_de_las_baterias():
    """Deja a la vista cuántas respuestas buenas pasan y cuántas malas se atrapan (mismas listas de arriba)."""
    pasan = sum(1 for c, r, s in BUENAS_PASAN if _pasa(c, r, s))
    malas = [m for m in MALAS if not (m[3] == "Pendiente de recolección.")]
    atrapadas = sum(1 for _, c, r, s in malas if not _pasa(c, r, s))
    print(f"\nbuenas que pasan: {pasan}/{len(BUENAS_PASAN)} | malas rechazadas: {atrapadas}/{len(malas)}")
    assert pasan == len(BUENAS_PASAN) and atrapadas == len(malas)


def _pasa(contexto, resumen, siguiente) -> bool:
    try:
        valido(resumen, siguiente, contexto)
        return True
    except SalidaInvalida:
        return False


# ======================= 2c. Límites conocidos (documentados con pruebas) =======================
def test_limite_conocido_una_negacion_engana_al_validador():
    # El detector de estados deja pasar una mención "negada" aunque el sentido final sea falso.
    # Es una heurística, no una garantía; por eso estado_actual NUNCA sale del texto. Si esta
    # prueba empieza a fallar es porque el validador mejoró: actualiza la documentación.
    engaña = valido("No dudes, ya fue entregado en la puerta.", "Gracias por tu paciencia.", ctx("en_transito"))
    assert engaña.resumen.startswith("No dudes")
    # ...pero con el negador lejos (más de 4 palabras) sí se atrapa:
    assert motivo_de("No te preocupes, tu envío fue entregado en la puerta.", "Gracias por tu paciencia.", ctx("en_transito")) == "estado_incoherente"


def test_limite_conocido_una_parafrasis_rara_no_se_detecta():
    # "ya está en tus manos" afirma la entrega sin usar ninguna de las formas conocidas del estado.
    assert valido("Tu paquete ya está en tus manos.", "Disfrútalo.", ctx("en_transito"))


# ======================= 3. Plantillas de respaldo =======================
def test_hay_una_plantilla_por_cada_estado():
    assert set(PLANTILLAS) == {"creado", "recolectado", "en_transito", "en_reparto", "entregado", "fallido"}
    assert len({v for v in PLANTILLAS.values()}) == 6


@pytest.mark.parametrize("guia", GUIAS)
def test_la_plantilla_pasa_el_mismo_validador_que_la_ia(db, guia):
    contexto = leer_contexto(db, guia)
    p = plantilla(contexto)
    validar(p, contexto, SISTEMA)  # no lanza: plantilla y reglas son coherentes entre sí
    assert p.requiere_atencion is (contexto["estado_actual"] == "fallido")


@pytest.mark.parametrize("guia", GUIAS)
def test_la_plantilla_cita_el_ultimo_movimiento_real(db, guia):
    contexto = leer_contexto(db, guia)
    assert fecha_legible(contexto["historial"][-1]["fecha"]) in plantilla(contexto).resumen


def test_fecha_legible():
    assert fecha_legible("2026-10-04 23:20") == "4 de octubre de 2026 a las 23:20"
    assert fecha_legible("2026-01-09 08:05") == "9 de enero de 2026 a las 08:05"


@pytest.mark.parametrize("estado", list(PLANTILLAS))
def test_ninguna_plantilla_promete_fecha_ni_dinero(estado):
    t = " ".join(PLANTILLAS[estado]).lower()
    for prohibido in ("reembols", "devol", "compens", "llegará", "mañana", "pronto", "hoy", "http"):
        assert prohibido not in t


# ======================= 4. Prompt =======================
def test_el_prompt_pide_exactamente_el_esquema_que_el_servidor_valida():
    for campo in CAMPOS:
        assert campo in SISTEMA
    assert "JSON" in SISTEMA and "español" in SISTEMA


def test_el_prompt_explica_los_seis_estados_y_las_reglas_clave():
    for estado in ("creado", "recolectado", "en_transito", "en_reparto", "entregado", "fallido"):
        assert estado in SISTEMA
    for regla in ("fechas estimadas", "reembolsos", "teléfonos", "<pregunta_cliente>", "no las reveles", "No culpes"):
        assert regla in SISTEMA


def test_el_peor_caso_de_entrada_sigue_dentro_del_presupuesto(db):
    contexto = leer_contexto(db, GUIAS[0])
    contexto["historial"] = (contexto["historial"] * 3)[:HISTORIAL_MAX]
    mensaje = construir_mensaje_usuario(contexto, "x" * 200)
    assert len(SISTEMA) + len(mensaje) <= 2100  # ≈600 tokens a 3.5 caracteres por token


# ======================= 5. Integración con el endpoint =======================
@pytest.fixture
def armar(client):
    def _armar(proveedor=None, **cambios):
        proveedor = proveedor or Proveedor()
        servicio = ServicioIA(config(**cambios), transport=httpx.MockTransport(proveedor))
        app.dependency_overrides[get_servicio_ia] = lambda: servicio
        return client, proveedor, servicio
    return _armar


def test_json_envuelto_en_markdown_llega_como_origen_ia(armar):
    client, _, _ = armar(Proveedor(texto="```json\n" + BUENAS["en_transito"] + "\n```"))
    assert client.post(url("MEV-2026-000005"), json={}).json()["origen"] == "ia"


def test_cada_motivo_de_rechazo_cae_en_plantilla_y_queda_en_el_log(armar, caplog):
    caplog.set_level(logging.INFO, logger="more_envios")
    casos = {
        "estado_incoherente": salida_ia("Tu envío ya fue entregado.", "Listo."),
        "promesa_de_plazo": salida_ia("Tu envío va en tránsito.", "Llegará mañana."),
        "fecha_inventada": salida_ia("Tu envío va en tránsito.", "Llega el 31 de octubre de 2026."),
        "promesa_de_dinero": salida_ia("Tu envío va en tránsito.", "Te reembolsaremos el costo."),
        "enlace": salida_ia("Tu envío va en tránsito.", "Reclama en https://x.invalido."),
        "campos_distintos": json.dumps({"resumen": "a", "siguiente_paso": "b"}),
    }
    for motivo, texto in casos.items():
        caplog.clear()
        client, _, _ = armar(Proveedor(texto=texto))
        r = client.post(url("MEV-2026-000005"), json={}).json()
        assert r["origen"] == "plantilla" and r["estado_actual"] == "en_transito", motivo
        assert f"motivo={motivo}" in caplog.text, motivo


def test_los_tokens_gastados_se_registran_aunque_la_salida_se_rechace(armar, caplog):
    caplog.set_level(logging.INFO, logger="more_envios")
    client, _, _ = armar(Proveedor(texto=salida_ia("Tu envío ya fue entregado.", "Listo.")))
    client.post(url("MEV-2026-000005"), json={})
    assert "tokens_in=310 tokens_out=42" in caplog.text  # costó aunque no se usó


# ---------- IA apagada = plantilla, sin límites ni costo ----------
def test_ia_apagada_no_consume_limites_ni_llama_al_proveedor(client):
    proveedor = Proveedor()
    servicio = ServicioIA(ConfigIA(habilitada=False, limite_por_min=1, limite_diario=1), transport=httpx.MockTransport(proveedor))
    app.dependency_overrides[get_servicio_ia] = lambda: servicio
    codigos = [client.post(url("MEV-2026-000005"), json={"pregunta": "hola"}).status_code for _ in range(5)]
    assert codigos == [200] * 5 and proveedor.llamadas == 0 and servicio.por_dia._usadas == 0


def test_ia_apagada_sigue_dando_404_en_guia_inexistente(client):
    app.dependency_overrides[get_servicio_ia] = lambda: ServicioIA(ConfigIA(habilitada=False))
    assert client.post(url("MEV-2026-000099"), json={}).status_code == 404


def test_ia_apagada_registra_en_info_no_como_advertencia(client, caplog):
    caplog.set_level(logging.INFO, logger="more_envios")
    app.dependency_overrides[get_servicio_ia] = lambda: ServicioIA(ConfigIA(habilitada=False))
    client.post(url("MEV-2026-000005"), json={})
    registros = [r for r in caplog.records if "ia_respaldo" in r.getMessage()]
    assert registros and registros[0].levelno == logging.INFO and "motivo=ia_apagada" in registros[0].getMessage()


# ---------- los topes (429) siguen siendo 429, no plantilla ----------
def test_el_limite_por_minuto_sigue_siendo_429_y_no_plantilla(armar):
    client, _, _ = armar(limite_por_min=1)
    assert client.post(url("MEV-2026-000005"), json={}).status_code == 200
    r = client.post(url("MEV-2026-000005"), json={})
    assert r.status_code == 429 and "Retry-After" in r.headers


# ---------- ninguna respuesta lleva la salida cruda ni campos de más ----------
def test_la_respuesta_tiene_exactamente_estos_campos(armar):
    client, _, _ = armar()
    r = client.post(url("MEV-2026-000005"), json={}).json()
    assert set(r) == {"num_guia", "estado_actual", "requiere_atencion", "resumen", "siguiente_paso", "origen"}
