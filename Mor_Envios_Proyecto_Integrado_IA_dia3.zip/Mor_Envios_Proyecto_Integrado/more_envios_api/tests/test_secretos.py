"""Pruebas de la gestión de secretos: nada de claves en el repo, ni en el navegador.

Incluye pruebas del propio escáner (que detecte lo que debe y no dé falsas alarmas),
del asistente que guarda la clave en .env y del generador de .env.
"""
import stat
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[2]  # carpeta del proyecto (la que tiene escanear_secretos.py)
sys.path.insert(0, str(RAIZ))

import generar_env  # noqa: E402  (carpeta de la API, ya en sys.path por pytest)
from configurar_ia import configurar  # noqa: E402
from escanear_secretos import escanear  # noqa: E402

from app.config_ia import cargar_config_ia  # noqa: E402

# Se arma por partes para que ESTE archivo no contenga una clave con forma real.
CLAVE_FALSA = "sk-" + "ant-" + "api03-" + "A" * 30


def _leer_env(texto: str) -> dict:
    return {k: v for k, _, v in (l.partition("=") for l in texto.splitlines() if "=" in l and not l.startswith("#"))}


# ---------- El proyecto real ----------
def test_el_proyecto_no_tiene_claves_ni_usos_indebidos():
    assert [str(h) for h in escanear(RAIZ)] == []


def test_env_example_deja_la_ia_apagada_y_sin_clave_real():
    env = _leer_env((RAIZ / "more_envios_api" / ".env.example").read_text(encoding="utf-8"))
    assert env["IA_HABILITADA"] == "0"
    assert "CAMBIAME" in env["IA_API_KEY"]
    assert cargar_config_ia(env).habilitada is False
    with pytest.raises(RuntimeError):  # si alguien enciende la IA sin poner su clave, no arranca
        cargar_config_ia({**env, "IA_HABILITADA": "1"})


def test_el_env_real_esta_en_gitignore():
    gitignore = (RAIZ / ".gitignore").read_text(encoding="utf-8")
    assert ".env" in gitignore and "!**/.env.example" in gitignore


# ---------- El escáner ----------
def test_escaner_detecta_clave_de_proveedor_sin_imprimirla(tmp_path):
    (tmp_path / "config.py").write_text(f'KEY = "{CLAVE_FALSA}"\n', encoding="utf-8")
    hallazgos = escanear(tmp_path)
    assert len(hallazgos) == 1 and hallazgos[0].linea == 1
    assert CLAVE_FALSA not in str(hallazgos[0]) and "AAAA" not in str(hallazgos[0])


def test_escaner_detecta_asignacion_real_y_acepta_el_ejemplo(tmp_path):
    (tmp_path / "a.sh").write_text("export IA_API_KEY=valor-real-0123456789abcdef\n", encoding="utf-8")
    (tmp_path / "b.txt").write_text("IA_API_KEY=CAMBIAME-clave-del-proveedor-de-ia\nIA_API_KEY=\n", encoding="utf-8")
    assert [h.archivo for h in escanear(tmp_path)] == ["a.sh"]


@pytest.mark.parametrize("contenido", [
    "fetch('https://api.anthropic.com/v1/messages')",
    "const k = process.env.IA_API_KEY",
    "headers: {'anthropic-version': '2023-06-01'}",
])
def test_escaner_detecta_al_proveedor_en_codigo_de_navegador(tmp_path, contenido):
    (tmp_path / "web").mkdir()
    (tmp_path / "web" / "app.js").write_text(contenido + "\n", encoding="utf-8")
    hallazgos = escanear(tmp_path)
    assert len(hallazgos) == 1 and "navegador" in hallazgos[0].regla


def test_escaner_permite_mencionar_al_proveedor_en_el_servidor_y_en_docs(tmp_path):
    (tmp_path / "servidor.py").write_text('URL = "https://api.anthropic.com/v1/messages"\n', encoding="utf-8")
    (tmp_path / "LEEME.md").write_text("La IA usa api.anthropic.com desde el servidor.\n", encoding="utf-8")
    assert escanear(tmp_path) == []


def test_escaner_respeta_la_marca_de_clave_falsa(tmp_path):
    (tmp_path / "t.py").write_text(f'K = "{CLAVE_FALSA}"  # secreto-falso\n', encoding="utf-8")
    assert escanear(tmp_path) == []


def test_escaner_ignora_env_local_pero_lo_marca_con_incluir_env(tmp_path):
    (tmp_path / ".env").write_text(f"IA_API_KEY={CLAVE_FALSA}\n", encoding="utf-8")
    assert escanear(tmp_path) == []  # local: ahi si van los secretos
    en_ci = escanear(tmp_path, incluir_env=True)  # en CI un .env en el repo es un problema
    assert {h.regla for h in en_ci} >= {"archivo .env dentro del repositorio"}


# ---------- configurar_ia.py ----------
def _env_ejemplo(tmp_path) -> Path:
    destino = tmp_path / ".env"
    destino.write_text((RAIZ / "more_envios_api" / ".env.example").read_text(encoding="utf-8"), encoding="utf-8")
    return destino


def test_configurar_ia_guarda_la_clave_y_enciende(tmp_path):
    env = _env_ejemplo(tmp_path)
    configurar(env, CLAVE_FALSA)
    guardado = _leer_env(env.read_text(encoding="utf-8"))
    assert guardado["IA_HABILITADA"] == "1" and guardado["IA_API_KEY"] == CLAVE_FALSA
    assert guardado["DATABASE_URL"].startswith("postgresql")  # no tocó lo demás
    assert cargar_config_ia(guardado).api_key.revelar() == CLAVE_FALSA
    if sys.platform != "win32":
        assert stat.S_IMODE(env.stat().st_mode) == 0o600


@pytest.mark.parametrize("mala", ["", "corta", "con espacios 0123456789abcdef", "CAMBIAME-clave-del-proveedor-de-ia"])
def test_configurar_ia_no_escribe_nada_si_la_clave_es_mala(tmp_path, mala):
    env = _env_ejemplo(tmp_path)
    antes = env.read_text(encoding="utf-8")
    with pytest.raises(RuntimeError) as exc:
        configurar(env, mala)
    assert env.read_text(encoding="utf-8") == antes
    if len(mala) > 8:
        assert mala not in str(exc.value)


def test_configurar_ia_apagar_deja_la_clave_guardada_pero_apagada(tmp_path):
    env = _env_ejemplo(tmp_path)
    configurar(env, CLAVE_FALSA)
    configurar(env, None, habilitar=False)
    guardado = _leer_env(env.read_text(encoding="utf-8"))
    assert guardado["IA_HABILITADA"] == "0" and guardado["IA_API_KEY"] == CLAVE_FALSA
    assert cargar_config_ia(guardado).api_key is None  # apagada: ni se carga en memoria


# ---------- generar_env.py ----------
def test_generar_env_crea_llave_aleatoria_ia_apagada_y_no_pisa(tmp_path):
    (tmp_path / ".env.example").write_text((RAIZ / "more_envios_api" / ".env.example").read_text(encoding="utf-8"), encoding="utf-8")
    generar_env.generar(tmp_path)
    env = _leer_env((tmp_path / ".env").read_text(encoding="utf-8"))
    assert "CAMBIAME" not in env["API_KEYS"] and len(env["API_KEYS"].split(":")[1]) >= 32
    assert env["IA_HABILITADA"] == "0"
    (tmp_path / ".env").write_text("IA_HABILITADA=1\n", encoding="utf-8")
    assert "no se modifica" in generar_env.generar(tmp_path)
    assert (tmp_path / ".env").read_text(encoding="utf-8") == "IA_HABILITADA=1\n"
