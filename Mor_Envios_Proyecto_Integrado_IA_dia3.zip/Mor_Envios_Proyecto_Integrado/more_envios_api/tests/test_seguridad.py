"""Pruebas de los hallazgos corregidos en la auditoria (Dia 4).

Cada prueba dice a que hallazgo corresponde. Corren con la misma base de
pruebas que test_transacciones.py y no dejan datos (transaccion que se revierte).
"""
import pytest
from sqlalchemy import text

from app.seguridad import cargar_llaves
from tests.conftest import LLAVE_PRUEBAS

GUIA = "MEV-2026-000010"  # seed: estado 'creado'

RUTAS_GET = [
    "/envios",
    "/envios/costosos",
    f"/envios/{GUIA}/ruta",
    f"/envios/{GUIA}/historial",
    "/reportes/ingresos-por-zona",
    "/reportes/carga-repartidores",
    "/clientes/sin-fallidos",
]


# ---------- Hallazgos 1 y 2: autenticacion ----------
@pytest.mark.parametrize("ruta", RUTAS_GET)
def test_h1_sin_llave_es_401(client_sin_llave, ruta):
    r = client_sin_llave.get(ruta)
    assert r.status_code == 401
    assert "correo" not in r.text and "nombre" not in r.text  # nada de datos en la respuesta


def test_h1_patch_sin_llave_es_401_y_no_escribe(client_sin_llave, db):
    r = client_sin_llave.patch(f"/envios/{GUIA}/estado", json={"estado": "recolectado"})
    assert r.status_code == 401
    est = db.execute(text("SELECT estado_actual FROM envio WHERE num_guia=:g"), {"g": GUIA}).scalar_one()
    assert est == "creado"


@pytest.mark.parametrize("llave", ["", "equivocada", LLAVE_PRUEBAS + "x", LLAVE_PRUEBAS[:-1], "ñandú-ünïcode-€"])
def test_h1_llave_invalida_es_401_nunca_500(client_sin_llave, llave):
    r = client_sin_llave.get("/envios", headers={"X-API-Key": llave.encode("utf-8")})
    assert r.status_code == 401


def test_h2_el_usuario_sale_de_la_llave_no_del_cliente(client, db):
    r = client.patch(f"/envios/{GUIA}/estado", json={"estado": "recolectado", "id_repartidor": 1})
    assert r.status_code == 200
    h = client.get(f"/envios/{GUIA}/historial").json()
    assert h[-1]["usuario_cambio"] == "pruebas"


@pytest.mark.parametrize("falso", ["Director General", "repartidor:99", "<script>alert(1)</script>", "a\u0000b"])
def test_h2_h11_ya_no_se_puede_inventar_usuario(client, db, falso):
    r = client.patch(f"/envios/{GUIA}/estado", json={"estado": "recolectado", "usuario": falso})
    assert r.status_code == 422
    est = db.execute(text("SELECT estado_actual FROM envio WHERE num_guia=:g"), {"g": GUIA}).scalar_one()
    assert est == "creado"  # no se escribio nada


def test_h1_configuracion_de_llaves_se_valida_al_arrancar():
    with pytest.raises(RuntimeError):
        cargar_llaves(None)                       # falta
    with pytest.raises(RuntimeError):
        cargar_llaves("ana:corta")                # llave muy corta
    with pytest.raises(RuntimeError):
        cargar_llaves("ana:CAMBIAME-genera-una-llave-larga-y-aleatoria")  # la del ejemplo
    with pytest.raises(RuntimeError):
        cargar_llaves("nombre con espacios:" + "x" * 30)                   # nombre invalido
    with pytest.raises(RuntimeError):
        cargar_llaves("ana:" + "x" * 30 + ",beto:" + "x" * 30)            # llave repetida
    assert cargar_llaves("ana:" + "a" * 30 + ",beto:" + "b" * 30) == {"a" * 30: "ana", "b" * 30: "beto"}


# ---------- Hallazgo 13: documentacion apagada ----------
@pytest.mark.parametrize("ruta", ["/docs", "/openapi.json", "/redoc"])
def test_h13_docs_apagados_por_defecto(client_sin_llave, ruta):
    assert client_sin_llave.get(ruta).status_code == 404


# ---------- Hallazgos 10 y 12: entradas extremas ----------
ENTRADAS_EXTREMAS = [
    "/envios?page=9223372036854775807",
    "/envios?page=100001",
    "/envios?page=0",
    "/envios?size=1000",
    "/envios?id_cliente=0",
    "/envios?id_cliente=99999999999999999999",
    "/envios?estado=%00",
    "/envios?estado=hackeado",
    "/envios?estado=%27%20OR%201%3D1%20--",
    "/envios/costosos?costo_min=nan",
    "/envios/costosos?costo_min=inf",
    "/envios/costosos?costo_min=-5",
    "/envios/costosos?costo_min=1e308",
    "/reportes/carga-repartidores?min_envios=99999999999999999999",
    "/envios/MEV%00X/historial",
    "/envios/MEV%00X/ruta",
    "/envios/" + "A" * 21 + "/ruta",
    "/envios/" + "A" * 5000 + "/ruta",
    "/envios/x'%20OR%20'1'='1/ruta",
]


@pytest.mark.parametrize("ruta", ENTRADAS_EXTREMAS)
def test_h10_h12_entrada_extrema_es_422_nunca_500(client, ruta):
    r = client.get(ruta)
    assert r.status_code == 422, f"{ruta[:60]} -> {r.status_code}"


def test_h12_el_422_no_repite_el_valor_enviado(client):
    r = client.get("/envios/" + "A" * 5000 + "/ruta")
    assert r.status_code == 422
    assert "AAAAAAAAAA" not in r.text and len(r.text) < 500


@pytest.mark.parametrize("cuerpo", [
    {"estado": "recolectado", "id_repartidor": 3_000_000_000},   # mayor que INT de 4 bytes (era 500)
    {"estado": "recolectado", "id_repartidor": 0},
    {"estado": "recolectado", "id_repartidor": -1},
    {"estado": "a\u0000b"},
    {"estado": "hackeado"},
    {"estado": "recolectado", "id_repartidor": "uno"},
    {},
])
def test_h10_cuerpo_extremo_en_patch_es_422_y_no_escribe(client, db, cuerpo):
    r = client.patch(f"/envios/{GUIA}/estado", json=cuerpo)
    assert r.status_code == 422, f"{cuerpo} -> {r.status_code}"
    est = db.execute(text("SELECT estado_actual FROM envio WHERE num_guia=:g"), {"g": GUIA}).scalar_one()
    assert est == "creado"


def test_h10_limites_validos_siguen_funcionando(client):
    assert client.get("/envios?page=100000").status_code == 200       # el tope mismo es valido
    assert client.get("/envios?id_cliente=2147483647").status_code == 200
    assert client.get("/envios/costosos?costo_min=0").status_code == 200
    assert client.get("/envios/MEV-2026-000001/historial").status_code == 200


# ---------- Hallazgo 4: limite de peticiones ----------
def test_h4_limite_de_peticiones_responde_429(client):
    from app.seguridad import limitador
    limitador.maximo = 5
    codigos = [client.get("/envios").status_code for _ in range(8)]
    assert codigos[:5] == [200] * 5
    assert codigos[5:] == [429] * 3
    r = client.get("/envios")
    assert r.status_code == 429 and int(r.headers["Retry-After"]) >= 1


def test_h4_el_limite_no_se_salta_con_llaves_invalidas(client_sin_llave):
    from app.seguridad import limitador
    limitador.maximo = 3
    codigos = [client_sin_llave.get("/envios", headers={"X-API-Key": f"x{i}"}).status_code for i in range(5)]
    assert codigos == [401, 401, 401, 429, 429]   # tambien frena los intentos de adivinar llaves


# ---------- Errores: el 500 no debe mostrar detalles ----------
def test_el_error_interno_no_muestra_traza(client, monkeypatch):
    import app.main as m
    def roto(*a, **k):
        raise ValueError("secreto interno: password=abc")
    monkeypatch.setattr(m, "filas", roto)
    from fastapi.testclient import TestClient
    r = TestClient(m.app, headers={"X-API-Key": LLAVE_PRUEBAS}, raise_server_exceptions=False).get("/clientes/sin-fallidos")
    assert r.status_code == 500
    assert "secreto" not in r.text and "Traceback" not in r.text
