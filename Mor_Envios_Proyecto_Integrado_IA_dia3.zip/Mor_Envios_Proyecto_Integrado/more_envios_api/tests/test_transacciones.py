import pytest
from sqlalchemy import text

from app.services import (
    NoEncontrado, ReferenciaInvalida, TransicionInvalida, cambiar_estado,
)

GUIA = "MEV-2026-000010"  # seed: estado 'creado', sin repartidor


def estado(db, guia=GUIA):
    return db.execute(
        text("SELECT estado_actual, id_repartidor FROM envio WHERE num_guia=:g"),
        {"g": guia},
    ).one()


def n_historial(db, guia=GUIA):
    return db.execute(
        text(
            "SELECT COUNT(*) FROM historial_estado h "
            "JOIN envio e USING (id_envio) WHERE e.num_guia=:g"
        ),
        {"g": guia},
    ).scalar_one()


def test_commit_completo(db):
    antes = n_historial(db)
    cambiar_estado(db, GUIA, "recolectado", "repartidor:1", id_repartidor=1)
    est, rep = estado(db)
    assert est == "recolectado" and rep == 1
    assert n_historial(db) == antes + 1


def test_repartidor_inexistente_no_modifica_envio(db):
    """Un repartidor inválido se rechaza sin dejar cambios parciales."""
    antes = n_historial(db)
    with pytest.raises(ReferenciaInvalida):
        cambiar_estado(db, GUIA, "recolectado", "repartidor:1", id_repartidor=99999)
    est, rep = estado(db)
    assert est == "creado" and rep is None   # nada quedó a medias
    assert n_historial(db) == antes


def test_repartidor_de_otra_zona_se_rechaza(db):
    """El envío sale de la zona 1; el repartidor 3 trabaja en la zona 2."""
    antes = n_historial(db)
    with pytest.raises(ReferenciaInvalida):
        cambiar_estado(db, GUIA, "recolectado", "repartidor:3", id_repartidor=3)
    assert estado(db) == ("creado", None)
    assert n_historial(db) == antes


def test_respuesta_devuelve_repartidor_actual_si_no_se_cambia(db):
    """Sin id_repartidor en la petición, la respuesta muestra el ya asignado."""
    r = cambiar_estado(db, "MEV-2026-000011", "en_transito", "repartidor:3")
    assert r["id_repartidor"] == 3


def test_transicion_invalida_no_escribe(db):
    antes = n_historial(db)
    with pytest.raises(TransicionInvalida):
        cambiar_estado(db, GUIA, "entregado", "repartidor:1")
    assert estado(db)[0] == "creado"
    assert n_historial(db) == antes


def test_envio_inexistente(db):
    with pytest.raises(NoEncontrado):
        cambiar_estado(db, "MEV-NO-EXISTE", "recolectado", "x")


# ---- API ----
def test_api_patch_409_y_404(client):
    r = client.patch(f"/envios/{GUIA}/estado",
                     json={"estado": "recolectado", "id_repartidor": 99999})
    assert r.status_code == 409
    r = client.patch("/envios/NOPE/estado", json={"estado": "recolectado"})
    assert r.status_code == 404


def test_paginacion_sin_traslape(client):
    p1 = client.get("/envios?page=1&size=5").json()
    p2 = client.get("/envios?page=2&size=5").json()
    g1 = {i["num_guia"] for i in p1["items"]}
    g2 = {i["num_guia"] for i in p2["items"]}
    assert len(g1) == 5 and not g1 & g2
    assert p1["total"] == 12 and p1["total_pages"] == 3


def test_filtro_entregados(client):
    r = client.get("/envios?estado=entregado&size=5").json()
    assert r["total"] == 4
    assert all(i["estado_actual"] == "entregado" for i in r["items"])


def test_reporte_repartidores(client):
    r = client.get("/reportes/carga-repartidores?min_envios=2").json()
    assert len(r) == 4
