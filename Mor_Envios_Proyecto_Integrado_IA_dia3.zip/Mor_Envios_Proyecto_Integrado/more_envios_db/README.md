# More Envios - base de datos

Esquema PostgreSQL para el seguimiento de envios (clientes, repartidores, zonas, sucursales, tarifas, pagos).
Probado con PostgreSQL 16 (ultima prueba: 16.15). Usa siempre la ultima version menor de 16: las menores traen correcciones de seguridad.

## Requisitos
- PostgreSQL 12 o superior
- `psql` en el PATH
- bash

## Uso

```bash
createdb more_envios
export DATABASE_URL=postgresql://usuario:clave@localhost:5432/more_envios

bash migrar.sh up       # aplica las migraciones pendientes
bash migrar.sh status   # lista las aplicadas
bash migrar.sh down     # revierte la ultima
bash migrar.sh reset    # revierte todo y vuelve a aplicar (borra datos)

psql "$DATABASE_URL" -f pruebas/verificar_integridad.sql   # cada consulta debe dar 0 filas
psql "$DATABASE_URL" -f pruebas/verificar_permisos.sql     # todas las filas deben decir OK
```

`migrar.sh` separa la URL en variables `PG*` antes de llamar a `psql`, para que la
contrasena no aparezca en la lista de procesos (`ps`).

Cada migracion corre en una sola transaccion: si falla, no queda nada a medias.
El estado se guarda en la tabla `schema_migrations`.

## Estructura

```
migrar.sh
migraciones/
  001_crear_tablas      tablas, columnas, PK, NOT NULL, DEFAULT
  002_restricciones     UNIQUE, CHECK, FK (con ON DELETE)
  003_indices           indices sobre FK y filtros frecuentes
  004_datos_semilla     5 zonas, 5 sucursales, 8 clientes, 6 repartidores,
                        6 tarifas, 12 envios con historial y pago
  005_rol_api_minimo    rol more_envios_api con permisos minimos para la API
pruebas/
  verificar_integridad.sql
  verificar_permisos.sql   comprueba que el rol puede lo necesario y nada mas
```

Cada migracion tiene su `.up.sql` y su `.down.sql`.

## Convenciones
- Tablas y campos en snake_case, singular, sin acentos.
- Restricciones con nombre: `pk_`, `uq_`, `ck_`, `fk_` + tabla + detalle.
- Montos en NUMERIC, fechas en TIMESTAMP.
- Tarifa por rango de peso: (peso_min_kg, peso_max_kg].
- Los hashes de `administrador` en la semilla son de ejemplo, no son reales.

## Rol de la API (005)
La migracion crea el rol `more_envios_api` **sin contrasena y sin login**. Para usarlo:
```bash
psql "$DATABASE_URL" -c "ALTER ROLE more_envios_api LOGIN PASSWORD 'una-clave-larga'"
```
El rol es de todo el servidor PostgreSQL, no de una base: `migrar.sh down` le quita
los permisos de esa base pero **no borra el rol** (podria estar en uso en otra base,
por ejemplo `more_envios_test`).

## Notas
- La semilla usa ids implicitos (SERIAL desde 1), asi que asume tablas vacias.
- `estado_actual` en `envio` y `historial_estado` deben actualizarse juntos, en la misma transaccion (se hace desde la API).
- Pendiente: decidir si `usuario_cambio` pasa a ser FK hacia repartidor/administrador.

## Advertencias
- `migrar.sh reset` revierte todas las migraciones y las vuelve a aplicar: úsalo solo en desarrollo/pruebas, nunca contra una base con datos reales sin respaldo.
- La reversión de `004` borra únicamente los 12 envíos, clientes y demás registros de ejemplo, no hace `TRUNCATE`.
- `migrar.sh` necesita Bash y `psql`. En Windows: Git Bash o WSL.
