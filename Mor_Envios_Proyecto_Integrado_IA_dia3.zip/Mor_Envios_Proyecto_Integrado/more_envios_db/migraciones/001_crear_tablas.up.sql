-- 001_crear_tablas.up.sql
-- Tablas, columnas, PK, NOT NULL y DEFAULT.
-- Las FK, CHECK y UNIQUE van en 002_restricciones.

CREATE TABLE zona (
    id_zona   SERIAL       NOT NULL,
    nombre    VARCHAR(80)  NOT NULL,
    ciudad    VARCHAR(80)  NOT NULL,
    CONSTRAINT pk_zona PRIMARY KEY (id_zona)
);

CREATE TABLE sucursal (
    id_sucursal SERIAL       NOT NULL,
    nombre      VARCHAR(100) NOT NULL,
    direccion   VARCHAR(200) NOT NULL,
    id_zona     INT          NOT NULL,
    CONSTRAINT pk_sucursal PRIMARY KEY (id_sucursal)
);

CREATE TABLE cliente (
    id_cliente SERIAL       NOT NULL,
    nombre     VARCHAR(100) NOT NULL,
    correo     VARCHAR(120) NOT NULL,
    telefono   VARCHAR(20),
    direccion  VARCHAR(200) NOT NULL,
    CONSTRAINT pk_cliente PRIMARY KEY (id_cliente)
);

CREATE TABLE administrador (
    id_administrador SERIAL       NOT NULL,
    nombre           VARCHAR(100) NOT NULL,
    usuario          VARCHAR(50)  NOT NULL,
    password_hash    VARCHAR(255) NOT NULL,
    CONSTRAINT pk_administrador PRIMARY KEY (id_administrador)
);

CREATE TABLE repartidor (
    id_repartidor SERIAL       NOT NULL,
    nombre        VARCHAR(100) NOT NULL,
    estado        VARCHAR(12)  NOT NULL DEFAULT 'disponible',
    id_zona       INT          NOT NULL,
    id_sucursal   INT,
    CONSTRAINT pk_repartidor PRIMARY KEY (id_repartidor)
);

CREATE TABLE tarifa (
    id_tarifa     SERIAL        NOT NULL,
    tipo_servicio VARCHAR(10)   NOT NULL,
    peso_min_kg   NUMERIC(8,2)  NOT NULL,
    peso_max_kg   NUMERIC(8,2)  NOT NULL,
    costo         NUMERIC(10,2) NOT NULL,
    CONSTRAINT pk_tarifa PRIMARY KEY (id_tarifa)
);

CREATE TABLE envio (
    id_envio            SERIAL        NOT NULL,
    num_guia            VARCHAR(20)   NOT NULL,
    dir_origen          VARCHAR(200)  NOT NULL,
    dir_destino         VARCHAR(200)  NOT NULL,
    peso_kg             NUMERIC(8,2)  NOT NULL,
    largo_cm            NUMERIC(6,1),
    ancho_cm            NUMERIC(6,1),
    alto_cm             NUMERIC(6,1),
    costo               NUMERIC(10,2) NOT NULL,
    estado_actual       VARCHAR(15)   NOT NULL DEFAULT 'creado',
    fecha_creacion      TIMESTAMP     NOT NULL DEFAULT now(),
    id_cliente          INT           NOT NULL,
    id_repartidor       INT,
    id_tarifa           INT           NOT NULL,
    id_zona_origen      INT           NOT NULL,
    id_zona_destino     INT           NOT NULL,
    id_sucursal_origen  INT,
    id_sucursal_destino INT,
    CONSTRAINT pk_envio PRIMARY KEY (id_envio)
);

CREATE TABLE historial_estado (
    id_historial   SERIAL      NOT NULL,
    id_envio       INT         NOT NULL,
    estado         VARCHAR(15) NOT NULL,
    fecha_cambio   TIMESTAMP   NOT NULL DEFAULT now(),
    usuario_cambio VARCHAR(50) NOT NULL,
    CONSTRAINT pk_historial_estado PRIMARY KEY (id_historial)
);

CREATE TABLE pago (
    id_pago    SERIAL        NOT NULL,
    id_envio   INT           NOT NULL,
    monto      NUMERIC(10,2) NOT NULL,
    metodo     VARCHAR(15)   NOT NULL,
    fecha_pago TIMESTAMP,
    estado     VARCHAR(10)   NOT NULL DEFAULT 'pendiente',
    CONSTRAINT pk_pago PRIMARY KEY (id_pago)
);
