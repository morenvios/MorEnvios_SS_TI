-- 002_restricciones.down.sql
-- FK
ALTER TABLE pago             DROP CONSTRAINT IF EXISTS fk_pago_envio;
ALTER TABLE historial_estado DROP CONSTRAINT IF EXISTS fk_historial_envio;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS fk_envio_sucursal_destino;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS fk_envio_sucursal_origen;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS fk_envio_zona_destino;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS fk_envio_zona_origen;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS fk_envio_tarifa;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS fk_envio_repartidor;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS fk_envio_cliente;
ALTER TABLE repartidor DROP CONSTRAINT IF EXISTS fk_repartidor_sucursal;
ALTER TABLE repartidor DROP CONSTRAINT IF EXISTS fk_repartidor_zona;
ALTER TABLE sucursal   DROP CONSTRAINT IF EXISTS fk_sucursal_zona;
-- CHECK
ALTER TABLE pago DROP CONSTRAINT IF EXISTS ck_pago_fecha;
ALTER TABLE pago DROP CONSTRAINT IF EXISTS ck_pago_estado;
ALTER TABLE pago DROP CONSTRAINT IF EXISTS ck_pago_metodo;
ALTER TABLE pago DROP CONSTRAINT IF EXISTS ck_pago_monto;
ALTER TABLE historial_estado DROP CONSTRAINT IF EXISTS ck_historial_estado;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS ck_envio_estado;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS ck_envio_costo;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS ck_envio_alto;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS ck_envio_ancho;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS ck_envio_largo;
ALTER TABLE envio DROP CONSTRAINT IF EXISTS ck_envio_peso;
ALTER TABLE tarifa DROP CONSTRAINT IF EXISTS ck_tarifa_costo;
ALTER TABLE tarifa DROP CONSTRAINT IF EXISTS ck_tarifa_rango;
ALTER TABLE tarifa DROP CONSTRAINT IF EXISTS ck_tarifa_peso_min;
ALTER TABLE tarifa DROP CONSTRAINT IF EXISTS ck_tarifa_servicio;
ALTER TABLE repartidor DROP CONSTRAINT IF EXISTS ck_repartidor_estado;
ALTER TABLE cliente DROP CONSTRAINT IF EXISTS ck_cliente_correo;
-- UNIQUE
ALTER TABLE pago          DROP CONSTRAINT IF EXISTS uq_pago_envio;
ALTER TABLE envio         DROP CONSTRAINT IF EXISTS uq_envio_num_guia;
ALTER TABLE tarifa        DROP CONSTRAINT IF EXISTS uq_tarifa_servicio_rango;
ALTER TABLE administrador DROP CONSTRAINT IF EXISTS uq_administrador_usuario;
ALTER TABLE cliente       DROP CONSTRAINT IF EXISTS uq_cliente_correo;
ALTER TABLE zona          DROP CONSTRAINT IF EXISTS uq_zona_nombre;
