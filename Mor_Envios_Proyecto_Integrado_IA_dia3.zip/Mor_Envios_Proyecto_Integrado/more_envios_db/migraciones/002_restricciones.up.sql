-- 002_restricciones.up.sql
-- UNIQUE, CHECK y llaves foraneas.
-- Convencion de nombres: uq_ / ck_ / fk_ + tabla + detalle.

-- ---------- UNIQUE ----------
ALTER TABLE zona          ADD CONSTRAINT uq_zona_nombre          UNIQUE (nombre);
ALTER TABLE cliente       ADD CONSTRAINT uq_cliente_correo       UNIQUE (correo);
ALTER TABLE administrador ADD CONSTRAINT uq_administrador_usuario UNIQUE (usuario);
ALTER TABLE tarifa        ADD CONSTRAINT uq_tarifa_servicio_rango UNIQUE (tipo_servicio, peso_min_kg);
ALTER TABLE envio         ADD CONSTRAINT uq_envio_num_guia       UNIQUE (num_guia);
ALTER TABLE pago          ADD CONSTRAINT uq_pago_envio           UNIQUE (id_envio);  -- fuerza 1:1

-- ---------- CHECK ----------
ALTER TABLE cliente ADD CONSTRAINT ck_cliente_correo
    CHECK (position('@' in correo) > 1);

ALTER TABLE repartidor ADD CONSTRAINT ck_repartidor_estado
    CHECK (estado IN ('disponible', 'ocupado'));

ALTER TABLE tarifa ADD CONSTRAINT ck_tarifa_servicio
    CHECK (tipo_servicio IN ('estandar', 'express'));
ALTER TABLE tarifa ADD CONSTRAINT ck_tarifa_peso_min CHECK (peso_min_kg >= 0);
ALTER TABLE tarifa ADD CONSTRAINT ck_tarifa_rango    CHECK (peso_max_kg > peso_min_kg);
ALTER TABLE tarifa ADD CONSTRAINT ck_tarifa_costo    CHECK (costo >= 0);

ALTER TABLE envio ADD CONSTRAINT ck_envio_peso     CHECK (peso_kg > 0);
ALTER TABLE envio ADD CONSTRAINT ck_envio_largo    CHECK (largo_cm > 0);
ALTER TABLE envio ADD CONSTRAINT ck_envio_ancho    CHECK (ancho_cm > 0);
ALTER TABLE envio ADD CONSTRAINT ck_envio_alto     CHECK (alto_cm  > 0);
ALTER TABLE envio ADD CONSTRAINT ck_envio_costo    CHECK (costo >= 0);
ALTER TABLE envio ADD CONSTRAINT ck_envio_estado
    CHECK (estado_actual IN ('creado', 'recolectado', 'en_transito', 'en_reparto', 'entregado', 'fallido'));

ALTER TABLE historial_estado ADD CONSTRAINT ck_historial_estado
    CHECK (estado IN ('creado', 'recolectado', 'en_transito', 'en_reparto', 'entregado', 'fallido'));

ALTER TABLE pago ADD CONSTRAINT ck_pago_monto  CHECK (monto >= 0);
ALTER TABLE pago ADD CONSTRAINT ck_pago_metodo
    CHECK (metodo IN ('efectivo', 'tarjeta', 'transferencia'));
ALTER TABLE pago ADD CONSTRAINT ck_pago_estado
    CHECK (estado IN ('pendiente', 'pagado', 'rechazado'));
-- solo un pago pendiente puede no tener fecha
ALTER TABLE pago ADD CONSTRAINT ck_pago_fecha
    CHECK (estado = 'pendiente' OR fecha_pago IS NOT NULL);

-- ---------- FOREIGN KEY ----------
ALTER TABLE sucursal ADD CONSTRAINT fk_sucursal_zona
    FOREIGN KEY (id_zona) REFERENCES zona (id_zona) ON DELETE RESTRICT;

ALTER TABLE repartidor ADD CONSTRAINT fk_repartidor_zona
    FOREIGN KEY (id_zona) REFERENCES zona (id_zona) ON DELETE RESTRICT;
ALTER TABLE repartidor ADD CONSTRAINT fk_repartidor_sucursal
    FOREIGN KEY (id_sucursal) REFERENCES sucursal (id_sucursal) ON DELETE SET NULL;

ALTER TABLE envio ADD CONSTRAINT fk_envio_cliente
    FOREIGN KEY (id_cliente) REFERENCES cliente (id_cliente) ON DELETE RESTRICT;
ALTER TABLE envio ADD CONSTRAINT fk_envio_repartidor
    FOREIGN KEY (id_repartidor) REFERENCES repartidor (id_repartidor) ON DELETE RESTRICT;
ALTER TABLE envio ADD CONSTRAINT fk_envio_tarifa
    FOREIGN KEY (id_tarifa) REFERENCES tarifa (id_tarifa) ON DELETE RESTRICT;
ALTER TABLE envio ADD CONSTRAINT fk_envio_zona_origen
    FOREIGN KEY (id_zona_origen) REFERENCES zona (id_zona) ON DELETE RESTRICT;
ALTER TABLE envio ADD CONSTRAINT fk_envio_zona_destino
    FOREIGN KEY (id_zona_destino) REFERENCES zona (id_zona) ON DELETE RESTRICT;
ALTER TABLE envio ADD CONSTRAINT fk_envio_sucursal_origen
    FOREIGN KEY (id_sucursal_origen) REFERENCES sucursal (id_sucursal) ON DELETE RESTRICT;
ALTER TABLE envio ADD CONSTRAINT fk_envio_sucursal_destino
    FOREIGN KEY (id_sucursal_destino) REFERENCES sucursal (id_sucursal) ON DELETE RESTRICT;

ALTER TABLE historial_estado ADD CONSTRAINT fk_historial_envio
    FOREIGN KEY (id_envio) REFERENCES envio (id_envio) ON DELETE CASCADE;

ALTER TABLE pago ADD CONSTRAINT fk_pago_envio
    FOREIGN KEY (id_envio) REFERENCES envio (id_envio) ON DELETE RESTRICT;
