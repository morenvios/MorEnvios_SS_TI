-- 003_indices.down.sql
DROP INDEX IF EXISTS idx_pago_estado;
DROP INDEX IF EXISTS idx_historial_envio_fecha;
DROP INDEX IF EXISTS idx_envio_estado_fecha;
DROP INDEX IF EXISTS idx_envio_zona_destino;
DROP INDEX IF EXISTS idx_envio_zona_origen;
DROP INDEX IF EXISTS idx_envio_tarifa;
DROP INDEX IF EXISTS idx_envio_repartidor;
DROP INDEX IF EXISTS idx_envio_cliente;
DROP INDEX IF EXISTS idx_repartidor_sucursal;
DROP INDEX IF EXISTS idx_repartidor_zona;
DROP INDEX IF EXISTS idx_sucursal_zona;
