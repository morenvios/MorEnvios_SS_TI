-- 003_indices.up.sql
-- Postgres no indexa las FK solas. Estos cubren los joins y filtros
-- de las consultas de negocio (envios por cliente, repartidor, estado y fecha).

CREATE INDEX idx_sucursal_zona          ON sucursal (id_zona);
CREATE INDEX idx_repartidor_zona        ON repartidor (id_zona);
CREATE INDEX idx_repartidor_sucursal    ON repartidor (id_sucursal);
CREATE INDEX idx_envio_cliente          ON envio (id_cliente);
CREATE INDEX idx_envio_repartidor       ON envio (id_repartidor);
CREATE INDEX idx_envio_tarifa           ON envio (id_tarifa);
CREATE INDEX idx_envio_zona_origen      ON envio (id_zona_origen);
CREATE INDEX idx_envio_zona_destino     ON envio (id_zona_destino);
CREATE INDEX idx_envio_estado_fecha     ON envio (estado_actual, fecha_creacion DESC);
CREATE INDEX idx_historial_envio_fecha  ON historial_estado (id_envio, fecha_cambio);
CREATE INDEX idx_pago_estado            ON pago (estado);
