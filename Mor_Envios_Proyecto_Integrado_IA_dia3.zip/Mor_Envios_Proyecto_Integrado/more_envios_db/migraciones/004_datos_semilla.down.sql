-- Revierte únicamente los datos de ejemplo de la semilla.
-- No usa TRUNCATE ni elimina envíos que no pertenezcan a esta semilla.
DELETE FROM pago
WHERE id_envio IN (
    SELECT id_envio FROM envio WHERE num_guia IN (
        'MEV-2026-000001', 'MEV-2026-000002', 'MEV-2026-000003',
        'MEV-2026-000004', 'MEV-2026-000005', 'MEV-2026-000006',
        'MEV-2026-000007', 'MEV-2026-000008', 'MEV-2026-000009',
        'MEV-2026-000010', 'MEV-2026-000011', 'MEV-2026-000012'
    )
);

DELETE FROM historial_estado
WHERE id_envio IN (
    SELECT id_envio FROM envio WHERE num_guia IN (
        'MEV-2026-000001', 'MEV-2026-000002', 'MEV-2026-000003',
        'MEV-2026-000004', 'MEV-2026-000005', 'MEV-2026-000006',
        'MEV-2026-000007', 'MEV-2026-000008', 'MEV-2026-000009',
        'MEV-2026-000010', 'MEV-2026-000011', 'MEV-2026-000012'
    )
);

DELETE FROM envio WHERE num_guia IN (
    'MEV-2026-000001', 'MEV-2026-000002', 'MEV-2026-000003',
    'MEV-2026-000004', 'MEV-2026-000005', 'MEV-2026-000006',
    'MEV-2026-000007', 'MEV-2026-000008', 'MEV-2026-000009',
    'MEV-2026-000010', 'MEV-2026-000011', 'MEV-2026-000012'
);
DELETE FROM repartidor WHERE (id_repartidor, nombre) IN
    ((1, 'Rafael Ortega'), (2, 'Elena Vargas'), (3, 'Marcos Lira'),
     (4, 'Karla Beltrán'), (5, 'Iván Solís'), (6, 'Diana Prado'));
DELETE FROM tarifa WHERE (tipo_servicio, peso_min_kg) IN
    (('estandar', 0), ('estandar', 5), ('estandar', 20),
     ('express', 0), ('express', 5), ('express', 20));
DELETE FROM sucursal WHERE (id_sucursal, nombre) IN
    ((1, 'Sucursal Zócalo'), (2, 'Sucursal Indios Verdes'),
     (3, 'Sucursal Coyoacán'), (4, 'Sucursal Guadalajara Centro'),
     (5, 'Sucursal Monterrey Centro'));
DELETE FROM administrador WHERE usuario IN ('admin', 'logistica');
DELETE FROM cliente WHERE correo IN
    ('ana.torres@correo.mx', 'luis.hernandez@correo.mx', 'maria.gomez@correo.mx',
     'carlos.ramirez@correo.mx', 'sofia.mendoza@correo.mx', 'jorge.castillo@correo.mx',
     'paola.nunez@correo.mx', 'diego.flores@correo.mx');
DELETE FROM zona WHERE nombre IN
    ('Centro CDMX', 'Norte CDMX', 'Sur CDMX', 'Centro GDL', 'Centro MTY');
