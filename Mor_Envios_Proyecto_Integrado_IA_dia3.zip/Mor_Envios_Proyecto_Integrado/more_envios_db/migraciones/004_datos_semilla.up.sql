-- 004_datos_semilla.up.sql
-- Datos de ejemplo. Las referencias usan ids esperados por el orden de insercion;
-- ejecutar en una base nueva o vacia. No ejecutar directamente en una base con datos reales.

-- zonas (ids 1-5)
INSERT INTO zona (nombre, ciudad) VALUES
    ('Centro CDMX', 'Ciudad de México'),
    ('Norte CDMX', 'Ciudad de México'),
    ('Sur CDMX', 'Ciudad de México'),
    ('Centro GDL', 'Guadalajara'),
    ('Centro MTY', 'Monterrey');

-- sucursales (ids 1-5)
INSERT INTO sucursal (nombre, direccion, id_zona) VALUES
    ('Sucursal Zócalo', 'Calle 5 de Mayo 25, Centro', 1),
    ('Sucursal Indios Verdes', 'Av. Insurgentes Norte 1200', 2),
    ('Sucursal Coyoacán', 'Av. Universidad 1850', 3),
    ('Sucursal Guadalajara Centro', 'Av. Juárez 410', 4),
    ('Sucursal Monterrey Centro', 'Calle Morelos 320', 5);

-- clientes (ids 1-8)
INSERT INTO cliente (nombre, correo, telefono, direccion) VALUES
    ('Ana Torres Ruiz', 'ana.torres@correo.mx', '5512340001', 'Calle Tula 45, Roma Norte, CDMX'),
    ('Luis Hernández Pérez', 'luis.hernandez@correo.mx', '5512340002', 'Av. Revolución 880, San Ángel, CDMX'),
    ('María Gómez Salas', 'maria.gomez@correo.mx', '5512340003', 'Calle Hidalgo 12, Tlalpan, CDMX'),
    ('Carlos Ramírez Díaz', 'carlos.ramirez@correo.mx', '3312340004', 'Av. Chapultepec 300, Guadalajara'),
    ('Sofía Mendoza León', 'sofia.mendoza@correo.mx', '8112340005', 'Calle Zaragoza 150, Monterrey'),
    ('Jorge Castillo Vega', 'jorge.castillo@correo.mx', '8112340006', 'Av. Constitución 700, Monterrey'),
    ('Paola Núñez Cruz', 'paola.nunez@correo.mx', NULL, 'Calle Madero 98, Centro, CDMX'),
    ('Diego Flores Rojas', 'diego.flores@correo.mx', '5512340008', 'Calle Reforma 55, Coyoacán, CDMX');

-- administradores (hashes de ejemplo, no son reales)
INSERT INTO administrador (nombre, usuario, password_hash) VALUES
    ('Administrador General', 'admin', '$2b$12$hashDeEjemploNoUsarEnProduccion000000000000000000000'),
    ('Coordinador Logística', 'logistica', '$2b$12$hashDeEjemploNoUsarEnProduccion111111111111111111111');

-- repartidores (ids 1-6)
INSERT INTO repartidor (nombre, estado, id_zona, id_sucursal) VALUES
    ('Rafael Ortega', 'disponible', 1, 1),
    ('Elena Vargas', 'ocupado', 1, 1),
    ('Marcos Lira', 'ocupado', 2, 2),
    ('Karla Beltrán', 'ocupado', 3, 3),
    ('Iván Solís', 'ocupado', 4, 4),
    ('Diana Prado', 'disponible', 5, 5);

-- tarifas: rango de peso (min, max], en kg
INSERT INTO tarifa (tipo_servicio, peso_min_kg, peso_max_kg, costo) VALUES
    ('estandar', 0, 5, 90),
    ('estandar', 5, 20, 150),
    ('estandar', 20, 70, 280),
    ('express', 0, 5, 160),
    ('express', 5, 20, 260),
    ('express', 20, 70, 450);

-- envios (ids 1-12), costo = costo de su tarifa
INSERT INTO envio (num_guia, dir_origen, dir_destino, peso_kg, largo_cm, ancho_cm, alto_cm, costo, estado_actual, fecha_creacion, id_cliente, id_repartidor, id_tarifa, id_zona_origen, id_zona_destino, id_sucursal_origen, id_sucursal_destino) VALUES
    ('MEV-2026-000001', 'Calle Tula 45, Roma Norte, CDMX', 'Av. Insurgentes Norte 1250, CDMX', 8.5, 40, 30, 25, 150, 'entregado', '2026-09-20 09:10', 1, 1, 2, 1, 2, 1, 2),
    ('MEV-2026-000002', 'Av. Revolución 880, San Ángel, CDMX', 'Sucursal Coyoacán', 2.0, 25, 20, 10, 90, 'entregado', '2026-09-21 11:30', 2, 2, 1, 1, 3, NULL, 3),
    ('MEV-2026-000003', 'Calle Hidalgo 12, Tlalpan, CDMX', 'Calle Bolívar 77, Centro, CDMX', 1.2, 30, 20, 5, 160, 'en_reparto', '2026-10-05 08:00', 3, 3, 4, 2, 1, NULL, NULL),
    ('MEV-2026-000004', 'Av. Chapultepec 300, Guadalajara', 'Calle Norte 14, Gustavo A. Madero, CDMX', 25.0, 60, 50, 40, 280, 'en_transito', '2026-10-04 15:45', 4, 4, 3, 3, 2, 3, NULL),
    ('MEV-2026-000005', 'Calle Zaragoza 150, Monterrey', 'Sucursal Monterrey Centro', 12.0, 50, 40, 30, 260, 'en_transito', '2026-10-04 17:20', 5, 5, 5, 4, 5, 4, 5),
    ('MEV-2026-000006', 'Av. Constitución 700, Monterrey', 'Av. Vallarta 2100, Guadalajara', 4.5, 35, 25, 15, 90, 'recolectado', '2026-10-05 13:05', 6, 6, 1, 5, 4, NULL, NULL),
    ('MEV-2026-000007', 'Calle Tula 45, Roma Norte, CDMX', 'Calle Donceles 30, Centro, CDMX', 0.8, 20, 15, 5, 90, 'creado', '2026-10-06 09:40', 1, NULL, 1, 1, 1, NULL, NULL),
    ('MEV-2026-000008', 'Calle Madero 98, Centro, CDMX', 'Sucursal Guadalajara Centro', 30.0, 80, 60, 50, 450, 'entregado', '2026-09-15 10:00', 7, 1, 6, 1, 4, 1, 4),
    ('MEV-2026-000009', 'Calle Reforma 55, Coyoacán, CDMX', 'Calle Isabel la Católica 8, CDMX', 15.0, 45, 35, 30, 150, 'fallido', '2026-09-30 12:15', 8, 4, 2, 3, 1, NULL, NULL),
    ('MEV-2026-000010', 'Av. Revolución 880, San Ángel, CDMX', 'Calle Poniente 112, CDMX', 3.0, 30, 25, 10, 160, 'creado', '2026-10-06 10:05', 2, NULL, 4, 1, 2, NULL, NULL),
    ('MEV-2026-000011', 'Calle Hidalgo 12, Tlalpan, CDMX', 'Calle Cuauhtémoc 60, Coyoacán, CDMX', 7.5, 40, 30, 20, 260, 'recolectado', '2026-10-06 07:30', 3, 3, 5, 2, 3, NULL, NULL),
    ('MEV-2026-000012', 'Calle Zaragoza 150, Monterrey', 'Calle Hospital 33, Guadalajara', 18.0, 55, 45, 35, 150, 'entregado', '2026-09-25 14:00', 5, 5, 2, 4, 4, NULL, NULL);

-- historial: un registro por cada estado por el que paso el envio
INSERT INTO historial_estado (id_envio, estado, fecha_cambio, usuario_cambio) VALUES
    (1, 'creado', '2026-09-20 09:10', 'cliente:1'),
    (1, 'recolectado', '2026-09-20 12:10', 'repartidor:1'),
    (1, 'en_transito', '2026-09-20 15:10', 'repartidor:1'),
    (1, 'en_reparto', '2026-09-20 18:10', 'repartidor:1'),
    (1, 'entregado', '2026-09-20 21:10', 'repartidor:1'),
    (2, 'creado', '2026-09-21 11:30', 'cliente:2'),
    (2, 'recolectado', '2026-09-21 14:30', 'repartidor:2'),
    (2, 'en_transito', '2026-09-21 17:30', 'repartidor:2'),
    (2, 'en_reparto', '2026-09-21 20:30', 'repartidor:2'),
    (2, 'entregado', '2026-09-21 23:30', 'repartidor:2'),
    (3, 'creado', '2026-10-05 08:00', 'cliente:3'),
    (3, 'recolectado', '2026-10-05 11:00', 'repartidor:3'),
    (3, 'en_transito', '2026-10-05 14:00', 'repartidor:3'),
    (3, 'en_reparto', '2026-10-05 17:00', 'repartidor:3'),
    (4, 'creado', '2026-10-04 15:45', 'cliente:4'),
    (4, 'recolectado', '2026-10-04 18:45', 'repartidor:4'),
    (4, 'en_transito', '2026-10-04 21:45', 'repartidor:4'),
    (5, 'creado', '2026-10-04 17:20', 'cliente:5'),
    (5, 'recolectado', '2026-10-04 20:20', 'repartidor:5'),
    (5, 'en_transito', '2026-10-04 23:20', 'repartidor:5'),
    (6, 'creado', '2026-10-05 13:05', 'cliente:6'),
    (6, 'recolectado', '2026-10-05 16:05', 'repartidor:6'),
    (7, 'creado', '2026-10-06 09:40', 'cliente:1'),
    (8, 'creado', '2026-09-15 10:00', 'cliente:7'),
    (8, 'recolectado', '2026-09-15 13:00', 'repartidor:1'),
    (8, 'en_transito', '2026-09-15 16:00', 'repartidor:1'),
    (8, 'en_reparto', '2026-09-15 19:00', 'repartidor:1'),
    (8, 'entregado', '2026-09-15 22:00', 'repartidor:1'),
    (9, 'creado', '2026-09-30 12:15', 'cliente:8'),
    (9, 'recolectado', '2026-09-30 15:15', 'repartidor:4'),
    (9, 'en_transito', '2026-09-30 18:15', 'repartidor:4'),
    (9, 'en_reparto', '2026-09-30 21:15', 'repartidor:4'),
    (9, 'fallido', '2026-10-01 00:15', 'repartidor:4'),
    (10, 'creado', '2026-10-06 10:05', 'cliente:2'),
    (11, 'creado', '2026-10-06 07:30', 'cliente:3'),
    (11, 'recolectado', '2026-10-06 10:30', 'repartidor:3'),
    (12, 'creado', '2026-09-25 14:00', 'cliente:5'),
    (12, 'recolectado', '2026-09-25 17:00', 'repartidor:5'),
    (12, 'en_transito', '2026-09-25 20:00', 'repartidor:5'),
    (12, 'en_reparto', '2026-09-25 23:00', 'repartidor:5'),
    (12, 'entregado', '2026-09-26 02:00', 'repartidor:5');

-- pagos: uno por envio
INSERT INTO pago (id_envio, monto, metodo, fecha_pago, estado) VALUES
    (1, 150, 'tarjeta', '2026-09-20 09:15', 'pagado'),
    (2, 90, 'transferencia', '2026-09-21 11:35', 'pagado'),
    (3, 160, 'efectivo', '2026-10-05 08:05', 'pagado'),
    (4, 280, 'tarjeta', '2026-10-04 15:50', 'pagado'),
    (5, 260, 'transferencia', '2026-10-04 17:25', 'pagado'),
    (6, 90, 'efectivo', '2026-10-05 13:10', 'pagado'),
    (7, 90, 'efectivo', NULL, 'pendiente'),
    (8, 450, 'transferencia', '2026-09-15 10:05', 'pagado'),
    (9, 150, 'efectivo', '2026-09-30 12:20', 'pagado'),
    (10, 160, 'tarjeta', '2026-10-06 10:05', 'rechazado'),
    (11, 260, 'transferencia', '2026-10-06 07:35', 'pagado'),
    (12, 150, 'efectivo', '2026-09-25 14:05', 'pagado');
