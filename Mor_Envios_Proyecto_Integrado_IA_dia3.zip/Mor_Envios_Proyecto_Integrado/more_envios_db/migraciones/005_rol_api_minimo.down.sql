-- 005_rol_api_minimo.down.sql
-- Quita los permisos del rol EN ESTA BASE. No borra el rol: en PostgreSQL los
-- roles son de todo el servidor, no de una base, y puede seguir en uso en otra
-- (por ejemplo more_envios_test). Si de verdad quieres borrarlo, hazlo a mano
-- y en cada base:   DROP OWNED BY more_envios_api;   y despues:   DROP ROLE more_envios_api;
REVOKE ALL ON ALL TABLES    IN SCHEMA public FROM more_envios_api;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM more_envios_api;
REVOKE USAGE ON SCHEMA public FROM more_envios_api;
