-- 005_rol_api_minimo.up.sql
-- Rol con permisos minimos para la API (en vez de conectarse como superusuario).
-- La API solo necesita: leer las tablas de negocio, actualizar estado y
-- repartidor de un envio, y agregar filas al historial.
-- NO lleva contrasena aqui: se asigna aparte (ver README), para que no quede en git.

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'more_envios_api') THEN
        CREATE ROLE more_envios_api NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE;
    END IF;
END
$$;

GRANT USAGE ON SCHEMA public TO more_envios_api;

-- lectura: solo las tablas que consultan los endpoints (administrador NO esta)
GRANT SELECT ON envio, cliente, repartidor, zona, sucursal, pago, historial_estado
    TO more_envios_api;

-- escritura: unicamente lo que hace el cambio de estado
GRANT UPDATE (estado_actual, id_repartidor) ON envio TO more_envios_api;
GRANT INSERT ON historial_estado TO more_envios_api;
GRANT USAGE ON SEQUENCE historial_estado_id_historial_seq TO more_envios_api;
