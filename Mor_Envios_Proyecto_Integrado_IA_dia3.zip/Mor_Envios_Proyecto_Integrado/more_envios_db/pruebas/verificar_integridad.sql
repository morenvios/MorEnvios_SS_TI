-- verificar_integridad.sql
-- Cada consulta debe devolver 0 filas. Si devuelve algo, hay un problema de datos.
-- Uso: psql "$DATABASE_URL" -f pruebas/verificar_integridad.sql

\echo '1. envios con estado_actual distinto al ultimo registro del historial'
SELECT e.id_envio, e.estado_actual, h.estado AS ultimo_historial
FROM envio e
JOIN LATERAL (SELECT estado FROM historial_estado
              WHERE id_envio = e.id_envio
              ORDER BY fecha_cambio DESC, id_historial DESC LIMIT 1) h ON true
WHERE e.estado_actual <> h.estado;

\echo '2. envios sin ningun registro de historial'
SELECT e.id_envio FROM envio e
LEFT JOIN historial_estado h ON h.id_envio = e.id_envio
WHERE h.id_historial IS NULL;

\echo '3. envios con peso fuera del rango de su tarifa (min, max]'
SELECT e.id_envio, e.peso_kg, t.peso_min_kg, t.peso_max_kg
FROM envio e JOIN tarifa t ON t.id_tarifa = e.id_tarifa
WHERE e.peso_kg <= t.peso_min_kg OR e.peso_kg > t.peso_max_kg;

\echo '4. envios cuyo costo no coincide con el de su tarifa'
SELECT e.id_envio, e.costo, t.costo AS costo_tarifa
FROM envio e JOIN tarifa t ON t.id_tarifa = e.id_tarifa
WHERE e.costo <> t.costo;

\echo '5. envios sin pago'
SELECT e.id_envio FROM envio e
LEFT JOIN pago p ON p.id_envio = e.id_envio
WHERE p.id_pago IS NULL;

\echo '6. pagos con monto distinto al costo del envio'
SELECT p.id_pago, p.monto, e.costo
FROM pago p JOIN envio e ON e.id_envio = p.id_envio
WHERE p.monto <> e.costo;

\echo '7. envios con repartidor de una zona distinta a la zona de origen'
SELECT e.id_envio, e.id_zona_origen, r.id_zona AS zona_repartidor
FROM envio e JOIN repartidor r ON r.id_repartidor = e.id_repartidor
WHERE e.id_zona_origen <> r.id_zona;

\echo '8. envios con sucursal de origen/destino en otra zona'
SELECT e.id_envio FROM envio e
LEFT JOIN sucursal so ON so.id_sucursal = e.id_sucursal_origen
LEFT JOIN sucursal sd ON sd.id_sucursal = e.id_sucursal_destino
WHERE (so.id_sucursal IS NOT NULL AND so.id_zona <> e.id_zona_origen)
   OR (sd.id_sucursal IS NOT NULL AND sd.id_zona <> e.id_zona_destino);
