-- verificar_permisos.sql
-- Comprueba que el rol more_envios_api puede lo que necesita y NADA mas.
-- Se corre como administrador (necesita SET ROLE). No cambia datos: todo va
-- dentro de una transaccion que termina en ROLLBACK.
-- Cada fila de resultado debe decir OK. Si algo sale "FALLA", se ve cual.
--   psql "$DATABASE_URL" -f pruebas/verificar_permisos.sql

BEGIN;
CREATE TABLE resultado_permisos (prueba text, veredicto text);   -- se descarta con el ROLLBACK
GRANT INSERT ON resultado_permisos TO more_envios_api;
-- funcion auxiliar (la crea el administrador; se ejecuta con los permisos de quien la llama)
CREATE FUNCTION debe_negar(nombre text, sentencia text) RETURNS void
LANGUAGE plpgsql AS $f$
BEGIN
    EXECUTE sentencia;
    INSERT INTO resultado_permisos VALUES (nombre, 'FALLA: la operacion SI se permitio');
EXCEPTION
    WHEN insufficient_privilege THEN
        INSERT INTO resultado_permisos VALUES (nombre, 'OK');
    WHEN OTHERS THEN
        INSERT INTO resultado_permisos VALUES (nombre, 'FALLA: error distinto: ' || SQLERRM);
END $f$;
GRANT EXECUTE ON FUNCTION debe_negar(text, text) TO more_envios_api;

SET LOCAL ROLE more_envios_api;

-- Debe poder: consultas de lectura
DO $$ BEGIN
    PERFORM count(*) FROM envio; PERFORM count(*) FROM cliente; PERFORM count(*) FROM historial_estado;
    INSERT INTO resultado_permisos VALUES ('puede leer envio, cliente e historial', 'OK');
EXCEPTION WHEN OTHERS THEN
    INSERT INTO resultado_permisos VALUES ('puede leer envio, cliente e historial', 'FALLA: ' || SQLERRM);
END $$;

-- Debe poder: el cambio de estado completo (con FOR UPDATE, UPDATE e INSERT)
DO $$ BEGIN
    PERFORM 1 FROM envio WHERE num_guia = 'MEV-2026-000010' FOR UPDATE;
    UPDATE envio SET estado_actual = 'recolectado', id_repartidor = 1 WHERE num_guia = 'MEV-2026-000010';
    INSERT INTO historial_estado (id_envio, estado, fecha_cambio, usuario_cambio)
        SELECT id_envio, 'recolectado', now(), 'prueba' FROM envio WHERE num_guia = 'MEV-2026-000010';
    INSERT INTO resultado_permisos VALUES ('puede hacer el cambio de estado completo', 'OK');
EXCEPTION WHEN OTHERS THEN
    INSERT INTO resultado_permisos VALUES ('puede hacer el cambio de estado completo', 'FALLA: ' || SQLERRM);
END $$;

-- NO debe poder: cada bloque espera "permission denied"; si la operacion pasa, es FALLA

\o /dev/null
SELECT debe_negar('no puede leer administrador (hashes)', 'SELECT * FROM administrador');
SELECT debe_negar('no puede cambiar el costo de un envio', 'UPDATE envio SET costo = 0');
SELECT debe_negar('no puede cambiar el cliente de un envio', 'UPDATE envio SET id_cliente = 1');
SELECT debe_negar('no puede borrar envios', 'DELETE FROM envio');
SELECT debe_negar('no puede borrar el historial', 'DELETE FROM historial_estado');
SELECT debe_negar('no puede editar el historial', 'UPDATE historial_estado SET usuario_cambio = ''x''');
SELECT debe_negar('no puede insertar clientes', 'INSERT INTO cliente (nombre, correo, direccion) VALUES (''a'',''a@b.c'',''d'')');
SELECT debe_negar('no puede tocar pagos', 'UPDATE pago SET monto = 0');
SELECT debe_negar('no puede borrar tablas', 'DROP TABLE pago');
SELECT debe_negar('no puede crear tablas', 'CREATE TABLE intruso (x int)');
SELECT debe_negar('no puede crear roles', 'CREATE ROLE intruso LOGIN');

\o
RESET ROLE;
SELECT prueba, veredicto FROM resultado_permisos ORDER BY (veredicto <> 'OK') DESC, prueba;
SELECT 'rolsuper=' || rolsuper || ', rolcreatedb=' || rolcreatedb || ', rolcreaterole=' || rolcreaterole AS atributos_del_rol
FROM pg_roles WHERE rolname = 'more_envios_api';
ROLLBACK;
