# Guía de demo — Explicación del estado de un envío con IA

Duración: unos 15 minutos. Se puede correr sola con `simulacro.bat` (Parte A), o seguir los pasos a mano contra la API.

## Antes de empezar
- PostgreSQL arriba con la base de ejemplo; API iniciada.
- **Decide y di desde el principio con qué proveedor de IA vas a demostrar.** Sin clave real, la demo usa un proveedor **simulado** (textos fijos por estado): se demuestra la integración, no la calidad de un modelo. Decirlo no resta; que el cliente lo descubra, sí.

## Guion
| Min | Qué hacer | Qué decir | Qué se ve |
|---|---|---|---|
| 0-2 | `GET /health` y el historial de un envío | "Esto ya existía: se consultaba el historial. Lo nuevo es explicarlo en lenguaje claro." | Estados creado → recolectado → en_transito |
| 2-5 | `POST /envios/{guia}/explicacion` con "¿Cómo va mi envío?" | "El estado y las fechas salen de la base; la IA solo redacta." | Resumen, siguiente paso, `origen: ia` |
| 5-7 | Mostrar lo que recibe el proveedor | "Solo guía, estado, historial y la pregunta. Nada de nombres, correos, teléfonos, direcciones ni costos." | El mensaje enviado |
| 7-9 | Un envío fallido | "Si hay un problema, marca que una persona debe atender." (Aclarar: hoy nadie consume esa marca.) | `requiere_atencion: true` |
| 9-11 | Seguridad: sin llave (401), guía inválida (422), instrucciones ocultas en la pregunta | "La clave del proveedor vive solo en el servidor." | Códigos de error y el texto invisible que no llega |
| 11-13 | El modelo "miente" (modo manipulado) | "Si el texto contradice a la base, no llega al cliente: se usa una plantilla." | `origen: plantilla`, estado real intacto |
| 13-15 | Se cae el proveedor; luego IA apagada | "El cliente no ve errores. Y hay un interruptor de emergencia." | 200 con plantilla en ambos casos |

## Qué NO prometer
- Calidad del texto de un modelo real (no se midió).
- Fechas de entrega ni reembolsos (la función dice que no hay fecha estimada y deriva a una persona).
- Que alguien atienda los casos marcados (falta definirlo).
- Que es inmune a la inyección: se probó contra los ataques que se me ocurrieron, no contra un atacante real.

## Preguntas probables del cliente
- **¿Qué pasa si la IA se equivoca?** El estado nunca sale del texto de la IA. Un validador rechaza texto que contradiga a la base, invente fechas, prometa dinero, traiga enlaces o datos personales; en ese caso se usa una plantilla. Es heurístico: no es una garantía total.
- **¿Qué datos ve el proveedor?** Solo los del paso 5-7. Está probado contra los 12 envíos de ejemplo.
- **¿Cuánto cuesta?** Por llamada, del orden de centavos de centavo (≈ $0.0002 con el precio que encontré, por verificar). Los topes de uso lo acotan. Con tokens reales se confirma.
- **¿Y si se cae el proveedor?** Respuesta inmediata con plantilla; hay interruptor de emergencia.
- **¿Quién lo opera?** Ver `RUNBOOK_OPERACION.md`: hay lector de logs con alertas y cinco playbooks ensayados. Falta asignar a las personas.

## Si algo falla en vivo
- API no arranca: leer el mensaje; casi siempre es una variable de `.env` (la validación es estricta a propósito).
- Proveedor real no responde: apagar la IA (`configurar_ia.bat --apagar`, reiniciar) y seguir con plantilla; decirlo.
- Sin base de datos: la demo no se puede dar; usar las capturas.
