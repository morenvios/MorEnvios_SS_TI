# Informe técnico de integración — More Envíos

## Qué traía la carpeta recibida
Salud (`/health`), carga de `.env` desde la carpeta de la API, normalización de la URL a `psycopg` 3, validación de repartidor y zona, `004` de reversión selectiva y scripts `.bat`. Se conservó todo y se integró con la parte de seguridad.

## Qué se corrigió o agregó
- Autenticación por llave y usuario tomado de la llave (`app/seguridad.py`); el campo `usuario` ya no se acepta.
- Validación con topes en todas las entradas, incluidos casos que daban 500 (byte nulo, enteros mayores a 4 bytes).
- Límite de peticiones, `/docs` apagado, `/health` sin datos internos y `/health/db` con 503 genérico.
- Migración 005: rol con permisos mínimos, más `verificar_permisos.sql`.
- `requirements.txt` con versiones fijas; `requirements-dev.txt` separado (pytest, httpx, pip-audit).
- `configurar_entorno.bat` genera `.env` con llave aleatoria; nuevo `iniciar_api.bat` sin `--reload`; CI.
- Prueba vieja corregida: `test_api_patch_409_y_404` aún mandaba `usuario`.

## Verificado en este entorno (PostgreSQL 16 local)
- 68 pruebas pasan (zona del repartidor, salud, seguridad y transacciones).
- `migrar.sh up` y `reset` con el `004` selectivo: quedan 12 envíos y 5 migraciones; 8 de 8 verificaciones de integridad en 0 filas.
- API arrancada: `/health` y `/health/db` 200 sin llave; `/envios` 401 sin llave y 200 con llave; `/docs` 404; repartidor de otra zona 409; historial con el usuario de la llave; 0 trazas de error.

## No verificado
Scripts `.bat` en Windows, el flujo de GitHub Actions y la conexión con el rol `more_envios_api` en tu equipo. Ejecuta los pasos del README raíz.

## Integración de IA del lado servidor (semana de IA, martes)
- Nuevo endpoint `POST /envios/{num_guia}/explicacion` (versión 1.3 de la API): explica el estado de un envío a partir de su historial real, solo lectura, con la misma `X-API-Key`.
- Archivos nuevos: `app/config_ia.py` (configuración y secretos), `app/ia.py` (contexto, prompt, cliente del proveedor, límites), `configurar_ia.py/.bat` (guarda la clave sin mostrarla), `escanear_secretos.py` (CI), `evaluacion_ia/casos_evaluacion.json` (22 casos del lunes; C18 corregido de 422 a 404), `tests/test_ia.py` y `tests/test_secretos.py`.
- Verificado: 201 pruebas pasan y 1 se omite a propósito (C20, depende del respaldo con plantilla del miércoles); cuatro sabotajes deliberados del código fueron detectados por las pruebas; prueba de extremo a extremo con uvicorn, el rol `more_envios_api` y un proveedor HTTP simulado (timeout de 2 s cortado en 2.04 s, clave solo en el encabezado, 0 apariciones de la clave en el log).
- No verificado: llamadas al proveedor real, calidad del texto, latencia y costo reales.

## Salida estructurada, validación y respaldo (semana de IA, miércoles)
- La respuesta del endpoint ahora lleva `resumen`, `siguiente_paso`, `requiere_atencion`, `estado_actual`, `num_guia` y `origen` (`ia` o `plantilla`). El campo `mensaje` del martes se reemplazó.
- Archivos: `app/ia_salida.py` (esquema, validador de coherencia, plantillas por estado), `app/ia.py` (prompt nuevo y flujo con respaldo), `tests/test_ia_salida.py`. Se actualizó `tests/test_ia.py` al nuevo comportamiento.
- Cambios de comportamiento respecto al martes: si el proveedor falla o la salida no es válida, la respuesta es 200 con la plantilla (antes 503); con la IA apagada también responde con la plantilla (antes 503). Los topes por minuto y por día siguen respondiendo 429.
- Verificado: 333 pruebas pasan y ninguna se omite (C20 ya se prueba); cinco sabotajes deliberados fueron detectados; baterías hechas a mano: 26/26 respuestas buenas aceptadas y 36/36 malas rechazadas; prueba de extremo a extremo con uvicorn y un proveedor simulado (respaldo por JSON inválido, estado contradictorio, error 500 y timeout; IA apagada; 0 apariciones de la clave en el log).
- No verificado: el comportamiento de un modelo real (las respuestas de prueba las escribí yo), calidad del texto, latencia, costo y tasa real de respaldo.

## Evaluación de la IA (semana de IA, jueves)
- No hubo clave del proveedor en el entorno de trabajo: la calidad, la latencia y el costo REALES del modelo no se midieron. Se entregan el arnés (`evaluar_ia.py`/`.bat`, con `evaluacion_ia/inyecciones.json`, `contextos_semilla.json` y `modelo_costo.py`) y la guía para correrlo con la clave real.
- Medido: 28 de 31 ataques de salida (ofuscación, Unicode, otros formatos) se colaban por el validador del miércoles; ahora se rechazan los 31. La pregunta aceptaba caracteres de etiqueta Unicode invisibles y 200 emojis (≈800 bytes); ahora se limpian y se topan en bytes.
- Medido con servidor real: con 80 consultas a la IA a la vez (proveedor de 4 s), `/historial` llegaba a 4 075 ms; con el tope de concurrencia (8) llega a ~120 ms. Entorno de 1 núcleo: valores absolutos inflados, comparación antes/después válida.
- Documentación oficial de Haiku 5.5: razonamiento adaptativo activo por defecto y contado dentro de `max_tokens` (se subió de 200 a 500), parámetro `output_config.effort` (se envía `low`), `stop_reason` `refusal` y `max_tokens` (se distinguen en el log; el costo de esas respuestas se registra).
- Costo (precio $0.10/$0.50 por millón de tokens, por verificar): ≈ $0.00016 por llamada típica y ≈ $0.00034 en el peor caso; el tope diario de 200 cuesta como máximo ≈ $2 al mes.
- Verificado: 453 pruebas pasan; cinco sabotajes detectados; arnés validado con un proveedor simulado (no mide nada real).

## Demo, simulacro de incidentes y entrega (semana de IA, viernes)
- Nuevos: `demo/simulacro.py` (+ `simulacro.bat`), `resumen_log.py` (+ `.bat`), `iniciar_api_con_log.bat`, `docs/RUNBOOK_OPERACION.md`, `docs/GUIA_DEMO.md`, pruebas `test_resumen_log.py` y `test_documentacion_operativa.py` (el runbook debe explicar todos los motivos de respaldo del código).
- El simulacro levanta la API real y un proveedor de IA SIMULADO, corre una demo de 10 pasos y cinco incidentes (proveedor lento, clave rechazada, clave filtrada, abuso/costo, modelo manipulado). Cada incidente mide detección (con `resumen_log`), acción del runbook ejecutada de verdad y resultado: 38/38 verificaciones; con tres sabotajes al código falló donde debía.
- Hallazgo: las consultas frenadas por los topes (429) no dejaban ninguna línea en el log, así que un abuso era invisible; ahora se registra `ia_limite` y `resumen_log` alerta.
- No verificado: lo mismo que el jueves (modelo real: calidad, latencia, tokens, costo, tasa de plantilla, inyección real). Estado de la entrega: apta como demostración o piloto interno; NO lista para clientes reales hasta cerrar los pendientes bloqueantes del runbook (sección 8).
