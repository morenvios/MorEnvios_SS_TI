# Runbook de operación — Explicación del estado de un envío con IA

Para quien reciba el servicio. Cubre arranque, cómo saber si está sano, qué significa cada señal y qué hacer en cada incidente.
Los procedimientos de los cinco incidentes se ensayaron de verdad con `more_envios_api/demo/simulacro.py` (el proveedor de IA era **simulado**).
Los tiempos que ahí aparecen son de máquina: en la vida real se suman los de las personas.

## 1. Qué es y qué no es
`POST /envios/{guia}/explicacion` explica en lenguaje claro el estado de un envío. Solo lee la base; no puede cambiar nada.
Al proveedor de IA solo le llegan guía, estado, historial (estado y fecha) y la pregunta. Si algo falla, el cliente recibe una **plantilla fija** (HTTP 200, `origen: "plantilla"`), nunca un error del proveedor.
**No** está evaluada con un modelo real (ver sección 8).

## 2. Arrancar y configurar
1. `configurar_entorno.bat` (una vez): crea `.venv`, `.env` y la llave de API.
2. `configurar_ia.bat`: pide la clave del proveedor sin mostrarla y la guarda solo en `.env`. Nunca la pegues en chats, correos, capturas ni en el código.
3. `iniciar_api_con_log.bat`: inicia la API y guarda el log en `logs\api.log`. (`iniciar_api.bat` no guarda log.)
4. Comprobar: `GET /health` y `GET /health/db` responden 200.
Variables (`IA_*`): ver la tabla del `README.md` de la API. La API **no arranca** si la configuración de IA está mal; es a propósito.

## 3. Saber si está sano
`resumen_log.bat` (o `python resumen_log.py logs\api.log`). Imprime respaldos, motivos, latencia, tokens, costo estimado, consultas frenadas por topes y **alertas**; sale con código 1 si hay alguna (sirve para una tarea programada).

| Severidad | Cuándo aparece | Respuesta |
|---|---|---|
| CRÍTICA | Un solo `credencial_rechazada`, `rechazo_proveedor`, `max_tokens` o `saturado` | Ahora mismo |
| ALTA | Tasa de respaldo > 20 % (con al menos 10 llamadas) o tope diario agotado | El mismo día |
| MEDIA | Consultas frenadas por el tope por minuto, o latencia p95 > 5 s | Revisar al día siguiente |

Revisar el resumen al menos una vez al día mientras el servicio sea nuevo. La API no avisa sola: hace falta que alguien (o una tarea programada) corra el resumen.

## 4. Motivos de respaldo (`ia_respaldo ... motivo=X`)
| Motivo | Qué significa | Qué hacer |
|---|---|---|
| `ia_apagada` | `IA_HABILITADA` no es 1: se responde con plantilla a propósito | Nada (es normal si se apagó) |
| `timeout` | El proveedor tardó más de `IA_TIMEOUT_SEG` | Playbook A |
| `red:...` | Sin conexión con el proveedor (el nombre del error sigue a `red:`) | Playbook A |
| `http_...` | El proveedor respondió un error (`http_500`, `http_429`, `http_529`...) | Playbook A |
| `credencial_rechazada` | El proveedor rechaza la clave | Playbook B |
| `respuesta_invalida` | Respuesta vacía, sin texto, rota o demasiado larga | Si es frecuente, Playbook E |
| `max_tokens` | La respuesta se cortó (el razonamiento consume el tope) | Subir `IA_MAX_TOKENS_SALIDA` o bajar `IA_ESFUERZO` |
| `rechazo_proveedor` | El modelo rechazó la solicitud (`stop_reason` refusal) | Revisar qué preguntas lo provocan |
| `saturado` | Se alcanzó `IA_MAX_CONCURRENTES` llamadas simultáneas | Ver si es un pico o un abuso (Playbook D) |
| `json_invalido`, `no_es_objeto`, `campos_distintos`, `tipo_texto`, `tipo_booleano`, `largo_resumen`, `largo_siguiente_paso` | La salida no cumple el esquema de tres campos | Si es frecuente, Playbook E |
| `estado_incoherente`, `fecha_inventada`, `hora_inventada`, `promesa_de_plazo`, `promesa_de_dinero` | El texto contradice a la base o promete lo que no debe | Si es frecuente, Playbook E |
| `enlace`, `dato_sensible`, `caracteres_no_permitidos`, `texto_ofuscado`, `filtra_instrucciones`, `idioma` | El texto trae enlaces, datos personales, caracteres peligrosos, letras disfrazadas, el prompt o no está en español | Si es frecuente, Playbook E |

Un puñado de rechazos del validador es normal (es su trabajo). Preocupa un **aumento repentino** de la tasa.
Además: `ia_limite ... tipo=minuto|diario` = consulta frenada por un tope de uso (el cliente recibió 429).

## 5. Playbooks de incidentes
**Interruptor de emergencia (sirve para A, E y dudas):** `configurar_ia.bat --apagar` y reiniciar la API. El servicio sigue respondiendo con plantilla, sin costo. Para volver: `configurar_ia.bat` (pide la clave otra vez) y reiniciar.

### A. El proveedor está lento o caído
- **Se ve:** tasa de respaldo alta con `timeout`, `red:` o `http_`. Los clientes no ven errores; esperan hasta el timeout (por defecto 8 s) y reciben plantilla.
- **Hacer:** si dura más de unos minutos, apagar la IA (interruptor): evita que cada consulta espere el timeout. Revisar el estado del proveedor. Encender de nuevo cuando se normalice.
- **Ensayo:** con timeout de 1 s, las consultas pasaron de ~1 s a decenas de ms al apagar la IA; ningún error visible para el cliente.

### B. El proveedor rechaza la clave
- **Se ve:** alerta CRÍTICA `credencial_rechazada` (con una sola llamada). Los clientes reciben plantilla.
- **Hacer:** 1) conseguir una clave nueva en el panel del proveedor; 2) `configurar_ia.bat` (valida y guarda; si la clave es mala no toca el `.env`); 3) reiniciar la API; 4) `resumen_log` y confirmar que ya no aparece el motivo. 5) Revocar la clave vieja si no lo está.
- **Verificado:** ni la clave vieja ni la nueva aparecen en los logs.

### C. Se filtró una clave (en el código, un chat, una captura, un correo)
- **Se ve:** `escanear_secretos.py` falla en CI; o alguien lo avisa.
- **Hacer, en este orden:** 1) **revocar la clave en el proveedor YA**: borrarla del archivo no basta, queda en el historial de git y en cualquier copia; 2) rotar como en B; 3) quitar el archivo y volver a pasar el escáner; 4) revisar el panel del proveedor por uso que no reconozcas.
- El escáner no imprime la clave que encuentra.

### D. Un cliente dispara consultas (abuso, cliente mal configurado o pico de costo)
- **Se ve:** alerta MEDIA de consultas frenadas por el tope por minuto, con el usuario; o ALTA si se agotó el tope diario (afecta a todos).
- **Hacer:** identificar al usuario en el resumen; contactarlo; si hace falta, quitar su llave de `API_KEYS` en `.env` y reiniciar (recibirá 401). Los topes limitan el gasto: con 10 por minuto, 10 de 40 consultas llegaron al proveedor, y otro cliente no se vio afectado. Si se agotó el tope diario, decidir si subir `IA_LIMITE_DIARIO` (cuesta centavos: ver `evaluacion_ia/modelo_costo.py`).

### E. El modelo responde fuera de política (manipulado o degradado)
- **Se ve:** tasa de respaldo alta con motivos del validador (`estado_incoherente`, `promesa_de_*`...).
- **Qué protege:** ningún texto rechazado llega al cliente, y el estado siempre sale de la base. Ensayo: 12 de 12 consultas con el modelo diciendo algo falso recibieron plantilla.
- **Hacer:** apagar la IA mientras se revisan el prompt y los ataques (`python evaluar_ia.py --solo I01,I05` con la clave real). Si el modelo cambió de versión, volver a evaluar.
- **Límite:** el validador es heurístico; puede dejar pasar texto que no rompe ninguna regla. Ver sección 8.

## 6. Rotación planeada de claves
Rotar la clave del proveedor y las `API_KEYS` de los clientes periódicamente y siempre que alguien con acceso se vaya del equipo. Mismos pasos que el playbook B; sin prisa y sin interrupción si se hace en una ventana corta.

## 7. Roles (por definir por el equipo)
| Rol | Responsable |
|---|---|
| Dueño de la clave del proveedor y de su facturación | _por definir_ |
| Quien revisa `resumen_log` cada día | _por definir_ |
| Quien atiende los casos con `requiere_atencion: true` | _por definir — hoy nadie los consume_ |
| Quien decide apagar la IA en un incidente | _por definir_ |

## 8. Lo que este servicio NO tiene todavía
- **Evaluación con un modelo real**: calidad, latencia, tokens, costo y tasa real de plantilla están sin medir (no hubo clave). El arnés está listo: `evaluar_ia.bat`.
- **Quien atienda `requiere_atencion`**: la plantilla de "fallido" dice que una persona revisará el caso, pero hoy no existe ese proceso.
- **Autorización por guía**: cualquier llave válida puede pedir la explicación de cualquier envío. Un navegador necesitaría una llave visible: falta decidir cómo autenticar a clientes finales.
- Topes de uso en memoria de un solo proceso (se reinician con la API). Sin alertas automáticas (hay que correr `resumen_log`). Sin autoescalado.
- Validador heurístico: puede dejar pasar texto arbitrario que no rompa ninguna regla.
- Los precios del modelo vienen de fuentes secundarias; verificarlos antes de fijar el tope diario.
