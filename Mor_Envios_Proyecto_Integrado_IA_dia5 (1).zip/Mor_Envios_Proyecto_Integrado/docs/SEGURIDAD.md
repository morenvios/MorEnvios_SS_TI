# Seguridad — More Envíos

## Lo que está implementado
- Llave de API en todas las rutas de negocio (comparación en tiempo constante); la API se niega a arrancar con llaves ausentes, cortas, repetidas o de ejemplo.
- El usuario del historial sale de la llave, no del cliente.
- Validación con topes en todas las entradas; los errores no repiten lo enviado ni devuelven 500 por datos raros.
- Límite de peticiones por IP (429 con `Retry-After`).
- `/docs`, `/redoc` y `/openapi.json` apagados salvo `EXPONER_DOCS=1`.
- Rol de base `more_envios_api` con permisos mínimos (migración 005, verificado con `verificar_permisos.sql`).
- Dependencias fijadas y revisadas con `pip-audit`; `.env` fuera de git.
- `/health` y `/health/db` sin llave, sin versión ni detalles de errores.
- IA (explicación de estado): la clave del proveedor vive solo en `.env`; se carga solo si la función está encendida, va envuelta en `Secreto` (no sale en `repr`, logs ni trazas) y un filtro de logs la tapa si llegara a un mensaje. Solo el servidor habla con el proveedor.
- IA: lista blanca de columnas (guía, estado, historial); timeout, tope de tokens, tope por llave y tope diario; la pregunta y la respuesta no se registran.
- IA: la salida del modelo es un JSON de tres campos que el servidor valida antes de usarlo (esquema estricto y coherencia con la base, sin enlaces ni caracteres `<` `>`). Si falla, el cliente recibe la plantilla del estado y el motivo queda en el log. `estado_actual` nunca sale del texto del modelo y `requiere_atencion` solo puede subirlo la IA, no bajarlo.
- IA: la pregunta se normaliza (NFKC) y se borran los caracteres invisibles, bidireccionales y de etiqueta Unicode (con los que se esconden instrucciones al modelo); tope de 200 caracteres y de 400 bytes (422 si se pasa). El validador de salida normaliza Unicode y homoglifos, rechaza caracteres invisibles, texto con letras separadas, entidades HTML, enlaces y correos ofuscados, estados en inglés y otros formatos de fecha, plazo y hora.
- IA: tope de llamadas simultáneas al proveedor (`IA_MAX_CONCURRENTES`, 8): pasado ese número se responde la plantilla al instante. Sin él, un pico de consultas dejaba al resto de la API esperando varios segundos (todos los endpoints comparten ~40 hilos).
- IA: las consultas frenadas por los topes de uso (429) dejan una línea `ia_limite` en el log con el usuario, y `resumen_log.py` las cuenta y alerta; sin eso un abuso no dejaba rastro (hallazgo del simulacro de incidentes).
- `escanear_secretos.py` (corre en CI): busca claves reales, `.env` subidos y código de navegador que mencione al proveedor de IA.

## Límites declarados (no resueltos)
- Todas las llaves tienen los mismos permisos; sin rotación ni vencimiento.
- Sin HTTPS probado: debe ponerlo un proxy.
- El límite de peticiones vive en un solo proceso (no sirve con varios workers).
- No se registran los intentos fallidos de autenticación.
- La contraseña del rol está en `.env`.
- `historial_estado.usuario_cambio` no es llave foránea.
- No hubo pruebas de carga.
- Los hashes de administrador de la semilla son de ejemplo.
- IA: no hay autorización por guía; cualquier llave válida puede pedir la explicación de cualquier envío (límite heredado de las demás rutas).
- IA: un navegador que llame a `/explicacion` necesitaría una `X-API-Key` de More Envíos visible en el navegador. La clave del proveedor sigue protegida, pero falta decidir cómo autenticar a clientes finales (servidor intermedio o autenticación por cliente).
- IA: los topes de uso viven en memoria de un solo proceso y se reinician al reiniciar la API; el tope diario (200) es provisional.
- IA: el timeout limita cada etapa de la espera, no el tiempo total absoluto; un proveedor que responda gota a gota podría tardar más. Se mide el jueves.
- IA: el validador de coherencia usa heurísticas sobre texto libre, no es una garantía. Una negación a 4 palabras o menos puede colar una afirmación falsa ("No dudes, ya fue entregado") y una paráfrasis que no use las formas conocidas del estado ("ya está en tus manos") no se detecta. Ambos límites están fijados en pruebas. Por eso `estado_actual` sale de la base y no del texto. Su tasa real de falsos rechazos y de fallas se mide el jueves con el modelo real.
- IA: `requiere_atencion` solo marca el caso; todavía no existe un proceso ni una persona asignada que atienda los casos marcados (por definir con el equipo).
- IA: el texto de la plantilla de `fallido` dice que una persona de atención revisará el caso; eso solo es cierto cuando ese proceso exista.
- IA: no se probó contra el proveedor real (solo contra uno simulado); calidad, latencia y costo reales se miden el jueves.
- IA: el validador es una lista de prohibiciones, no de permitidos: si un modelo manipulado añade texto arbitrario que no rompe ninguna regla (por ejemplo, una palabra pedida por el atacante), llega al cliente. Cuánto pasa de verdad solo se sabe con el modelo real (`evaluar_ia.py`, ataques con canarios). Posible mitigación a evaluar: exigir que el texto mencione el estado actual.
- IA: falso rechazo conocido por diseño: una negación a más de 4 palabras ("No te prometemos una entrega el sábado") se rechaza y cae en la plantilla (segura, pero menos informativa).
- IA: los ataques de la batería adversarial los escribí yo conociendo el código; sirven para fijar el comportamiento, no miden a un atacante real.
- IA: la compatibilidad con Haiku 5.5 (esfuerzo, razonamiento que cuenta dentro de `max_tokens`, `stop_reason` de rechazo) se tomó de la documentación oficial y no se probó contra el proveedor real.
- Operación: las alertas no son automáticas; alguien (o una tarea programada) tiene que correr `resumen_log`. Nadie tiene asignado el rol de revisar el log, ser dueño de la clave ni atender `requiere_atencion` (ver `RUNBOOK_OPERACION.md`, sección 7).
- Operación: no se revisó la política de retención de datos del proveedor ni la normativa de protección de datos aplicable; solo se redujo lo que se le envía.
