"""API de More Envíos: las 10 consultas del miércoles como endpoints.

Versión 1.3: autenticación por llave, validación de entradas, límite de
peticiones, documentación apagada por defecto, endpoints de salud y la
explicación del estado de un envío con IA (solo servidor, solo lectura).
"""
import logging
import os
from datetime import date
from math import ceil
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, FastAPI, Path, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import text
from sqlalchemy.exc import DataError
from sqlalchemy.orm import Session

from app.db import get_db
from app.ia import ServicioIA, get_servicio_ia
from app.seguridad import autenticar, limitador
from app.services import ErrorNegocio, NoEncontrado, cambiar_estado

log = logging.getLogger("more_envios")
# Uvicorn solo configura sus propios loggers: sin esto, los mensajes INFO de la API (por ejemplo
# latencia y tokens de cada llamada a la IA) no se escriben en ningún lado.
log.setLevel(logging.INFO)
if not log.handlers:
    _salida = logging.StreamHandler()
    _salida.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    log.addHandler(_salida)

# /docs y /openapi.json solo se encienden a propósito (EXPONER_DOCS=1), nunca por defecto
EXPONER_DOCS = os.getenv("EXPONER_DOCS") == "1"

app = FastAPI(
    title="More Envíos API",
    version="1.3",
    description="API de consulta, seguimiento y reportes para operaciones de More Envíos.",
    docs_url="/docs" if EXPONER_DOCS else None,
    redoc_url=None,
    openapi_url="/openapi.json" if EXPONER_DOCS else None,
)

# Rutas de negocio: todas exigen llave. Las de salud van aparte, sin llave, pero
# con el mismo límite de peticiones y sin devolver datos internos.
privado = APIRouter(dependencies=[Depends(autenticar)])
publico = APIRouter(tags=["Salud"])

INT4_MAX = 2_147_483_647  # tope de las columnas INT de PostgreSQL

Estado = Literal["creado", "recolectado", "en_transito", "en_reparto", "entregado", "fallido"]
# num_guia es VARCHAR(20) en la base: solo letras, números y guion, máximo 20
NumGuia = Annotated[str, Path(min_length=1, max_length=20, pattern=r"^[A-Za-z0-9-]+$")]


@app.middleware("http")
async def limitar_peticiones(request: Request, call_next):
    cliente = request.client.host if request.client else "desconocido"
    permitido, espera = limitador.permitir(cliente)
    if not permitido:
        return JSONResponse(
            status_code=429,
            content={"detail": "Demasiadas peticiones, intenta más tarde"},
            headers={"Retry-After": str(espera)},
        )
    return await call_next(request)


@app.exception_handler(ErrorNegocio)
def manejar_error_negocio(_: Request, exc: ErrorNegocio):
    return JSONResponse(
        status_code=exc.status_code, content={"detail": exc.detalle}, headers=exc.headers
    )


@app.exception_handler(RequestValidationError)
def manejar_validacion(_: Request, exc: RequestValidationError):
    # El manejador por defecto devuelve también "input" (el valor tal cual lo mandó
    # el cliente). Aquí solo se devuelve dónde y qué falló, sin repetir el valor.
    errores = [
        {"loc": list(e["loc"]), "msg": e["msg"], "type": e["type"]} for e in exc.errors()
    ]
    return JSONResponse(status_code=422, content={"detail": errores})


@app.exception_handler(DataError)
def manejar_dato_invalido(_: Request, exc: DataError):
    # Última red de seguridad: si algo raro llega a la base, no es un 500.
    log.warning("DataError de la base: %s", type(exc.orig).__name__)
    return JSONResponse(status_code=422, content={"detail": "Dato fuera de rango o inválido"})


def filas(db: Session, sql: str, params: dict | None = None) -> list[dict]:
    return [dict(r) for r in db.execute(text(sql), params or {}).mappings()]


# ---------- Salud (sin llave) ----------
@publico.get("/health")
def health():
    """Comprueba que el proceso de la API responde."""
    return {"status": "ok"}


@publico.get("/health/db")
def health_db(db: Session = Depends(get_db)):
    """Comprueba la conectividad con PostgreSQL (sin detalles del error)."""
    try:
        db.execute(text("SELECT 1"))
    except Exception:
        log.error("health/db: sin conexión con la base")
        return JSONResponse(status_code=503, content={"status": "error", "database": "unavailable"})
    return {"status": "ok", "database": "connected"}


# ---------- Consultas 1, 3, 9 y 10: listado con filtros y paginación ----------
@privado.get("/envios", tags=["Envíos"])
def listar_envios(
    estado: Estado | None = None,
    id_cliente: int | None = Query(None, ge=1, le=INT4_MAX),
    desde: date | None = None,
    page: int = Query(1, ge=1, le=100_000),
    size: int = Query(5, ge=1, le=50),
    db: Session = Depends(get_db),
):
    condiciones, params = [], {}
    if estado:
        condiciones.append("e.estado_actual = :estado")
        params["estado"] = estado
    if id_cliente:
        condiciones.append("e.id_cliente = :id_cliente")
        params["id_cliente"] = id_cliente
    if desde:
        condiciones.append("e.fecha_creacion >= :desde")
        params["desde"] = desde
    where = ("WHERE " + " AND ".join(condiciones)) if condiciones else ""

    total = db.execute(
        text(f"SELECT COUNT(*) FROM envio e {where}"), params
    ).scalar_one()

    items = filas(
        db,
        f"""
        SELECT e.num_guia, c.nombre AS cliente, r.nombre AS repartidor,
               e.estado_actual, e.costo, e.fecha_creacion
        FROM envio e
        JOIN cliente c         ON c.id_cliente = e.id_cliente
        LEFT JOIN repartidor r ON r.id_repartidor = e.id_repartidor
        {where}
        ORDER BY e.fecha_creacion DESC, e.id_envio
        LIMIT :size OFFSET :offset
        """,
        {**params, "size": size, "offset": (page - 1) * size},
    )
    return {
        "page": page,
        "size": size,
        "total": total,
        "total_pages": ceil(total / size) if total else 0,
        "items": items,
    }


# ---------- Consulta 4: envíos caros y su pago ----------
@privado.get("/envios/costosos", tags=["Envíos"])
def envios_costosos(
    costo_min: float = Query(150, ge=0, le=1_000_000, allow_inf_nan=False),
    db: Session = Depends(get_db),
):
    return filas(
        db,
        """
        SELECT e.num_guia, e.costo, p.estado AS estado_pago
        FROM envio e
        JOIN pago p ON p.id_envio = e.id_envio
        WHERE e.costo > :costo_min
        ORDER BY e.costo DESC
        """,
        {"costo_min": costo_min},
    )


# ---------- Consulta 2: ruta ----------
@privado.get("/envios/{num_guia}/ruta", tags=["Envíos"])
def ruta_envio(num_guia: NumGuia, db: Session = Depends(get_db)):
    datos = filas(
        db,
        """
        SELECT e.num_guia, zo.nombre AS zona_origen, zd.nombre AS zona_destino,
               so.nombre AS sucursal_origen, sd.nombre AS sucursal_destino
        FROM envio e
        JOIN zona zo          ON zo.id_zona = e.id_zona_origen
        JOIN zona zd          ON zd.id_zona = e.id_zona_destino
        LEFT JOIN sucursal so ON so.id_sucursal = e.id_sucursal_origen
        LEFT JOIN sucursal sd ON sd.id_sucursal = e.id_sucursal_destino
        WHERE e.num_guia = :guia
        """,
        {"guia": num_guia},
    )
    if not datos:
        raise NoEncontrado(f"No existe el envío {num_guia}")
    return datos[0]


# ---------- Consulta 8: historial ----------
@privado.get("/envios/{num_guia}/historial", tags=["Envíos"])
def historial_envio(num_guia: NumGuia, db: Session = Depends(get_db)):
    datos = filas(
        db,
        """
        SELECT e.num_guia, h.estado, h.fecha_cambio, h.usuario_cambio
        FROM historial_estado h
        JOIN envio e ON e.id_envio = h.id_envio
        WHERE e.num_guia = :guia
        ORDER BY h.fecha_cambio
        """,
        {"guia": num_guia},
    )
    if not datos:
        raise NoEncontrado(f"No hay historial para {num_guia}")
    return datos


# ---------- Consulta 5: ingresos por zona ----------
@privado.get("/reportes/ingresos-por-zona", tags=["Reportes"])
def ingresos_por_zona(db: Session = Depends(get_db)):
    return filas(
        db,
        """
        SELECT z.nombre AS zona_destino, COUNT(*) AS total_envios,
               SUM(e.costo) AS ingresos,
               ROUND(AVG(e.costo), 2) AS costo_promedio
        FROM envio e
        JOIN zona z ON z.id_zona = e.id_zona_destino
        GROUP BY z.nombre
        ORDER BY ingresos DESC
        """,
    )


# ---------- Consulta 6: carga de repartidores ----------
@privado.get("/reportes/carga-repartidores", tags=["Reportes"])
def carga_repartidores(
    min_envios: int = Query(2, ge=1, le=1000), db: Session = Depends(get_db)
):
    return filas(
        db,
        """
        SELECT r.nombre AS repartidor, COUNT(*) AS envios_asignados
        FROM envio e
        JOIN repartidor r ON r.id_repartidor = e.id_repartidor
        GROUP BY r.nombre
        HAVING COUNT(*) >= :min_envios
        ORDER BY envios_asignados DESC, r.nombre
        """,
        {"min_envios": min_envios},
    )


# ---------- Consulta 7: clientes sin fallidos ----------
# NOT EXISTS en lugar de NOT IN: no se rompe si id_cliente llega a ser NULL.
@privado.get("/clientes/sin-fallidos", tags=["Clientes"])
def clientes_sin_fallidos(db: Session = Depends(get_db)):
    return filas(
        db,
        """
        SELECT c.nombre, c.correo
        FROM cliente c
        WHERE NOT EXISTS (
            SELECT 1 FROM envio e
            WHERE e.id_cliente = c.id_cliente AND e.estado_actual = 'fallido'
        )
        ORDER BY c.nombre
        """,
    )


# ---------- Transacción: cambio de estado ----------
class CambioEstado(BaseModel):
    # "usuario" ya no se recibe: el usuario sale de la llave con la que se autenticó.
    # extra="forbid" hace que un cliente viejo que lo mande reciba un 422 claro.
    model_config = ConfigDict(extra="forbid")

    estado: Estado
    id_repartidor: int | None = Field(default=None, ge=1, le=INT4_MAX)


@privado.patch("/envios/{num_guia}/estado", tags=["Envíos"])
def patch_estado(
    num_guia: NumGuia,
    body: CambioEstado,
    usuario: str = Depends(autenticar),
    db: Session = Depends(get_db),
):
    """Cambia el estado. El usuario del historial sale de la llave, no del cuerpo."""
    return cambiar_estado(db, num_guia, body.estado, usuario, body.id_repartidor)


# ---------- IA: explicación del estado de un envío (solo lectura) ----------
class PreguntaEnvio(BaseModel):
    model_config = ConfigDict(extra="forbid")

    # Opcional: sin pregunta se da un resumen general. Tope de 200 caracteres Y de 400 bytes:
    # 200 emojis son 200 caracteres pero ~800 bytes, y los bytes son lo que acerca a los tokens.
    pregunta: str | None = Field(default=None, max_length=200)

    @field_validator("pregunta")
    @classmethod
    def _tope_en_bytes(cls, valor: str | None) -> str | None:
        if valor is not None and len(valor.encode("utf-8")) > 400:
            raise ValueError("pregunta demasiado larga")
        return valor


@privado.post("/envios/{num_guia}/explicacion", tags=["IA"])
def explicar_estado(
    num_guia: NumGuia,
    body: PreguntaEnvio | None = None,
    usuario: str = Depends(autenticar),
    db: Session = Depends(get_db),
    servicio: ServicioIA = Depends(get_servicio_ia),
):
    """Explica en lenguaje claro el estado de un envío. No modifica nada en la base."""
    return servicio.explicar(db, num_guia, body.pregunta if body else None, usuario)


app.include_router(publico)
app.include_router(privado)
