"""Modelo de costo de la explicación con IA.

Precios de Claude Haiku 5.5 (USD por millón de tokens, prompts de hasta 100 000 tokens):
    entrada 0.10 | salida 0.50
Fuente: artículos que citan la documentación de Anthropic (no se consultó la página oficial de precios
en esta sesión): VERIFICAR en https://platform.claude.com/docs/en/models/haiku-5-5/overview antes de decidir.
Los tokens de razonamiento se cobran como salida.

Los tokens de cada escenario son SUPUESTOS hasta que el arnés evaluar_ia.py mida los reales
(el proveedor los informa en `usage`). Uso:  python evaluacion_ia/modelo_costo.py
"""
PRECIO_ENTRADA_USD_POR_M = 0.10
PRECIO_SALIDA_USD_POR_M = 0.50

# (nombre, tokens de entrada, tokens de salida). Entrada: el prompt mide 1 482 caracteres + datos del
# envío (hasta ~1 953 caracteres con los 12 envíos reales); con 3-4 caracteres por token son 490-650,
# y el tokenizador de Haiku 5.5 cuenta ~30 % más que el de Haiku 4.5, de ahí el escenario de 900.
ESCENARIOS = [
    ("típico", 700, 180),
    ("conservador", 900, 300),
    ("peor caso (usa todo el tope de salida)", 900, 500),
]


def costo_llamada(tokens_entrada: float, tokens_salida: float,
                  precio_entrada: float = PRECIO_ENTRADA_USD_POR_M,
                  precio_salida: float = PRECIO_SALIDA_USD_POR_M) -> float:
    """Costo en USD de una llamada."""
    return (tokens_entrada * precio_entrada + tokens_salida * precio_salida) / 1_000_000


def proyeccion(llamadas_por_dia: int, tokens_entrada: float, tokens_salida: float, dias: int = 30) -> dict:
    por_llamada = costo_llamada(tokens_entrada, tokens_salida)
    return {"por_llamada": por_llamada, "por_dia": por_llamada * llamadas_por_dia, "por_mes": por_llamada * llamadas_por_dia * dias}


if __name__ == "__main__":
    print(f"Precios: entrada ${PRECIO_ENTRADA_USD_POR_M}/M, salida ${PRECIO_SALIDA_USD_POR_M}/M (verificar)\n")
    print(f"{'escenario':42} {'por llamada':>12} {'200/día':>10} {'2 000/día':>11} {'20 000/día':>12}   (USD, 30 días = mes)")
    for nombre, t_in, t_out in ESCENARIOS:
        c = costo_llamada(t_in, t_out)
        d = [proyeccion(n, t_in, t_out) for n in (200, 2000, 20000)]
        print(f"{nombre:42} {c:12.6f} {d[0]['por_dia']:10.4f} {d[1]['por_dia']:11.4f} {d[2]['por_dia']:12.4f}")
    print("\nCosto MENSUAL al tope diario:")
    for nombre, t_in, t_out in ESCENARIOS:
        print(f"  {nombre:42} " + " | ".join(f"{n:>6}/día: ${proyeccion(n, t_in, t_out)['por_mes']:8.2f}" for n in (200, 2000, 20000)))
