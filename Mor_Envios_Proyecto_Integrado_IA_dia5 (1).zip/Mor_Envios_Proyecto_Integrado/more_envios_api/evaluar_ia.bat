@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: No existe .venv. Ejecuta primero configurar_entorno.bat.
  pause
  exit /b 1
)
REM Evalua la IA con el proveedor REAL (gasta tokens: ~100 llamadas cuestan centavos). Antes: configurar_ia.bat
REM Para probar el arnes sin gastar nada:  evaluar_ia.bat --simulado
".venv\Scripts\python.exe" evaluar_ia.py %*
pause
