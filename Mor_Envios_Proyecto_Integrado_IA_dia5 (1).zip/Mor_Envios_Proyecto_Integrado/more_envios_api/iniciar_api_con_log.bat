@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: No existe .venv. Ejecuta primero configurar_entorno.bat.
  pause
  exit /b 1
)
if not exist ".env" (
  echo ERROR: No existe .env. Ejecuta configurar_entorno.bat.
  pause
  exit /b 1
)
if not exist logs mkdir logs
REM Igual que iniciar_api.bat, pero guarda todo en logs\api.log (no muestra nada en pantalla).
REM Ese archivo lo lee resumen_log.bat. Crece sin parar: renombralo o borralo de vez en cuando.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 >> logs\api.log 2>&1
pause
