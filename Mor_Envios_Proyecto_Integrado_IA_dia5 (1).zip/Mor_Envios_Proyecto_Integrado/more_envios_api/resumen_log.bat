@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: No existe .venv. Ejecuta primero configurar_entorno.bat.
  pause
  exit /b 1
)
if not exist "logs\api.log" (
  echo No hay logs\api.log. Inicia la API con iniciar_api_con_log.bat.
  pause
  exit /b 1
)
REM Resume la salud de la explicacion con IA (respaldos, latencia, tokens, costo y alertas).
REM Opciones: --umbral-respaldo 0.2  --p95-ms 5000
".venv\Scripts\python.exe" resumen_log.py logs\api.log %*
pause
