"""Resume el log de la API para operar la explicación con IA: salud, respaldos, latencia, tokens y costo.

Lee las líneas `ia_ok` y `ia_respaldo` que escribe la API (nunca contienen la pregunta, la respuesta ni la clave).
Uso:
    python resumen_log.py api.log                  (o:  tipo api.log | python resumen_log.py -)
    python resumen_log.py api.log --umbral-respaldo 0.2 --p95-ms 5000
Sale con código 1 si hay alguna ALERTA (sirve para un cron o una tarea programada), 0 si todo está bien.

Qué significa cada motivo de respaldo está en docs/RUNBOOK_OPERACION.md.
"""
import argparse
import re
import statistics
import sys
from collections import Counter
from pathlib import Path

PRECIO_ENTRADA = 0.10  # USD por millón de tokens (Haiku 5.5, por verificar: ver evaluacion_ia/modelo_costo.py)
PRECIO_SALIDA = 0.50

RE_FECHA = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})")
RE_OK = re.compile(r"ia_ok usuario=(\S+) guia=\S+ estado=(\S+) latencia_ms=(\d+) tokens_in=(\S+) tokens_out=(\S+)")
RE_LIMITE = re.compile(r"ia_limite usuario=(\S+) tipo=(\S+)")
RE_RESPALDO = re.compile(r"ia_respaldo usuario=(\S+) guia=\S+ motivo=(\S+) tokens_in=(\S+) tokens_out=(\S+)")

# Motivos que ameritan atención inmediata aunque sean pocos, y por qué.
CRITICOS = {
    "credencial_rechazada": "el proveedor rechaza la clave (revocada, vencida o sin saldo): ver playbook 'Clave'",
    "rechazo_proveedor": "el modelo rechazó solicitudes (stop_reason refusal): revisar qué preguntas lo provocan",
    "max_tokens": "el modelo se queda sin tokens de salida (¿razonamiento?): subir IA_MAX_TOKENS_SALIDA o bajar IA_ESFUERZO",
    "saturado": "se alcanzó el tope de llamadas simultáneas (IA_MAX_CONCURRENTES)",
}


def _num(valor):
    return int(valor) if valor and valor.isdigit() else None


def analizar(lineas, precio_entrada=PRECIO_ENTRADA, precio_salida=PRECIO_SALIDA) -> dict:
    ok, respaldos, apagada, limites = [], [], 0, []
    fechas = []
    for linea in lineas:
        f = RE_FECHA.match(linea)
        ml = RE_LIMITE.search(linea)
        if ml:                                   # consulta frenada por un tope de uso (429)
            limites.append({"usuario": ml[1], "tipo": ml[2]})
            if f:
                fechas.append(f[1])
            continue
        m = RE_OK.search(linea)
        if m:
            ok.append({"usuario": m[1], "latencia": int(m[3]), "t_in": _num(m[4]), "t_out": _num(m[5])})
        else:
            m = RE_RESPALDO.search(linea)
            if not m:
                continue
            if m[2] == "ia_apagada":
                apagada += 1
            else:
                respaldos.append({"usuario": m[1], "motivo": m[2], "t_in": _num(m[3]), "t_out": _num(m[4])})
        if f:
            fechas.append(f[1])
    lat = sorted(r["latencia"] for r in ok)
    con_ia = len(ok) + len(respaldos)
    tokens = [(r["t_in"], r["t_out"]) for r in ok + respaldos if r["t_in"] is not None and r["t_out"] is not None]
    t_in, t_out = sum(t[0] for t in tokens), sum(t[1] for t in tokens)
    return {
        "desde": fechas[0] if fechas else None, "hasta": fechas[-1] if fechas else None,
        "llamadas_con_ia": con_ia, "ok": len(ok), "respaldos": len(respaldos),
        "tasa_de_respaldo": round(len(respaldos) / con_ia, 3) if con_ia else 0.0,
        "respondidas_con_ia_apagada": apagada,
        "frenadas_por_tope": dict(Counter(l["tipo"] for l in limites)),
        "frenados_por_usuario": dict(Counter(l["usuario"] for l in limites).most_common(5)),
        "motivos": dict(Counter(r["motivo"] for r in respaldos)),
        "latencia_ms": {"p50": lat[len(lat) // 2] if lat else None,
                        "p95": lat[min(len(lat) - 1, int(len(lat) * .95))] if lat else None,
                        "max": lat[-1] if lat else None},
        "tokens": {"entrada": t_in, "salida": t_out},
        "costo_usd_estimado": round((t_in * precio_entrada + t_out * precio_salida) / 1_000_000, 6),
        "por_usuario": dict(Counter(r["usuario"] for r in ok + respaldos).most_common(5)),
        "promedio_ms": round(statistics.mean(lat), 1) if lat else None,
    }


def alertas(res: dict, umbral_respaldo=0.20, p95_ms=5000, minimo_llamadas=10) -> list[str]:
    """Reglas de alerta. Con pocas llamadas la tasa no es confiable, por eso hay un mínimo."""
    a = []
    for motivo, por_que in CRITICOS.items():
        if res["motivos"].get(motivo):
            a.append(f"CRÍTICA [{motivo} x{res['motivos'][motivo]}]: {por_que}")
    if res["llamadas_con_ia"] >= minimo_llamadas and res["tasa_de_respaldo"] > umbral_respaldo:
        a.append(f"ALTA: tasa de respaldo {res['tasa_de_respaldo']:.0%} supera el umbral de {umbral_respaldo:.0%}")
    if res["frenadas_por_tope"].get("diario"):
        a.append(f"ALTA: se agotó el tope diario ({res['frenadas_por_tope']['diario']} consultas frenadas): la IA dejó de responder a todos hasta mañana")
    if res["frenadas_por_tope"].get("minuto"):
        quien = ", ".join(f"{u} ({n})" for u, n in res["frenados_por_usuario"].items())
        a.append(f"MEDIA: {res['frenadas_por_tope']['minuto']} consultas frenadas por el tope por minuto (posible abuso o cliente mal configurado): {quien}")
    p95 = res["latencia_ms"]["p95"]
    if p95 is not None and res["ok"] >= minimo_llamadas and p95 > p95_ms:
        a.append(f"MEDIA: latencia p95 de {p95} ms supera {p95_ms} ms")
    return a


def imprimir(res: dict, alts: list[str]) -> None:
    print(f"Periodo: {res['desde']} -> {res['hasta']}")
    print(f"Llamadas con IA: {res['llamadas_con_ia']} | con texto de la IA: {res['ok']} | con plantilla: {res['respaldos']} "
          f"(tasa de respaldo {res['tasa_de_respaldo']:.1%}) | respondidas con la IA apagada: {res['respondidas_con_ia_apagada']}")
    print(f"Motivos de respaldo: {res['motivos'] or 'ninguno'}")
    print(f"Consultas frenadas por topes de uso: {res['frenadas_por_tope'] or 'ninguna'}")
    L = res["latencia_ms"]
    print(f"Latencia (solo llamadas buenas): p50={L['p50']} ms, p95={L['p95']} ms, max={L['max']} ms")
    print(f"Tokens: entrada={res['tokens']['entrada']}, salida={res['tokens']['salida']} | costo estimado: ${res['costo_usd_estimado']}")
    print(f"Más activos: {res['por_usuario'] or '-'}")
    print("ALERTAS:" if alts else "Sin alertas.")
    for x in alts:
        print(f"  - {x}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Resumen del log de la API (explicación con IA)")
    ap.add_argument("archivo", help="ruta del log, o - para leer de la entrada estándar")
    ap.add_argument("--umbral-respaldo", type=float, default=0.20)
    ap.add_argument("--p95-ms", type=int, default=5000)
    ap.add_argument("--minimo-llamadas", type=int, default=10)
    ap.add_argument("--precio-entrada", type=float, default=PRECIO_ENTRADA)
    ap.add_argument("--precio-salida", type=float, default=PRECIO_SALIDA)
    a = ap.parse_args(argv)
    lineas = sys.stdin.read().splitlines() if a.archivo == "-" else Path(a.archivo).read_text(encoding="utf-8", errors="replace").splitlines()
    res = analizar(lineas, a.precio_entrada, a.precio_salida)
    alts = alertas(res, a.umbral_respaldo, a.p95_ms, a.minimo_llamadas)
    imprimir(res, alts)
    return 1 if alts else 0


if __name__ == "__main__":
    sys.exit(main())
