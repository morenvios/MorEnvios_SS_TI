@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: No existe .venv. Ejecuta primero configurar_entorno.bat.
  pause
  exit /b 1
)
REM Demo guionada + simulacro de incidentes. El proveedor de IA es SIMULADO; la API y la base son las reales.
REM Necesita PostgreSQL con la base de ejemplo (DATABASE_URL en .env).
".venv\Scripts\python.exe" demo\simulacro.py
pause
