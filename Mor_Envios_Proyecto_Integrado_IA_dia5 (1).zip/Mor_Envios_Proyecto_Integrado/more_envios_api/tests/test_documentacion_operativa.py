"""Que el runbook no se quede atrás del código: todo motivo de respaldo que la API puede escribir debe estar explicado."""
import re
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
RUNBOOK = (RAIZ / "docs" / "RUNBOOK_OPERACION.md").read_text(encoding="utf-8")
FUENTES = (RAIZ / "more_envios_api" / "app" / "ia.py").read_text(encoding="utf-8") + (RAIZ / "more_envios_api" / "app" / "ia_salida.py").read_text(encoding="utf-8")


def motivos_del_codigo():
    m = set(re.findall(r'ProveedorNoDisponible\("([a-z_]+)"\)', FUENTES))
    m |= set(re.findall(r'SalidaInvalida\("([a-z_]+)"\)', FUENTES))
    assert '"rechazo_proveedor" if' in FUENTES  # estos dos se eligen con un condicional en ia.py
    m |= {"rechazo_proveedor", "max_tokens"}
    m |= {"saturado", "ia_apagada"}
    return m


def test_el_runbook_explica_todos_los_motivos_de_respaldo():
    motivos = motivos_del_codigo()
    assert len(motivos) >= 25, "el extractor dejó de encontrar los motivos del código"
    faltan = sorted(m for m in motivos if f"`{m}`" not in RUNBOOK)
    assert not faltan, f"motivos sin documentar en el runbook: {faltan}"


def test_el_runbook_cubre_los_motivos_dinamicos_y_los_topes():
    for texto in ("`red:...`", "`http_...`", "ia_limite", "interruptor", "configurar_ia.bat --apagar"):
        assert texto in RUNBOOK


def test_el_runbook_y_la_guia_declaran_lo_que_no_esta_hecho():
    assert "NO tiene todavía" in RUNBOOK and "requiere_atencion" in RUNBOOK
    guia = (RAIZ / "docs" / "GUIA_DEMO.md").read_text(encoding="utf-8")
    assert "simulado" in guia.lower() and "Qué NO prometer" in guia


def test_los_playbooks_y_alertas_del_lector_estan_alineados_con_el_runbook():
    import resumen_log
    for motivo in resumen_log.CRITICOS:
        assert f"`{motivo}`" in RUNBOOK
    for letra in "ABCDE":
        assert f"### {letra}." in RUNBOOK
