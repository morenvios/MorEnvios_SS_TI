"""Pruebas del tope de concurrencia de la IA (jueves).

Hallazgo medido con un servidor real: con 80 consultas a la IA a la vez (proveedor de 4 s), el resto de la
API se retrasaba hasta 3-4 s porque todos los endpoints comparten ~40 hilos. Cada llamada a la IA retiene
un hilo; el tope de concurrencia evita que la IA se coma el grupo completo.
"""
import logging

import httpx
import pytest

from app.config_ia import ConfigIA, cargar_config_ia
from app.ia import ServicioIA, get_servicio_ia
from app.main import app
from tests.test_ia import CLAVE_IA, BUENAS, Proveedor, config, url


@pytest.fixture
def armar(client):
    def _armar(proveedor=None, **cambios):
        proveedor = proveedor or Proveedor()
        servicio = ServicioIA(config(**cambios), transport=httpx.MockTransport(proveedor))
        app.dependency_overrides[get_servicio_ia] = lambda: servicio
        return client, proveedor, servicio
    return _armar


def test_valor_por_defecto_y_validacion_de_la_variable():
    assert cargar_config_ia({"IA_HABILITADA": "1", "IA_API_KEY": CLAVE_IA}).max_concurrentes == 8
    assert ConfigIA().max_concurrentes == 8
    assert cargar_config_ia({"IA_HABILITADA": "1", "IA_API_KEY": CLAVE_IA, "IA_MAX_CONCURRENTES": "3"}).max_concurrentes == 3
    for malo in ("0", "33", "muchas", "-1"):
        with pytest.raises(RuntimeError):
            cargar_config_ia({"IA_HABILITADA": "1", "IA_API_KEY": CLAVE_IA, "IA_MAX_CONCURRENTES": malo})


def test_sin_cupo_responde_plantilla_al_instante_sin_llamar_ni_gastar_cuota(armar, caplog):
    caplog.set_level(logging.INFO, logger="more_envios")
    client, proveedor, servicio = armar(max_concurrentes=2)
    assert servicio._cupo.acquire(blocking=False) and servicio._cupo.acquire(blocking=False)  # 2 llamadas "en vuelo"
    r = client.post(url("MEV-2026-000005"), json={"pregunta": "hola"})
    assert r.status_code == 200 and r.json()["origen"] == "plantilla" and r.json()["estado_actual"] == "en_transito"
    assert proveedor.llamadas == 0 and servicio.por_dia._usadas == 0
    assert "motivo=saturado" in caplog.text
    servicio._cupo.release()  # se libera un cupo: vuelve a atender con IA
    assert client.post(url("MEV-2026-000005"), json={}).json()["origen"] == "ia"


def test_el_estado_fallido_sigue_marcando_atencion_aunque_haya_saturacion(armar):
    client, _, servicio = armar(max_concurrentes=1)
    servicio._cupo.acquire(blocking=False)
    r = client.post(url("MEV-2026-000009"), json={}).json()
    assert r["origen"] == "plantilla" and r["requiere_atencion"] is True


@pytest.mark.parametrize("proveedor", [
    Proveedor(status=500), Proveedor(error=httpx.ReadTimeout("lento")), Proveedor(texto="no es json"),
    Proveedor(texto=BUENAS["fallido"]),  # incoherente con el estado de la guía 5: se rechaza
    Proveedor(),                          # caso bueno
], ids=["http_500", "timeout", "texto_libre", "salida_rechazada", "ok"])
def test_el_cupo_se_libera_siempre(armar, proveedor):
    client, _, servicio = armar(proveedor, max_concurrentes=3)
    client.post(url("MEV-2026-000005"), json={})
    tomados = [servicio._cupo.acquire(blocking=False) for _ in range(3)]
    assert all(tomados), "el cupo quedó retenido tras la petición"


def test_el_cupo_se_libera_cuando_se_acaba_el_tope_diario(armar):
    client, _, servicio = armar(max_concurrentes=2, limite_diario=1)
    assert client.post(url("MEV-2026-000005"), json={}).status_code == 200
    assert client.post(url("MEV-2026-000005"), json={}).status_code == 429   # tope diario
    assert all(servicio._cupo.acquire(blocking=False) for _ in range(2))


def test_el_limite_por_minuto_se_evalua_antes_que_el_cupo(armar):
    client, proveedor, servicio = armar(max_concurrentes=1, limite_por_min=1)
    servicio._cupo.acquire(blocking=False)
    assert client.post(url("MEV-2026-000005"), json={}).json()["origen"] == "plantilla"  # 1.ª: gasta el minuto
    assert client.post(url("MEV-2026-000005"), json={}).status_code == 429               # 2.ª: abuso, no plantilla
    assert proveedor.llamadas == 0
