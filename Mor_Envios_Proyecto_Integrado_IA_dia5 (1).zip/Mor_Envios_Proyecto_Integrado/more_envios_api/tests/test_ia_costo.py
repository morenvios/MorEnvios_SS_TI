import importlib.util
from pathlib import Path

RUTA = Path(__file__).resolve().parents[1] / "evaluacion_ia" / "modelo_costo.py"
spec = importlib.util.spec_from_file_location("modelo_costo", RUTA)
mc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mc)


def test_formula_de_costo():
    assert mc.costo_llamada(1_000_000, 0) == 0.10          # un millón de tokens de entrada
    assert mc.costo_llamada(0, 1_000_000) == 0.50          # un millón de salida
    assert abs(mc.costo_llamada(700, 180) - 0.00016) < 1e-9


def test_la_proyeccion_escala_linealmente():
    p = mc.proyeccion(200, 700, 180)
    assert abs(p["por_dia"] - 200 * p["por_llamada"]) < 1e-12 and abs(p["por_mes"] - 30 * p["por_dia"]) < 1e-12


def test_el_peor_caso_cuesta_mas_que_el_tipico_y_cabe_en_el_tope_de_salida():
    costos = [mc.costo_llamada(i, o) for _, i, o in mc.ESCENARIOS]
    assert costos == sorted(costos)
    assert max(o for _, _, o in mc.ESCENARIOS) <= 500   # IA_MAX_TOKENS_SALIDA por defecto
