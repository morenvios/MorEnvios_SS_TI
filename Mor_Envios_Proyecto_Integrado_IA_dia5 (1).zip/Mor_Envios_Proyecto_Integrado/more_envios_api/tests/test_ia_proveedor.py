"""Compatibilidad con Claude Haiku 5.5 (jueves), según la documentación oficial del proveedor.

Lo que dice la documentación y estas pruebas fijan:
  * El razonamiento adaptativo viene activo por defecto y CUENTA dentro de max_tokens: un tope chico
    puede cortar la respuesta tras pensar y antes de escribir texto (stop_reason "max_tokens").
  * La palanca recomendada es output_config.effort (low/medium/high/xhigh/max; por defecto medium).
  * temperature, top_p, top_k y un mensaje "assistant" de arranque (prefill) devuelven 400.
  * La respuesta puede traer bloques "thinking" antes del texto y stop_reason "refusal".
No se probó contra el proveedor real (no hay clave): esto fija el contrato que se leyó en la documentación.
"""
import json
import logging

import httpx
import pytest

from app.config_ia import ConfigIA, cargar_config_ia
from app.ia import ServicioIA, get_servicio_ia
from app.main import app
from tests.test_ia import BUENAS, CLAVE_IA, Proveedor, config, url


@pytest.fixture
def armar(client):
    def _armar(proveedor=None, **cambios):
        proveedor = proveedor or Proveedor()
        servicio = ServicioIA(config(**cambios), transport=httpx.MockTransport(proveedor))
        app.dependency_overrides[get_servicio_ia] = lambda: servicio
        return client, proveedor, servicio
    return _armar


# ---------- lo que se ENVÍA ----------
def test_se_envia_el_esfuerzo_por_output_config(armar):
    client, proveedor, _ = armar(esfuerzo="low")
    client.post(url("MEV-2026-000005"), json={})
    assert proveedor.cuerpo()["output_config"] == {"effort": "low"}


@pytest.mark.parametrize("nivel", ["low", "medium", "high"])
def test_el_nivel_configurado_es_el_que_se_envia(armar, nivel):
    client, proveedor, _ = armar(esfuerzo=nivel)
    client.post(url("MEV-2026-000005"), json={})
    assert proveedor.cuerpo()["output_config"]["effort"] == nivel


def test_esfuerzo_vacio_no_envia_output_config(armar):
    # Modelos que no soportan "effort" (p. ej. Haiku 4.5) lo rechazan: debe poder omitirse.
    client, proveedor, _ = armar(esfuerzo="")
    client.post(url("MEV-2026-000005"), json={})
    assert "output_config" not in proveedor.cuerpo()


def test_nunca_se_envian_parametros_que_haiku_5_5_rechaza(armar):
    client, proveedor, _ = armar()
    client.post(url("MEV-2026-000005"), json={"pregunta": "hola"})
    cuerpo = proveedor.cuerpo()
    for prohibido in ("temperature", "top_p", "top_k", "budget_tokens"):
        assert prohibido not in cuerpo
    assert "thinking" not in cuerpo                     # se deja el razonamiento adaptativo por defecto
    mensajes = cuerpo["messages"]
    assert [m["role"] for m in mensajes] == ["user"]    # sin "prefill" de assistant (da 400)


def test_el_esfuerzo_por_defecto_es_low_y_el_tope_de_salida_deja_espacio_para_razonar():
    cfg = cargar_config_ia({"IA_HABILITADA": "1", "IA_API_KEY": CLAVE_IA})
    assert cfg.esfuerzo == "low" and cfg.max_tokens_salida == 500
    assert ConfigIA().esfuerzo == "low" and ConfigIA().max_tokens_salida == 500


@pytest.mark.parametrize("valor,ok", [("low", True), ("MEDIUM", True), ("high", True), ("", True),
                                      ("xhigh", False), ("max", False), ("adaptive", False), ("bajo", False)])
def test_validacion_de_ia_esfuerzo(valor, ok):
    env = {"IA_HABILITADA": "1", "IA_API_KEY": CLAVE_IA, "IA_ESFUERZO": valor}
    if ok:
        assert cargar_config_ia(env).esfuerzo == valor.lower()
    else:
        with pytest.raises(RuntimeError):
            cargar_config_ia(env)


# ---------- lo que se RECIBE ----------
def respuesta(bloques, stop="end_turn", uso=None):
    return {"content": bloques, "stop_reason": stop, "usage": uso or {"input_tokens": 700, "output_tokens": 180}}


def test_los_bloques_de_razonamiento_se_ignoran_y_se_usa_el_texto(armar):
    cuerpo = respuesta([
        {"type": "thinking", "thinking": "", "signature": "EqQBCkYIARgC..."},
        {"type": "text", "text": BUENAS["en_transito"]},
    ])
    client, _, _ = armar(Proveedor(json_respuesta=cuerpo))
    r = client.post(url("MEV-2026-000005"), json={}).json()
    assert r["origen"] == "ia" and r["resumen"] == "Tu envío va en tránsito."


def test_varios_bloques_de_texto_y_de_razonamiento_mezclados(armar):
    mitad = BUENAS["en_transito"]
    cuerpo = respuesta([{"type": "thinking", "thinking": "", "signature": "x"},
                        {"type": "redacted_thinking", "data": "abc"},
                        {"type": "text", "text": mitad}])
    client, _, _ = armar(Proveedor(json_respuesta=cuerpo))
    assert client.post(url("MEV-2026-000005"), json={}).json()["origen"] == "ia"


def test_solo_razonamiento_sin_texto_cae_en_plantilla(armar, caplog):
    caplog.set_level(logging.INFO, logger="more_envios")
    cuerpo = respuesta([{"type": "thinking", "thinking": "", "signature": "x"}], stop="end_turn")
    client, _, _ = armar(Proveedor(json_respuesta=cuerpo))
    r = client.post(url("MEV-2026-000005"), json={}).json()
    assert r["origen"] == "plantilla" and "motivo=respuesta_invalida" in caplog.text


def test_stop_reason_max_tokens_se_registra_como_tal(armar, caplog):
    """El caso que más preocupa: gastó el tope razonando. Debe verse con nombre propio en el log."""
    caplog.set_level(logging.INFO, logger="more_envios")
    cuerpo = respuesta([{"type": "thinking", "thinking": "", "signature": "x"}], stop="max_tokens",
                       uso={"input_tokens": 700, "output_tokens": 500})
    client, _, _ = armar(Proveedor(json_respuesta=cuerpo))
    r = client.post(url("MEV-2026-000005"), json={}).json()
    assert r["origen"] == "plantilla" and r["estado_actual"] == "en_transito"
    assert "motivo=max_tokens" in caplog.text
    assert "tokens_in=700 tokens_out=500" in caplog.text   # el costo de la respuesta cortada queda registrado


def test_texto_truncado_por_max_tokens_no_se_usa_aunque_parezca_json(armar):
    truncado = respuesta([{"type": "text", "text": BUENAS["en_transito"]}], stop="max_tokens")
    client, _, _ = armar(Proveedor(json_respuesta=truncado))
    assert client.post(url("MEV-2026-000005"), json={}).json()["origen"] == "plantilla"


def test_stop_reason_refusal_cae_en_plantilla_y_se_registra(armar, caplog):
    caplog.set_level(logging.INFO, logger="more_envios")
    cuerpo = respuesta([], stop="refusal")
    cuerpo["stop_details"] = {"category": "general_harms"}
    client, proveedor, _ = armar(Proveedor(json_respuesta=cuerpo))
    r = client.post(url("MEV-2026-000009"), json={}).json()
    assert r["origen"] == "plantilla" and r["requiere_atencion"] is True
    assert "motivo=rechazo_proveedor" in caplog.text and proveedor.llamadas == 1  # sin reintento: daría otro rechazo
    assert "tokens_in=700" in caplog.text


def test_stop_reason_normal_no_afecta(armar):
    client, _, _ = armar(Proveedor(json_respuesta=respuesta([{"type": "text", "text": BUENAS["en_transito"]}], stop="end_turn")))
    assert client.post(url("MEV-2026-000005"), json={}).json()["origen"] == "ia"
    client, _, _ = armar(Proveedor(json_respuesta=respuesta([{"type": "text", "text": BUENAS["en_transito"]}], stop="stop_sequence")))
    assert client.post(url("MEV-2026-000005"), json={}).json()["origen"] == "ia"
