"""Pruebas de resumen_log.py, la herramienta con la que se opera la IA leyendo el log."""
import pytest

import resumen_log as rl

P = "2026-10-30 10:00:{s:02d},123 {nivel} more_envios "


def ok(s=0, lat=900, tin=700, tout=150, usuario="operador1"):
    return P.format(s=s, nivel="INFO") + f"ia_ok usuario={usuario} guia=MEV-2026-000005 estado=en_transito latencia_ms={lat} tokens_in={tin} tokens_out={tout}"


def resp(motivo, s=0, tin="None", tout="None", usuario="operador1", nivel="WARNING"):
    return P.format(s=s, nivel=nivel) + f"ia_respaldo usuario={usuario} guia=MEV-2026-000009 motivo={motivo} tokens_in={tin} tokens_out={tout}"


def test_cuenta_ok_respaldos_y_tasa():
    lineas = [ok(i) for i in range(8)] + [resp("timeout", 9), resp("http_500", 10)]
    r = rl.analizar(lineas)
    assert (r["llamadas_con_ia"], r["ok"], r["respaldos"]) == (10, 8, 2) and r["tasa_de_respaldo"] == 0.2
    assert r["motivos"] == {"timeout": 1, "http_500": 1}
    assert r["desde"] == "2026-10-30 10:00:00" and r["hasta"] == "2026-10-30 10:00:10"


def test_la_ia_apagada_a_proposito_no_cuenta_como_falla():
    r = rl.analizar([resp("ia_apagada", i, nivel="INFO") for i in range(30)] + [ok(40)])
    assert r["respondidas_con_ia_apagada"] == 30 and r["respaldos"] == 0 and r["tasa_de_respaldo"] == 0.0
    assert rl.alertas(r) == []


def test_latencia_tokens_y_costo():
    r = rl.analizar([ok(i, lat=100 * (i + 1), tin=1000, tout=100) for i in range(10)])
    assert r["latencia_ms"] == {"p50": 600, "p95": 1000, "max": 1000}
    assert r["tokens"] == {"entrada": 10000, "salida": 1000}
    assert r["costo_usd_estimado"] == pytest.approx((10000 * 0.10 + 1000 * 0.50) / 1e6)


def test_el_costo_de_los_respaldos_con_tokens_tambien_se_cuenta():
    r = rl.analizar([resp("max_tokens", 1, tin="700", tout="500"), ok(2, tin=700, tout=100)])
    assert r["tokens"] == {"entrada": 1400, "salida": 600}


def test_lineas_ajenas_o_raras_se_ignoran():
    r = rl.analizar(["INFO: 127.0.0.1 - GET /health 200", "", "basura ia_ok sin formato", ok(1)])
    assert r["ok"] == 1 and r["respaldos"] == 0


def test_sin_datos_no_revienta():
    r = rl.analizar([])
    assert r["llamadas_con_ia"] == 0 and r["latencia_ms"]["p95"] is None and rl.alertas(r) == []


# ---------- alertas ----------
def test_tasa_de_respaldo_alta_alerta_solo_con_suficientes_llamadas():
    poca = rl.analizar([resp("timeout", i) for i in range(5)])
    assert rl.alertas(poca) == []                                   # 5 llamadas: aún no es confiable
    mucha = rl.analizar([ok(i) for i in range(6)] + [resp("timeout", 10 + i) for i in range(6)])
    assert any("tasa de respaldo" in x for x in rl.alertas(mucha))


@pytest.mark.parametrize("motivo", ["credencial_rechazada", "rechazo_proveedor", "max_tokens", "saturado"])
def test_los_motivos_criticos_alertan_con_una_sola_aparicion(motivo):
    r = rl.analizar([ok(i) for i in range(20)] + [resp(motivo, 30)])
    alts = rl.alertas(r)
    assert alts and alts[0].startswith("CRÍTICA") and motivo in alts[0]


def test_los_motivos_normales_no_son_criticos():
    r = rl.analizar([ok(i) for i in range(20)] + [resp("timeout", 30), resp("estado_incoherente", 31)])
    assert rl.alertas(r) == []                                      # 2 de 22 = 9 %: dentro de lo esperado


def test_latencia_p95_alta_alerta():
    r = rl.analizar([ok(i, lat=9000) for i in range(12)])
    assert any("p95" in x for x in rl.alertas(r))


def lim(tipo, s=0, usuario="operador2"):
    return P.format(s=s, nivel="WARNING") + f"ia_limite usuario={usuario} tipo={tipo}"


def test_los_topes_de_uso_se_cuentan_y_alertan():
    r = rl.analizar([ok(i) for i in range(5)] + [lim("minuto", 10 + i) for i in range(4)])
    assert r["frenadas_por_tope"] == {"minuto": 4} and r["frenados_por_usuario"] == {"operador2": 4}
    assert r["llamadas_con_ia"] == 5                      # un 429 no es una llamada al proveedor ni un respaldo
    alts = rl.alertas(r)
    assert len(alts) == 1 and alts[0].startswith("MEDIA") and "operador2 (4)" in alts[0]


def test_el_tope_diario_agotado_es_alta():
    alts = rl.alertas(rl.analizar([lim("diario", i) for i in range(3)]))
    assert alts and alts[0].startswith("ALTA") and "tope diario" in alts[0]


def test_el_servicio_registra_ia_limite_con_el_formato_que_lee_el_resumen(client, caplog):
    import logging

    import httpx

    from app.ia import ServicioIA, get_servicio_ia
    from app.main import app
    from tests.test_ia import Proveedor, config, url

    servicio = ServicioIA(config(limite_por_min=1, limite_diario=100), transport=httpx.MockTransport(Proveedor()))
    app.dependency_overrides[get_servicio_ia] = lambda: servicio
    caplog.set_level(logging.INFO, logger="more_envios")
    client.post(url("MEV-2026-000005"), json={})
    assert client.post(url("MEV-2026-000005"), json={}).status_code == 429         # tope por minuto
    servicio2 = ServicioIA(config(limite_por_min=100, limite_diario=1), transport=httpx.MockTransport(Proveedor()))
    app.dependency_overrides[get_servicio_ia] = lambda: servicio2
    client.post(url("MEV-2026-000005"), json={})
    assert client.post(url("MEV-2026-000005"), json={}).status_code == 429         # tope diario
    lineas = [f"2026-10-30 10:00:00,000 {r.levelname} more_envios {r.getMessage()}" for r in caplog.records]
    assert rl.analizar(lineas)["frenadas_por_tope"] == {"minuto": 1, "diario": 1}
    assert "pregunta" not in caplog.text and "MEV-2026" not in "".join(l for l in lineas if "ia_limite" in l)


def test_el_resumen_no_imprime_guias_ni_claves(capsys):
    lineas = [ok(1), resp("timeout", 2)]
    res = rl.analizar(lineas)
    rl.imprimir(res, rl.alertas(res))
    salida = capsys.readouterr().out
    assert "MEV-2026" not in salida and "sk-ant" not in salida


def test_main_devuelve_codigo_segun_haya_alertas(tmp_path, capsys):
    bueno = tmp_path / "bueno.log"; bueno.write_text("\n".join(ok(i) for i in range(12)), encoding="utf-8")
    malo = tmp_path / "malo.log"; malo.write_text("\n".join([ok(i) for i in range(12)] + [resp("credencial_rechazada", 40)]), encoding="utf-8")
    assert rl.main([str(bueno)]) == 0 and "Sin alertas" in capsys.readouterr().out
    assert rl.main([str(malo)]) == 1 and "CRÍTICA" in capsys.readouterr().out


def test_funciona_con_el_formato_real_del_log_de_la_api(client, caplog):
    """El formato lo genera ia.py: si alguien lo cambia, esta prueba avisa que el lector dejó de entenderlo."""
    import logging

    import httpx

    from app.ia import ServicioIA, get_servicio_ia
    from app.main import app
    from tests.test_ia import Proveedor, config, url

    def conectar(proveedor):
        servicio = ServicioIA(config(), transport=httpx.MockTransport(proveedor))
        app.dependency_overrides[get_servicio_ia] = lambda: servicio

    caplog.set_level(logging.INFO, logger="more_envios")
    for proveedor in (Proveedor(), Proveedor(status=500)):      # una llamada buena y una con respaldo
        conectar(proveedor)
        assert client.post(url("MEV-2026-000005"), json={}).status_code == 200
    lineas = [f"2026-10-30 10:00:00,000 {r.levelname} more_envios {r.getMessage()}" for r in caplog.records]
    res = rl.analizar(lineas)
    assert res["ok"] == 1 and res["respaldos"] == 1 and res["motivos"] == {"http_500": 1}
    assert res["tokens"] == {"entrada": 310, "salida": 42}          # los que informa el proveedor falso
