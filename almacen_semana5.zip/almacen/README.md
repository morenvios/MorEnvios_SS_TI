# Almacén: modelo relacional + API REST (Semana 5)

## Puesta en marcha
```bash
docker compose up -d                  # PostgreSQL 16
pip install -r requirements.txt
python db/migrate.py                  # esquema + datos semilla (reproducible)
uvicorn app.main:app --reload         # API en http://localhost:8000/docs
pytest -v                             # pruebas
```
Variable opcional: `DATABASE_URL=postgresql://usuario:clave@host:5432/bd`

## Contenido
| Entregable | Archivo |
|---|---|
| Diagrama ER y reglas de negocio | docs/diagrama_er.md |
| Diccionario de datos | docs/diccionario_datos.md |
| Migraciones y datos semilla | db/migrations/, db/migrate.py |
| API REST con persistencia y paginación | app/main.py |
| Consultas de negocio | db/consultas_negocio.sql |
| Reporte de pruebas | reporte_pruebas.md, tests/ |

## Endpoints
`GET /productos?page=&size=&q=&categoria_id=` · `GET /productos/{id}` · `POST /productos` · `DELETE /productos/{id}` (baja lógica) · `POST /movimientos` (transaccional) · `GET /inventario` · `GET /reportes/stock-bajo`
