import os
from math import ceil
from typing import Literal, Optional

import psycopg
from psycopg import errors
from psycopg.rows import dict_row
from fastapi import Depends, FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

URL = os.getenv("DATABASE_URL", "postgresql://almacen:almacen@localhost:5432/almacen")
app = FastAPI(title="API de Almacén")


def get_conn():
    # autocommit=True: las transacciones se controlan explícitamente con conn.transaction()
    with psycopg.connect(URL, row_factory=dict_row, autocommit=True) as conn:
        yield conn


class ProductoIn(BaseModel):
    sku: str = Field(min_length=1, max_length=30)
    nombre: str = Field(min_length=1, max_length=120)
    precio: float = Field(ge=0)
    stock_minimo: int = Field(default=0, ge=0)
    categoria_id: int
    proveedor_id: int


class MovimientoIn(BaseModel):
    producto_id: int
    almacen_id: int
    tipo: Literal["ENTRADA", "SALIDA"]
    cantidad: int = Field(gt=0)
    motivo: Optional[str] = Field(default=None, max_length=200)


@app.get("/productos")
def listar_productos(
    page: int = Query(1, ge=1),
    size: int = Query(10, ge=1, le=100),
    q: Optional[str] = None,
    categoria_id: Optional[int] = None,
    conn=Depends(get_conn),
):
    filtros, params = ["activo"], []
    if q:
        filtros.append("(nombre ILIKE %s OR sku ILIKE %s)")
        params += [f"%{q}%", f"%{q}%"]
    if categoria_id:
        filtros.append("categoria_id = %s")
        params.append(categoria_id)
    where = " AND ".join(filtros)
    total = conn.execute(f"SELECT COUNT(*) AS n FROM productos WHERE {where}", params).fetchone()["n"]
    items = conn.execute(
        f"SELECT * FROM productos WHERE {where} ORDER BY id LIMIT %s OFFSET %s",
        params + [size, (page - 1) * size],
    ).fetchall()
    return {"items": items, "total": total, "page": page, "pages": ceil(total / size)}


@app.get("/productos/{producto_id}")
def obtener_producto(producto_id: int, conn=Depends(get_conn)):
    row = conn.execute("SELECT * FROM productos WHERE id = %s", (producto_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Producto no encontrado")
    return row


@app.post("/productos", status_code=201)
def crear_producto(p: ProductoIn, conn=Depends(get_conn)):
    try:
        return conn.execute(
            """INSERT INTO productos (sku, nombre, precio, stock_minimo, categoria_id, proveedor_id)
               VALUES (%s,%s,%s,%s,%s,%s) RETURNING *""",
            (p.sku, p.nombre, p.precio, p.stock_minimo, p.categoria_id, p.proveedor_id),
        ).fetchone()
    except errors.UniqueViolation:
        raise HTTPException(409, "El SKU ya existe")
    except errors.ForeignKeyViolation:
        raise HTTPException(422, "Categoría o proveedor inexistente")


@app.delete("/productos/{producto_id}", status_code=204)
def desactivar_producto(producto_id: int, conn=Depends(get_conn)):
    # Baja lógica: preserva el historial de movimientos
    r = conn.execute("UPDATE productos SET activo = FALSE WHERE id = %s", (producto_id,))
    if r.rowcount == 0:
        raise HTTPException(404, "Producto no encontrado")


@app.post("/movimientos", status_code=201)
def registrar_movimiento(m: MovimientoIn, conn=Depends(get_conn)):
    """Actualiza inventario y registra el movimiento en UNA transacción atómica."""
    delta = m.cantidad if m.tipo == "ENTRADA" else -m.cantidad
    try:
        with conn.transaction():
            conn.execute(
                "INSERT INTO inventario (producto_id, almacen_id, cantidad) VALUES (%s,%s,0) ON CONFLICT DO NOTHING",
                (m.producto_id, m.almacen_id),
            )
            inv = conn.execute(
                "UPDATE inventario SET cantidad = cantidad + %s WHERE producto_id=%s AND almacen_id=%s RETURNING cantidad",
                (delta, m.producto_id, m.almacen_id),
            ).fetchone()
            mov = conn.execute(
                """INSERT INTO movimientos (producto_id, almacen_id, tipo, cantidad, motivo)
                   VALUES (%s,%s,%s,%s,%s) RETURNING *""",
                (m.producto_id, m.almacen_id, m.tipo, m.cantidad, m.motivo),
            ).fetchone()
        return {"movimiento": mov, "existencia_actual": inv["cantidad"]}
    except errors.CheckViolation:
        raise HTTPException(409, "Existencias insuficientes")
    except errors.ForeignKeyViolation:
        raise HTTPException(422, "Producto o almacén inexistente")


@app.get("/inventario")
def inventario(page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100), conn=Depends(get_conn)):
    total = conn.execute("SELECT COUNT(*) AS n FROM inventario").fetchone()["n"]
    items = conn.execute(
        """SELECT p.sku, p.nombre, a.nombre AS almacen, i.cantidad
           FROM inventario i JOIN productos p ON p.id=i.producto_id JOIN almacenes a ON a.id=i.almacen_id
           ORDER BY p.sku, a.nombre LIMIT %s OFFSET %s""",
        (size, (page - 1) * size),
    ).fetchall()
    return {"items": items, "total": total, "page": page, "pages": ceil(total / size)}


@app.get("/reportes/stock-bajo")
def stock_bajo(conn=Depends(get_conn)):
    return conn.execute(
        """SELECT p.sku, p.nombre, p.stock_minimo, COALESCE(SUM(i.cantidad),0)::int AS stock_total
           FROM productos p LEFT JOIN inventario i ON i.producto_id = p.id
           WHERE p.activo GROUP BY p.id
           HAVING COALESCE(SUM(i.cantidad),0) < p.stock_minimo ORDER BY p.nombre"""
    ).fetchall()
