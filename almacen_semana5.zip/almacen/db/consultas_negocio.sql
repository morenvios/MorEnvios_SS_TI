-- 1. Existencias totales por producto (JOIN + agregado)
SELECT p.sku, p.nombre, COALESCE(SUM(i.cantidad),0) AS stock_total
FROM productos p
LEFT JOIN inventario i ON i.producto_id = p.id
GROUP BY p.id ORDER BY stock_total DESC;

-- 2. Productos por debajo del stock mínimo (HAVING)
SELECT p.sku, p.nombre, p.stock_minimo, COALESCE(SUM(i.cantidad),0) AS stock_total
FROM productos p
LEFT JOIN inventario i ON i.producto_id = p.id
WHERE p.activo
GROUP BY p.id
HAVING COALESCE(SUM(i.cantidad),0) < p.stock_minimo
ORDER BY p.nombre;

-- 3. Valor del inventario por categoría
SELECT c.nombre AS categoria, SUM(i.cantidad * p.precio) AS valor_inventario
FROM categorias c
JOIN productos p   ON p.categoria_id = c.id
JOIN inventario i  ON i.producto_id = p.id
GROUP BY c.nombre ORDER BY valor_inventario DESC;

-- 4. Salidas de los últimos 30 días por producto
SELECT p.nombre, SUM(m.cantidad) AS total_salidas
FROM movimientos m JOIN productos p ON p.id = m.producto_id
WHERE m.tipo = 'SALIDA' AND m.fecha >= now() - interval '30 days'
GROUP BY p.nombre ORDER BY total_salidas DESC;

-- 5. Productos sin ningún movimiento (LEFT JOIN + IS NULL)
SELECT p.sku, p.nombre
FROM productos p LEFT JOIN movimientos m ON m.producto_id = p.id
WHERE m.id IS NULL;

-- 6. Proveedores y cuántos productos surten
SELECT pr.nombre, COUNT(p.id) AS productos
FROM proveedores pr LEFT JOIN productos p ON p.proveedor_id = pr.id
GROUP BY pr.nombre ORDER BY productos DESC;

-- 7. Paginación (página 2, 3 por página)
SELECT id, sku, nombre FROM productos ORDER BY id LIMIT 3 OFFSET 3;

-- 8. Actualización y borrado (usar dentro de una transacción de prueba)
BEGIN;
UPDATE productos SET precio = precio * 1.05 WHERE categoria_id = 1;
-- Borrar un producto con movimientos FALLA por ON DELETE RESTRICT (integridad):
-- DELETE FROM productos WHERE id = 1;
ROLLBACK;
