"""Aplica las migraciones .sql de db/migrations en orden, una sola vez cada una."""
import os, pathlib, psycopg

URL = os.getenv("DATABASE_URL", "postgresql://almacen:almacen@localhost:5432/almacen")
DIR = pathlib.Path(__file__).parent / "migrations"

with psycopg.connect(URL) as conn:
    conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations (nombre TEXT PRIMARY KEY, aplicada_en TIMESTAMPTZ DEFAULT now())")
    hechas = {r[0] for r in conn.execute("SELECT nombre FROM schema_migrations")}
    for f in sorted(DIR.glob("*.sql")):
        if f.name in hechas:
            print("omitida :", f.name); continue
        conn.execute(f.read_text(encoding="utf-8"))
        conn.execute("INSERT INTO schema_migrations (nombre) VALUES (%s)", (f.name,))
        print("aplicada:", f.name)
