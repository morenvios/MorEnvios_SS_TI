CREATE TABLE categorias (
    id      SERIAL PRIMARY KEY,
    nombre  VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE proveedores (
    id        SERIAL PRIMARY KEY,
    nombre    VARCHAR(120) NOT NULL,
    email     VARCHAR(120) UNIQUE,
    telefono  VARCHAR(20)
);

CREATE TABLE almacenes (
    id         SERIAL PRIMARY KEY,
    nombre     VARCHAR(80) NOT NULL UNIQUE,
    ubicacion  VARCHAR(150)
);

CREATE TABLE productos (
    id            SERIAL PRIMARY KEY,
    sku           VARCHAR(30) NOT NULL UNIQUE,
    nombre        VARCHAR(120) NOT NULL,
    precio        NUMERIC(10,2) NOT NULL CHECK (precio >= 0),
    stock_minimo  INTEGER NOT NULL DEFAULT 0 CHECK (stock_minimo >= 0),
    categoria_id  INTEGER NOT NULL REFERENCES categorias(id) ON DELETE RESTRICT,
    proveedor_id  INTEGER NOT NULL REFERENCES proveedores(id) ON DELETE RESTRICT,
    activo        BOOLEAN NOT NULL DEFAULT TRUE,
    creado_en     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Existencias actuales por producto y almacén (nunca negativas)
CREATE TABLE inventario (
    producto_id  INTEGER NOT NULL REFERENCES productos(id) ON DELETE RESTRICT,
    almacen_id   INTEGER NOT NULL REFERENCES almacenes(id) ON DELETE RESTRICT,
    cantidad     INTEGER NOT NULL DEFAULT 0 CHECK (cantidad >= 0),
    PRIMARY KEY (producto_id, almacen_id)
);

-- Historial de entradas y salidas (auditoría)
CREATE TABLE movimientos (
    id           BIGSERIAL PRIMARY KEY,
    producto_id  INTEGER NOT NULL REFERENCES productos(id) ON DELETE RESTRICT,
    almacen_id   INTEGER NOT NULL REFERENCES almacenes(id) ON DELETE RESTRICT,
    tipo         VARCHAR(7) NOT NULL CHECK (tipo IN ('ENTRADA','SALIDA')),
    cantidad     INTEGER NOT NULL CHECK (cantidad > 0),
    motivo       VARCHAR(200),
    fecha        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_productos_categoria ON productos(categoria_id);
CREATE INDEX idx_productos_proveedor ON productos(proveedor_id);
CREATE INDEX idx_movimientos_producto_fecha ON movimientos(producto_id, fecha DESC);
