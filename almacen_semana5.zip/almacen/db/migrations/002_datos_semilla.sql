INSERT INTO categorias (nombre) VALUES
 ('Electrónica'), ('Papelería'), ('Limpieza'), ('Herramientas');

INSERT INTO proveedores (nombre, email, telefono) VALUES
 ('TecnoMex SA', 'ventas@tecnomex.example', '2721000001'),
 ('Papelera del Centro', 'contacto@papelera.example', '2721000002'),
 ('Limpio y Más', 'pedidos@limpiomas.example', '2721000003');

INSERT INTO almacenes (nombre, ubicacion) VALUES
 ('Central', 'Orizaba, Veracruz'),
 ('Sucursal Norte', 'Córdoba, Veracruz');

INSERT INTO productos (sku, nombre, precio, stock_minimo, categoria_id, proveedor_id) VALUES
 ('ELE-001', 'Cable USB-C 1m',        89.00, 20, 1, 1),
 ('ELE-002', 'Audífonos alámbricos', 150.00, 10, 1, 1),
 ('PAP-001', 'Cuaderno profesional',  45.50, 30, 2, 2),
 ('PAP-002', 'Caja de plumas (12)',   60.00, 15, 2, 2),
 ('LIM-001', 'Cloro 1L',              28.00, 25, 3, 3),
 ('LIM-002', 'Jabón líquido 500ml',   35.00, 20, 3, 3),
 ('HER-001', 'Martillo 16oz',        120.00,  5, 4, 1);

INSERT INTO inventario (producto_id, almacen_id, cantidad) VALUES
 (1,1,50),(1,2,10),(2,1,8),(3,1,100),(3,2,25),
 (4,1,12),(5,1,60),(6,1,5),(7,1,15);

INSERT INTO movimientos (producto_id, almacen_id, tipo, cantidad, motivo, fecha) VALUES
 (1,1,'ENTRADA',60,'Compra inicial', now() - interval '20 days'),
 (1,1,'SALIDA',10,'Venta',          now() - interval '10 days'),
 (3,1,'ENTRADA',100,'Compra inicial',now() - interval '25 days'),
 (2,1,'ENTRADA',15,'Compra inicial', now() - interval '15 days'),
 (2,1,'SALIDA',7,'Venta',            now() - interval '3 days'),
 (6,1,'ENTRADA',20,'Compra inicial', now() - interval '12 days'),
 (6,1,'SALIDA',15,'Venta',           now() - interval '2 days');
