# Diagrama Entidad-Relación

```mermaid
erDiagram
    CATEGORIAS ||--o{ PRODUCTOS : clasifica
    PROVEEDORES ||--o{ PRODUCTOS : surte
    PRODUCTOS ||--o{ INVENTARIO : "existe en"
    ALMACENES ||--o{ INVENTARIO : guarda
    PRODUCTOS ||--o{ MOVIMIENTOS : registra
    ALMACENES ||--o{ MOVIMIENTOS : "ocurre en"

    CATEGORIAS { int id PK  varchar nombre UK }
    PROVEEDORES { int id PK  varchar nombre  varchar email UK  varchar telefono }
    ALMACENES { int id PK  varchar nombre UK  varchar ubicacion }
    PRODUCTOS { int id PK  varchar sku UK  varchar nombre  numeric precio  int stock_minimo  int categoria_id FK  int proveedor_id FK  bool activo  timestamptz creado_en }
    INVENTARIO { int producto_id PK,FK  int almacen_id PK,FK  int cantidad }
    MOVIMIENTOS { bigint id PK  int producto_id FK  int almacen_id FK  varchar tipo  int cantidad  varchar motivo  timestamptz fecha }
```

## Reglas de negocio
1. Todo producto pertenece a una categoría y tiene un proveedor.
2. El SKU es único.
3. El precio y el stock mínimo no pueden ser negativos.
4. Las existencias se llevan por producto y almacén y nunca pueden ser negativas.
5. Toda entrada o salida queda registrada y su cantidad es mayor que cero.
6. No se puede borrar físicamente un producto, categoría, proveedor o almacén con registros relacionados (`ON DELETE RESTRICT`). Los productos se dan de baja con `activo = FALSE`.
7. Una salida solo es válida si hay existencias suficientes. Inventario y movimiento se actualizan en una sola transacción.
