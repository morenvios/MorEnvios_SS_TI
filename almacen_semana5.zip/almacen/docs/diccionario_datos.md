# Diccionario de datos

## categorias
| Campo | Tipo | Restricciones | Descripción |
|---|---|---|---|
| id | SERIAL | PK | Identificador |
| nombre | VARCHAR(80) | NOT NULL, UNIQUE | Nombre de la categoría |

## proveedores
| Campo | Tipo | Restricciones | Descripción |
|---|---|---|---|
| id | SERIAL | PK | Identificador |
| nombre | VARCHAR(120) | NOT NULL | Razón social |
| email | VARCHAR(120) | UNIQUE | Correo de contacto |
| telefono | VARCHAR(20) | | Teléfono |

## almacenes
| Campo | Tipo | Restricciones | Descripción |
|---|---|---|---|
| id | SERIAL | PK | Identificador |
| nombre | VARCHAR(80) | NOT NULL, UNIQUE | Nombre del almacén |
| ubicacion | VARCHAR(150) | | Dirección o ciudad |

## productos
| Campo | Tipo | Restricciones | Descripción |
|---|---|---|---|
| id | SERIAL | PK | Identificador |
| sku | VARCHAR(30) | NOT NULL, UNIQUE | Código del producto |
| nombre | VARCHAR(120) | NOT NULL | Nombre |
| precio | NUMERIC(10,2) | NOT NULL, CHECK >= 0 | Precio unitario |
| stock_minimo | INTEGER | NOT NULL, DEFAULT 0, CHECK >= 0 | Umbral de reabasto |
| categoria_id | INTEGER | NOT NULL, FK categorias | Categoría |
| proveedor_id | INTEGER | NOT NULL, FK proveedores | Proveedor |
| activo | BOOLEAN | NOT NULL, DEFAULT TRUE | Baja lógica |
| creado_en | TIMESTAMPTZ | NOT NULL, DEFAULT now() | Fecha de alta |

## inventario
| Campo | Tipo | Restricciones | Descripción |
|---|---|---|---|
| producto_id | INTEGER | PK, FK productos | Producto |
| almacen_id | INTEGER | PK, FK almacenes | Almacén |
| cantidad | INTEGER | NOT NULL, DEFAULT 0, CHECK >= 0 | Existencia actual |

## movimientos
| Campo | Tipo | Restricciones | Descripción |
|---|---|---|---|
| id | BIGSERIAL | PK | Identificador |
| producto_id | INTEGER | NOT NULL, FK productos | Producto |
| almacen_id | INTEGER | NOT NULL, FK almacenes | Almacén |
| tipo | VARCHAR(7) | NOT NULL, CHECK IN ('ENTRADA','SALIDA') | Tipo de movimiento |
| cantidad | INTEGER | NOT NULL, CHECK > 0 | Unidades |
| motivo | VARCHAR(200) | | Compra, venta, ajuste… |
| fecha | TIMESTAMPTZ | NOT NULL, DEFAULT now() | Fecha y hora |
