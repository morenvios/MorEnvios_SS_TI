# Reporte de pruebas

Ejecuta `pytest -v` y pega aquí el resultado real.

| # | Prueba | Resultado esperado | Resultado obtenido |
|---|---|---|---|
| 1 | Paginación de productos | Máximo 3 items, total >= 7 | |
| 2 | Crear producto y repetir SKU | 201 y luego 409 | |
| 3 | Categoría inexistente | 422 | |
| 4 | Entrada de mercancía | 201, existencia aumenta | |
| 5 | Salida mayor a la existencia | 409 y inventario sin cambios (rollback) | |
| 6 | Cantidad 0 | 422 | |
| 7 | Reporte de stock bajo | 200 | |

## Auditoría de integridad (viernes)
- [ ] `DELETE FROM productos WHERE id = 1;` falla por `ON DELETE RESTRICT`
- [ ] `UPDATE inventario SET cantidad = -1 ...` falla por CHECK
- [ ] `INSERT INTO movimientos ... cantidad = 0` falla por CHECK
- [ ] Un producto con SKU repetido falla por UNIQUE
