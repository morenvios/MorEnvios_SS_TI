import uuid
from fastapi.testclient import TestClient
from app.main import app

c = TestClient(app)


def test_paginacion():
    r = c.get("/productos?page=1&size=3")
    assert r.status_code == 200
    d = r.json()
    assert len(d["items"]) <= 3 and d["total"] >= 7 and d["pages"] >= 3


def test_crear_producto_y_sku_duplicado():
    sku = "T-" + uuid.uuid4().hex[:8]
    body = {"sku": sku, "nombre": "Prueba", "precio": 10, "categoria_id": 1, "proveedor_id": 1}
    assert c.post("/productos", json=body).status_code == 201
    assert c.post("/productos", json=body).status_code == 409


def test_fk_invalida():
    body = {"sku": "X-" + uuid.uuid4().hex[:8], "nombre": "X", "precio": 1, "categoria_id": 999, "proveedor_id": 1}
    assert c.post("/productos", json=body).status_code == 422


def test_entrada_aumenta_existencia():
    r = c.post("/movimientos", json={"producto_id": 7, "almacen_id": 2, "tipo": "ENTRADA", "cantidad": 5})
    assert r.status_code == 201 and r.json()["existencia_actual"] >= 5


def test_salida_excesiva_rechazada_y_sin_efectos():
    antes = c.get("/inventario?size=100").json()["items"]
    r = c.post("/movimientos", json={"producto_id": 1, "almacen_id": 1, "tipo": "SALIDA", "cantidad": 10**6})
    assert r.status_code == 409
    despues = c.get("/inventario?size=100").json()["items"]
    assert antes == despues  # la transacción hizo rollback


def test_cantidad_invalida():
    r = c.post("/movimientos", json={"producto_id": 1, "almacen_id": 1, "tipo": "SALIDA", "cantidad": 0})
    assert r.status_code == 422


def test_reporte_stock_bajo():
    assert c.get("/reportes/stock-bajo").status_code == 200
