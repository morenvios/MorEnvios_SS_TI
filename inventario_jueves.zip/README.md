# API de Inventario

Proyecto de API REST para gestión de inventario de productos, desarrollado con FastAPI.

## Integrantes del equipo
- Alexander Fernandez

## Institución
Instituto Tecnológico Superior de Cosamaloapan (ITSCO)
Ingeniería en Sistemas Computacionales

## Descripción del proyecto
API que permite administrar un inventario de productos: crear, consultar, actualizar,
eliminar y registrar salidas de stock, con validaciones de datos y reglas de negocio
(SKU único, precio mayor a cero, control de stock disponible).

## Requisitos previos
- Python 3.10 o superior instalado (en este proyecto se usó Python 3.14 con el
  lanzador `py`).
- Tener el archivo del proyecto descomprimido en una carpeta local.

## Instalación

1. Abrir una terminal dentro de la carpeta del proyecto (la que contiene la carpeta `app`).
2. Instalar las dependencias del proyecto:

   py -m pip install -r requirements.txt

## Ejecución del servidor

Para iniciar la API en modo desarrollo:

   py -m uvicorn app.main:app --reload

Cuando aparezca el mensaje "Application startup complete", el servidor estará
funcionando en:

   http://127.0.0.1:8000

## Documentación interactiva (Swagger)

Con el servidor corriendo, abrir en el navegador:

   http://127.0.0.1:8000/docs

Ahí se pueden probar todas las rutas de la API de forma interactiva (crear
productos, listarlos, actualizarlos, eliminarlos y registrar salidas de stock).

## Pruebas automatizadas

El proyecto incluye un script de prueba rápida y una suite de pruebas con pytest.

Prueba rápida (smoke test):

   py smoke_test.py

Suite completa de pruebas unitarias e integración:

   py -m pytest -v

## Estructura del proyecto

- app/main.py: punto de entrada de la aplicación FastAPI.
- app/models.py: modelos de datos y validaciones (Pydantic).
- app/exceptions.py: errores de negocio personalizados.
- app/repositories/: acceso y almacenamiento de datos en memoria.
- app/services/: lógica de negocio (reglas de validación, control de stock).
- app/routers/: rutas de la API (endpoints).
- app/dependencies.py: inyección de dependencias entre capas.
- tests/: pruebas automatizadas con pytest.
- smoke_test.py: script de verificación rápida manual.

## Reglas de negocio principales

- El SKU de cada producto debe ser único; si se repite, la API responde con error 409.
- El precio debe ser mayor a 0 y la cantidad no puede ser negativa; si no se cumple,
  la API responde con error 422.
- No se puede registrar una salida de stock mayor a la cantidad disponible; si se
  intenta, la API responde con error 409.

## Códigos de respuesta esperados

- 200: operación exitosa (consulta, actualización).
- 201: producto creado exitosamente.
- 204: producto eliminado exitosamente.
- 404: producto no encontrado.
- 409: conflicto (SKU duplicado o stock insuficiente).
- 422: error de validación de datos.
