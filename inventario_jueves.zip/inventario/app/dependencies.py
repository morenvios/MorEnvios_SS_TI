"""Punto único donde se arma el servicio con sus dependencias (repositorio).
Las rutas piden el servicio ya armado en vez de construirlo cada una por su cuenta."""
from app.repositories.product_repository import ProductRepository
from app.services.product_service import ProductService

_repository = ProductRepository()
_service = ProductService(_repository)


def get_product_service() -> ProductService:
    return _service
