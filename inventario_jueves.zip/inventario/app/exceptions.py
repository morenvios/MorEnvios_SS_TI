class BusinessError(Exception):
    """Error de regla de negocio (no es un error de validación de formato)."""

    def __init__(self, message: str):
        self.message = message
        super().__init__(message)


class SkuDuplicadoError(BusinessError):
    def __init__(self, sku: str):
        super().__init__(f"Ya existe un producto con el SKU '{sku}'")


class StockInsuficienteError(BusinessError):
    def __init__(self, disponible: int, solicitado: int):
        super().__init__(
            f"Stock insuficiente: disponible {disponible}, solicitado {solicitado}"
        )


class ProductoNoEncontradoError(BusinessError):
    def __init__(self, product_id: int):
        super().__init__(f"Producto con id {product_id} no encontrado")
        self.product_id = product_id
