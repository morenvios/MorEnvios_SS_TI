from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.routers import products

app = FastAPI(title="API de Inventario", version="0.2.0")
app.include_router(products.router)


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    """Convierte los errores de validación de Pydantic en un formato más claro."""
    errores = [
        {"campo": ".".join(str(p) for p in e["loc"] if p != "body"), "mensaje": e["msg"]}
        for e in exc.errors()
    ]
    return JSONResponse(
        status_code=422,
        content={"detail": "Error de validación", "errores": errores},
    )


@app.get("/", tags=["Salud"])
def root():
    return {"status": "ok"}
