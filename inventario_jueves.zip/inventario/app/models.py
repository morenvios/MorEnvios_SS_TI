from typing import Optional
from pydantic import BaseModel, Field, field_validator


class ProductBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=80)
    sku: str = Field(..., min_length=2, max_length=20)
    category: str = Field(..., min_length=2, max_length=50)
    quantity: int = Field(default=0, ge=0)
    price: float = Field(..., gt=0)

    @field_validator("sku")
    @classmethod
    def sku_sin_espacios(cls, value: str) -> str:
        value = value.strip().upper()
        if " " in value:
            raise ValueError("El SKU no puede contener espacios")
        return value

    @field_validator("name", "category")
    @classmethod
    def no_vacio(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Este campo no puede estar vacío")
        return value


class ProductCreate(ProductBase):
    """Datos que envía el cliente para crear un producto."""


class ProductUpdate(BaseModel):
    """Todos los campos opcionales: sirve para PATCH."""
    name: Optional[str] = Field(default=None, min_length=2, max_length=80)
    sku: Optional[str] = Field(default=None, min_length=2, max_length=20)
    category: Optional[str] = Field(default=None, min_length=2, max_length=50)
    quantity: Optional[int] = Field(default=None, ge=0)
    price: Optional[float] = Field(default=None, gt=0)

    @field_validator("sku")
    @classmethod
    def sku_sin_espacios(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return value
        value = value.strip().upper()
        if " " in value:
            raise ValueError("El SKU no puede contener espacios")
        return value


class Product(ProductBase):
    """Producto ya guardado (incluye id)."""
    id: int
