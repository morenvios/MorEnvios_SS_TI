"""Capa de repositorio.

Se encarga únicamente de guardar y recuperar productos. No conoce reglas de
negocio (eso vive en la capa de servicio) ni nada de HTTP (eso vive en las rutas).
Hoy el almacenamiento es en memoria; si mañana cambiamos a una base de datos,
solo se modifica este archivo.

Cada instancia de ProductRepository tiene sus propios datos. Esto es importante
para las pruebas: cada prueba crea un repositorio nuevo y así no se mezclan
los datos de una prueba con otra.
"""
from typing import Dict, List, Optional
from app.models import Product


class ProductRepository:
    def __init__(self):
        self._products: Dict[int, Product] = {}
        self._next_id = 1

    def next_id(self) -> int:
        value = self._next_id
        self._next_id += 1
        return value

    def add(self, product: Product) -> Product:
        self._products[product.id] = product
        return product

    def get(self, product_id: int) -> Optional[Product]:
        return self._products.get(product_id)

    def list_all(self) -> List[Product]:
        return list(self._products.values())

    def update(self, product: Product) -> Product:
        self._products[product.id] = product
        return product

    def delete(self, product_id: int) -> None:
        del self._products[product_id]

    def find_by_sku(self, sku: str, ignore_id: Optional[int] = None) -> Optional[Product]:
        for product in self._products.values():
            if product.sku == sku and product.id != ignore_id:
                return product
        return None
