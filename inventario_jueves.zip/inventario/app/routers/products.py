from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status

from app.models import Product, ProductCreate, ProductUpdate
from app.services.product_service import ProductService
from app.dependencies import get_product_service
from app.exceptions import SkuDuplicadoError, StockInsuficienteError, ProductoNoEncontradoError

router = APIRouter(prefix="/products", tags=["Productos"])


def _manejar_business_error(error: Exception) -> HTTPException:
    if isinstance(error, ProductoNoEncontradoError):
        return HTTPException(status_code=404, detail=error.message)
    if isinstance(error, (SkuDuplicadoError, StockInsuficienteError)):
        return HTTPException(status_code=409, detail=error.message)
    return HTTPException(status_code=400, detail=str(error))


@router.post("/", response_model=Product, status_code=status.HTTP_201_CREATED)
def create_product(data: ProductCreate, service: ProductService = Depends(get_product_service)):
    try:
        return service.crear(data)
    except (SkuDuplicadoError, ProductoNoEncontradoError) as error:
        raise _manejar_business_error(error)


@router.get("/", response_model=List[Product])
def list_products(category: Optional[str] = None, service: ProductService = Depends(get_product_service)):
    return service.listar(category)


@router.get("/{product_id}", response_model=Product)
def get_product(product_id: int, service: ProductService = Depends(get_product_service)):
    try:
        return service.obtener(product_id)
    except ProductoNoEncontradoError as error:
        raise _manejar_business_error(error)


@router.put("/{product_id}", response_model=Product)
def replace_product(product_id: int, data: ProductCreate, service: ProductService = Depends(get_product_service)):
    try:
        return service.reemplazar(product_id, data)
    except (SkuDuplicadoError, ProductoNoEncontradoError) as error:
        raise _manejar_business_error(error)


@router.patch("/{product_id}", response_model=Product)
def update_product(product_id: int, data: ProductUpdate, service: ProductService = Depends(get_product_service)):
    try:
        return service.actualizar_parcial(product_id, data)
    except (SkuDuplicadoError, ProductoNoEncontradoError) as error:
        raise _manejar_business_error(error)


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_product(product_id: int, service: ProductService = Depends(get_product_service)):
    try:
        service.eliminar(product_id)
    except ProductoNoEncontradoError as error:
        raise _manejar_business_error(error)


@router.post("/{product_id}/salida", response_model=Product)
def registrar_salida(product_id: int, cantidad: int, service: ProductService = Depends(get_product_service)):
    try:
        return service.registrar_salida(product_id, cantidad)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error))
    except (StockInsuficienteError, ProductoNoEncontradoError) as error:
        raise _manejar_business_error(error)
