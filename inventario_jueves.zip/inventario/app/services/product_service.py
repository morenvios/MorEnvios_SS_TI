"""Capa de servicio.

Aquí viven las reglas de negocio: SKU único, control de stock, filtros, etc.
Esta capa usa al repositorio para guardar/leer datos, pero no sabe nada de
HTTP ni de FastAPI. Así, las rutas quedan simples y esta lógica se puede
probar de forma aislada.
"""
from typing import List, Optional

from app.models import Product, ProductCreate, ProductUpdate
from app.repositories.product_repository import ProductRepository
from app.exceptions import SkuDuplicadoError, StockInsuficienteError, ProductoNoEncontradoError


class ProductService:
    def __init__(self, repository: ProductRepository):
        self.repository = repository

    def _obtener_o_error(self, product_id: int) -> Product:
        product = self.repository.get(product_id)
        if product is None:
            raise ProductoNoEncontradoError(product_id)
        return product

    def crear(self, data: ProductCreate) -> Product:
        if self.repository.find_by_sku(data.sku) is not None:
            raise SkuDuplicadoError(data.sku)
        product = Product(id=self.repository.next_id(), **data.model_dump())
        return self.repository.add(product)

    def listar(self, category: Optional[str] = None) -> List[Product]:
        items = self.repository.list_all()
        if category:
            items = [p for p in items if p.category.lower() == category.lower()]
        return items

    def obtener(self, product_id: int) -> Product:
        return self._obtener_o_error(product_id)

    def reemplazar(self, product_id: int, data: ProductCreate) -> Product:
        self._obtener_o_error(product_id)
        if self.repository.find_by_sku(data.sku, ignore_id=product_id) is not None:
            raise SkuDuplicadoError(data.sku)
        product = Product(id=product_id, **data.model_dump())
        return self.repository.update(product)

    def actualizar_parcial(self, product_id: int, data: ProductUpdate) -> Product:
        product = self._obtener_o_error(product_id)
        if data.sku is not None:
            if self.repository.find_by_sku(data.sku, ignore_id=product_id) is not None:
                raise SkuDuplicadoError(data.sku)
        updated = product.model_copy(update=data.model_dump(exclude_unset=True))
        return self.repository.update(updated)

    def eliminar(self, product_id: int) -> None:
        self._obtener_o_error(product_id)
        self.repository.delete(product_id)

    def registrar_salida(self, product_id: int, cantidad: int) -> Product:
        product = self._obtener_o_error(product_id)
        if cantidad <= 0:
            raise ValueError("La cantidad debe ser mayor a cero")
        if cantidad > product.quantity:
            raise StockInsuficienteError(disponible=product.quantity, solicitado=cantidad)
        updated = product.model_copy(update={"quantity": product.quantity - cantidad})
        return self.repository.update(updated)
