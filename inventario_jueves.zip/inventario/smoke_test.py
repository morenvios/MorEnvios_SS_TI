from fastapi.testclient import TestClient
from app.main import app

c = TestClient(app)

# --- CRUD básico (lo de ayer, sigue funcionando) ---
r = c.post("/products/", json={"name": "Teclado", "sku": "TEC-1", "category": "Perifericos", "quantity": 10, "price": 25.5})
assert r.status_code == 201, r.text
pid = r.json()["id"]
assert c.get(f"/products/{pid}").status_code == 200
assert c.patch(f"/products/{pid}", json={"quantity": 7}).json()["quantity"] == 7
assert len(c.get("/products/").json()) == 1

# --- Nuevas validaciones de hoy (miercoles) ---

# SKU duplicado -> 409
r_dup = c.post("/products/", json={"name": "Teclado 2", "sku": "TEC-1", "category": "Perifericos", "quantity": 5, "price": 10})
assert r_dup.status_code == 409, r_dup.text

# Precio invalido (<= 0) -> 422
r_precio = c.post("/products/", json={"name": "Mouse", "sku": "MOU-1", "category": "Perifericos", "quantity": 5, "price": 0})
assert r_precio.status_code == 422, r_precio.text

# Cantidad negativa -> 422
r_cant = c.post("/products/", json={"name": "Mouse", "sku": "MOU-2", "category": "Perifericos", "quantity": -3, "price": 10})
assert r_cant.status_code == 422, r_cant.text

# Registrar salida de stock valida
r_salida = c.post(f"/products/{pid}/salida", params={"cantidad": 2})
assert r_salida.status_code == 200, r_salida.text
assert r_salida.json()["quantity"] == 5

# Registrar salida mayor al stock disponible -> 409
r_salida_mala = c.post(f"/products/{pid}/salida", params={"cantidad": 999})
assert r_salida_mala.status_code == 409, r_salida_mala.text

# Filtro por categoria
r_filtro = c.get("/products/", params={"category": "Perifericos"})
assert r_filtro.status_code == 200
assert len(r_filtro.json()) == 1

assert c.delete(f"/products/{pid}").status_code == 204
assert c.get(f"/products/{pid}").status_code == 404

print("OK: CRUD + validaciones + reglas de negocio funcionando")
