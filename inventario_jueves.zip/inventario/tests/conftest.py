import pytest
from app.repositories.product_repository import ProductRepository
from app.services.product_service import ProductService


@pytest.fixture
def service():
    """Servicio con un repositorio limpio para cada prueba."""
    repo = ProductRepository()
    return ProductService(repo)


@pytest.fixture
def producto_base():
    from app.models import ProductCreate
    return ProductCreate(name="Teclado", sku="TEC-1", category="Perifericos", quantity=10, price=25.5)
