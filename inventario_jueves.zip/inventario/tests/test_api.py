from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def _crear_producto(sku="API-1"):
    return client.post("/products/", json={
        "name": "Mouse", "sku": sku, "category": "Perifericos", "quantity": 10, "price": 15.0
    })


def test_crear_y_obtener_producto():
    r = _crear_producto()
    assert r.status_code == 201
    pid = r.json()["id"]
    r_get = client.get(f"/products/{pid}")
    assert r_get.status_code == 200
    assert r_get.json()["sku"] == "API-1"


def test_sku_duplicado_devuelve_409():
    _crear_producto(sku="API-2")
    r = _crear_producto(sku="API-2")
    assert r.status_code == 409


def test_precio_invalido_devuelve_422():
    r = client.post("/products/", json={
        "name": "Mouse", "sku": "API-3", "category": "Perifericos", "quantity": 10, "price": 0
    })
    assert r.status_code == 422


def test_producto_inexistente_devuelve_404():
    r = client.get("/products/99999")
    assert r.status_code == 404


def test_eliminar_producto_devuelve_204():
    r = _crear_producto(sku="API-4")
    pid = r.json()["id"]
    r_del = client.delete(f"/products/{pid}")
    assert r_del.status_code == 204


def test_salida_de_stock_mayor_al_disponible_devuelve_409():
    r = _crear_producto(sku="API-5")
    pid = r.json()["id"]
    r_salida = client.post(f"/products/{pid}/salida", params={"cantidad": 999})
    assert r_salida.status_code == 409
