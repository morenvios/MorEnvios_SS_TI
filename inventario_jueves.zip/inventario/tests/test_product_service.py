import pytest
from app.models import ProductCreate, ProductUpdate
from app.exceptions import SkuDuplicadoError, StockInsuficienteError, ProductoNoEncontradoError


def test_crear_producto(service, producto_base):
    producto = service.crear(producto_base)
    assert producto.id == 1
    assert producto.sku == "TEC-1"


def test_no_permite_sku_duplicado(service, producto_base):
    service.crear(producto_base)
    duplicado = ProductCreate(name="Teclado 2", sku="TEC-1", category="Perifericos", quantity=5, price=10)
    with pytest.raises(SkuDuplicadoError):
        service.crear(duplicado)


def test_actualizar_parcial_cambia_solo_lo_indicado(service, producto_base):
    producto = service.crear(producto_base)
    actualizado = service.actualizar_parcial(producto.id, ProductUpdate(quantity=3))
    assert actualizado.quantity == 3
    assert actualizado.name == "Teclado"  # no cambió


def test_eliminar_producto(service, producto_base):
    producto = service.crear(producto_base)
    service.eliminar(producto.id)
    with pytest.raises(ProductoNoEncontradoError):
        service.obtener(producto.id)


def test_registrar_salida_descuenta_stock(service, producto_base):
    producto = service.crear(producto_base)
    actualizado = service.registrar_salida(producto.id, 4)
    assert actualizado.quantity == 6


def test_registrar_salida_rechaza_stock_insuficiente(service, producto_base):
    producto = service.crear(producto_base)
    with pytest.raises(StockInsuficienteError):
        service.registrar_salida(producto.id, 999)


def test_listar_filtra_por_categoria(service, producto_base):
    service.crear(producto_base)
    otra_categoria = ProductCreate(name="Silla", sku="SIL-1", category="Mobiliario", quantity=2, price=50)
    service.crear(otra_categoria)
    resultado = service.listar(category="Perifericos")
    assert len(resultado) == 1
    assert resultado[0].sku == "TEC-1"
